-- Bechir Dridi
-- english date format

time= os.date("%A, %B, %d, %Y")
service.speak(time)
service.playSoundTick()

return true