require "import"
import "com.androlua.Http"
import "android.widget.Toast"
import "android.app.AlertDialog"
import "android.view.WindowManager"
import "android.os.Handler"
import "android.os.Looper"
import "java.io.File"

local updateURL = "https://raw.githubusercontent.com/TechForVI/Auto-Update-Injector/main/version.txt"
local downloadURL = "https://raw.githubusercontent.com/TechForVI/Auto-Update-Injector/main/main.lua"
local messageURL = "" -- Optional: Insert Message URL manually
local requireUpdate = false -- Set to true to make updates mandatory
local currentVersion = "2.1"
local currentDir = "/storage/emulated/0/解说/Plugins/Auto Update Injector By Tech For V I"
local oldPath = currentDir .. "/old_main.lua"
local mainPath = currentDir .. "/main.lua"

local mainDialog = nil

local function runOriginalCode()
    if File(oldPath).exists() then
        local func, err = loadfile(oldPath)
        if func then pcall(func) end
    end
end

local function checkUpdate()
    Http.get(updateURL, function(code, response)
        if code == 200 and response then
            local onlineVersion = tostring(response):gsub("^%s*(.-)%s*$", "%1")
            if onlineVersion ~= currentVersion then
                
                local function showUpdateDialog(customMsg)
                    Handler(Looper.getMainLooper()).post(Runnable{run=function()
                        local updateAlertDlg = AlertDialog.Builder(service or activity)
                        updateAlertDlg.setTitle("Update Available!")
                        
                        -- Use original lightweight message dialog, supporting custom multiline messages if provided
                        if customMsg and customMsg ~= "" then
                            updateAlertDlg.setMessage(customMsg)
                        else
                            updateAlertDlg.setMessage("New version " .. onlineVersion .. " is ready. Your current version is " .. currentVersion)
                        end
                        
                        updateAlertDlg.setPositiveButton("Update Now", {onClick=function(v)
                            v.dismiss()
                            Toast.makeText(service, "Downloading...", 0).show()
                            Http.get(downloadURL, function(c, content)
                                if c == 200 and content then
                                    local f = io.open(oldPath, "w")
                                    if f then f:write(content):close() end
                                    
                                    local mf = io.open(mainPath, "r")
                                    if mf then
                                        local mainContent = mf:read("*a")
                                        mf:close()
                                        local newMainContent = mainContent:gsub('local currentVersion = "2.0"', 'local currentVersion = "2.0"')
                                        local mf2 = io.open(mainPath, "w")
                                        if mf2 then mf2:write(newMainContent):close() end
                                    end
                                    
                                    local successDialog = AlertDialog.Builder(service or activity)
                                    successDialog.setTitle("Update Successful")
                                    successDialog.setMessage("Plugin updated to "..onlineVersion..". Restarting...")
                                    successDialog.setPositiveButton("OK", {onClick=function(v2)
                                        v2.dismiss()
                                        if mainDialog then
                                            mainDialog.dismiss()
                                        end
                                        Handler(Looper.getMainLooper()).postDelayed(Runnable{run=function()
                                            local func, err = loadfile(mainPath)
                                            if func then
                                                pcall(func)
                                            else
                                                Toast.makeText(service, "Error loading updated plugin: " .. tostring(err), Toast.LENGTH_LONG).show()
                                            end
                                        end}, 1000)
                                    end})
                                    local d2 = successDialog.create()
                                    d2.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
                                    d2.show()
                                end
                            end)
                        end})
                        
                        -- Require update logic implemented inside original dialog structure
                        if requireUpdate then
                            updateAlertDlg.setCancelable(false)
                            updateAlertDlg.setNegativeButton("Later", {onClick=function(v)
                                Toast.makeText(service or activity, "Update is required.", 0).show()
                                showUpdateDialog(customMsg)
                            end})
                        else
                            updateAlertDlg.setNegativeButton("Later", nil)
                        end
                        
                        local d1 = updateAlertDlg.create()
                        d1.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
                        d1.show()
                    end})
                end

                -- Custom message fetching logic
                if messageURL and messageURL ~= "" then
                    Http.get(messageURL, function(mCode, mContent)
                        if mCode == 200 and mContent then
                            local fetchedMsg = tostring(mContent):gsub("^%s*(.-)%s*$", "%1")
                            if fetchedMsg ~= "" then
                                showUpdateDialog(fetchedMsg)
                            else
                                showUpdateDialog(nil)
                            end
                        else
                            showUpdateDialog(nil)
                        end
                    end)
                else
                    showUpdateDialog(nil)
                end
                
            end
        end
    end)
end

runOriginalCode()

Handler(Looper.getMainLooper()).postDelayed(Runnable{run=function()
    checkUpdate()
end}, 3000)
