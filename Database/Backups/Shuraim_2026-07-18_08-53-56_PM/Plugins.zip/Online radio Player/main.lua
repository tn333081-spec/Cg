require "import"
import "android.widget.*"
import "android.view.*"
import "android.content.Intent"
import "android.net.Uri"
import "android.media.MediaPlayer"
import "java.util.Locale"
import "android.os.Handler"
import "java.lang.Runnable"
import "android.text.TextWatcher"
import "android.content.DialogInterface"
import "android.widget.AdapterView"
import "java.net.URLEncoder"
import "android.text.InputType"
import "android.graphics.Typeface"

local cjson = require "cjson"
local prefs = this.getSharedPreferences("RadioAppPrefs", 0)
local editor = prefs.edit()

local api_servers = {
    "https://de1.api.radio-browser.info/json",
    "https://nl1.api.radio-browser.info/json",
    "https://at1.api.radio-browser.info/json",
    "https://all.api.radio-browser.info/json"
}
local active_api = ""
local station_list = {}
local favorites_list = {}
local play_history = {}
local search_history = {}
local current_station_index = 1
local player = nil
local player_status_tv = nil
local btn_play_pause = nil
local btn_sleep_timer = nil
local search_adapter = nil
local is_init_done = false
local my_country_code = Locale.getDefault().getCountry()

-- View Mode: 0 = All, 1 = Favorites, 2 = History
local view_mode = prefs.getInt("view_mode", 0)

-- Sleep Timer Variables (By default OFF)
local sleep_timer_handler = Handler()
local sleep_timer_runnable = nil
local sleep_timer_minutes = 0

local sort_options = {
    {name = "Most Clicks", param = "order=clickcount&reverse=true"},
    {name = "Most Votes", param = "order=votes&reverse=true"},
    {name = "Trending", param = "order=clicktrend&reverse=true"},
    {name = "Name A-Z", param = "order=name&reverse=false"},
    {name = "Name Z-A", param = "order=name&reverse=true"},
    {name = "Random", param = "order=random&reverse=false"}
}

local country_options = {
    {name = "All", code = "ALL"}, {name = "Afghanistan", code = "AF"}, {name = "Albania", code = "AL"}, {name = "Algeria", code = "DZ"}, {name = "American Samoa", code = "AS"}, {name = "Andorra", code = "AD"}, {name = "Angola", code = "AO"}, {name = "Anguilla", code = "AI"}, {name = "Antarctica", code = "AQ"}, {name = "Antigua and Barbuda", code = "AG"}, {name = "Argentina", code = "AR"}, {name = "Armenia", code = "AM"}, {name = "Aruba", code = "AW"}, {name = "Australia", code = "AU"}, {name = "Austria", code = "AT"}, {name = "Azerbaijan", code = "AZ"}, {name = "Bahamas", code = "BS"}, {name = "Bahrain", code = "BH"}, {name = "Bangladesh", code = "BD"}, {name = "Barbados", code = "BB"}, {name = "Belarus", code = "BY"}, {name = "Belgium", code = "BE"}, {name = "Belize", code = "BZ"}, {name = "Benin", code = "BJ"}, {name = "Bermuda", code = "BM"}, {name = "Bhutan", code = "BT"}, {name = "Bolivia", code = "BO"}, {name = "Bosnia and Herzegovina", code = "BA"}, {name = "Botswana", code = "BW"}, {name = "Bouvet Island", code = "BV"}, {name = "Brazil", code = "BR"}, {name = "British Indian Ocean Territory", code = "IO"}, {name = "British Virgin Islands", code = "VG"}, {name = "Brunei", code = "BN"}, {name = "Bulgaria", code = "BG"}, {name = "Burkina Faso", code = "BF"}, {name = "Burundi", code = "BI"}, {name = "Cambodia", code = "KH"}, {name = "Cameroon", code = "CM"}, {name = "Canada", code = "CA"}, {name = "Cape Verde", code = "CV"}, {name = "Caribbean Netherlands", code = "BQ"}, {name = "Cayman Islands", code = "KY"}, {name = "Central African Republic", code = "CF"}, {name = "Chad", code = "TD"}, {name = "Chile", code = "CL"}, {name = "China", code = "CN"}, {name = "Christmas Island", code = "CX"}, {name = "Cocos Islands", code = "CC"}, {name = "Colombia", code = "CO"}, {name = "Comoros", code = "KM"}, {name = "Congo", code = "CG"}, {name = "Congo, Democratic Republic", code = "CD"}, {name = "Cook Islands", code = "CK"}, {name = "Costa Rica", code = "CR"}, {name = "Croatia", code = "HR"}, {name = "Cuba", code = "CU"}, {name = "Curaçao", code = "CW"}, {name = "Cyprus", code = "CY"}, {name = "Czech Republic", code = "CZ"}, {name = "Denmark", code = "DK"}, {name = "Djibouti", code = "DJ"}, {name = "Dominica", code = "DM"}, {name = "Dominican Republic", code = "DO"}, {name = "East Timor", code = "TL"}, {name = "Ecuador", code = "EC"}, {name = "Egypt", code = "EG"}, {name = "El Salvador", code = "SV"}, {name = "Equatorial Guinea", code = "GQ"}, {name = "Eritrea", code = "ER"}, {name = "Estonia", code = "EE"}, {name = "Eswatini", code = "SZ"}, {name = "Ethiopia", code = "ET"}, {name = "Falkland Islands", code = "FK"}, {name = "Faroe Islands", code = "FO"}, {name = "Fiji", code = "FJ"}, {name = "Finland", code = "FI"}, {name = "France", code = "FR"}, {name = "French Guiana", code = "GF"}, {name = "French Polynesia", code = "PF"}, {name = "French Southern Territories", code = "TF"}, {name = "Gabon", code = "GA"}, {name = "Gambia", code = "GM"}, {name = "Georgia", code = "GE"}, {name = "Germany", code = "DE"}, {name = "Ghana", code = "GH"}, {name = "Gibraltar", code = "GI"}, {name = "Greece", code = "GR"}, {name = "Greenland", code = "GL"}, {name = "Grenada", code = "GD"}, {name = "Guadeloupe", code = "GP"}, {name = "Guam", code = "GU"}, {name = "Guatemala", code = "GT"}, {name = "Guernsey", code = "GG"}, {name = "Guinea", code = "GN"}, {name = "Guinea-Bissau", code = "GW"}, {name = "Guyana", code = "GY"}, {name = "Haiti", code = "HT"}, {name = "Heard and McDonald Islands", code = "HM"}, {name = "Honduras", code = "HN"}, {name = "Hong Kong", code = "HK"}, {name = "Hungary", code = "HU"}, {name = "Iceland", code = "IS"}, {name = "India", code = "IN"}, {name = "Indonesia", code = "ID"}, {name = "Iran", code = "IR"}, {name = "Iraq", code = "IQ"}, {name = "Ireland", code = "IE"}, {name = "Isle of Man", code = "IM"}, {name = "Israel", code = "IL"}, {name = "Italy", code = "IT"}, {name = "Ivory Coast", code = "CI"}, {name = "Jamaica", code = "JM"}, {name = "Japan", code = "JP"}, {name = "Jersey", code = "JE"}, {name = "Jordan", code = "JO"}, {name = "Kazakhstan", code = "KZ"}, {name = "Kenya", code = "KE"}, {name = "Kiribati", code = "KI"}, {name = "Kosovo", code = "XK"}, {name = "Kuwait", code = "KW"}, {name = "Kyrgyzstan", code = "KG"}, {name = "Laos", code = "LA"}, {name = "Latvia", code = "LV"}, {name = "Lebanon", code = "LB"}, {name = "Lesotho", code = "LS"}, {name = "Liberia", code = "LR"}, {name = "Libya", code = "LY"}, {name = "Liechtenstein", code = "LI"}, {name = "Lithuania", code = "LT"}, {name = "Luxembourg", code = "LU"}, {name = "Macau", code = "MO"}, {name = "Madagascar", code = "MG"}, {name = "Malawi", code = "MW"}, {name = "Malaysia", code = "MY"}, {name = "Maldives", code = "MV"}, {name = "Mali", code = "ML"}, {name = "Malta", code = "MT"}, {name = "Marshall Islands", code = "MH"}, {name = "Martinique", code = "MQ"}, {name = "Mauritania", code = "MR"}, {name = "Mauritius", code = "MU"}, {name = "Mayotte", code = "YT"}, {name = "Mexico", code = "MX"}, {name = "Micronesia", code = "FM"}, {name = "Moldova", code = "MD"}, {name = "Monaco", code = "MC"}, {name = "Mongolia", code = "MN"}, {name = "Montenegro", code = "ME"}, {name = "Montserrat", code = "MS"}, {name = "Morocco", code = "MA"}, {name = "Mozambique", code = "MZ"}, {name = "Myanmar", code = "MM"}, {name = "Namibia", code = "NA"}, {name = "Nauru", code = "NR"}, {name = "Nepal", code = "NP"}, {name = "Netherlands", code = "NL"}, {name = "New Caledonia", code = "NC"}, {name = "New Zealand", code = "NZ"}, {name = "Nicaragua", code = "NI"}, {name = "Niger", code = "NE"}, {name = "Nigeria", code = "NG"}, {name = "Niue", code = "NU"}, {name = "Norfolk Island", code = "NF"}, {name = "North Korea", code = "KP"}, {name = "North Macedonia", code = "MK"}, {name = "Northern Mariana Islands", code = "MP"}, {name = "Norway", code = "NO"}, {name = "Oman", code = "OM"}, {name = "Pakistan", code = "PK"}, {name = "Palau", code = "PW"}, {name = "Palestine", code = "PS"}, {name = "Panama", code = "PA"}, {name = "Papua New Guinea", code = "PG"}, {name = "Paraguay", code = "PY"}, {name = "Peru", code = "PE"}, {name = "Philippines", code = "PH"}, {name = "Pitcairn Islands", code = "PN"}, {name = "Poland", code = "PL"}, {name = "Portugal", code = "PT"}, {name = "Puerto Rico", code = "PR"}, {name = "Qatar", code = "QA"}, {name = "Réunion", code = "RE"}, {name = "Romania", code = "RO"}, {name = "Russia", code = "RU"}, {name = "Rwanda", code = "RW"}, {name = "Saint Barthélemy", code = "BL"}, {name = "Saint Helena", code = "SH"}, {name = "Saint Kitts and Nevis", code = "KN"}, {name = "Saint Lucia", code = "LC"}, {name = "Saint Martin", code = "MF"}, {name = "Saint Pierre and Miquelon", code = "PM"}, {name = "Saint Vincent and the Grenadines", code = "VC"}, {name = "Samoa", code = "WS"}, {name = "San Marino", code = "SM"}, {name = "São Tomé and Príncipe", code = "ST"}, {name = "Saudi Arabia", code = "SA"}, {name = "Senegal", code = "SN"}, {name = "Serbia", code = "RS"}, {name = "Seychelles", code = "SC"}, {name = "Sierra Leone", code = "SL"}, {name = "Singapore", code = "SG"}, {name = "Sint Maarten", code = "SX"}, {name = "Slovakia", code = "SK"}, {name = "Slovenia", code = "SI"}, {name = "Solomon Islands", code = "SB"}, {name = "Somalia", code = "SO"}, {name = "South Africa", code = "ZA"}, {name = "South Georgia and the Sandwich Islands", code = "GS"}, {name = "South Korea", code = "KR"}, {name = "South Sudan", code = "SS"}, {name = "Spain", code = "ES"}, {name = "Sri Lanka", code = "LK"}, {name = "Sudan", code = "SD"}, {name = "Suriname", code = "SR"}, {name = "Svalbard and Jan Mayen", code = "SJ"}, {name = "Sweden", code = "SE"}, {name = "Switzerland", code = "CH"}, {name = "Syria", code = "SY"}, {name = "Taiwan", code = "TW"}, {name = "Tajikistan", code = "TJ"}, {name = "Tanzania", code = "TZ"}, {name = "Thailand", code = "TH"}, {name = "Togo", code = "TG"}, {name = "Tokelau", code = "TK"}, {name = "Tonga", code = "TO"}, {name = "Trinidad and Tobago", code = "TT"}, {name = "Tunisia", code = "TN"}, {name = "Turkey", code = "TR"}, {name = "Turkmenistan", code = "TM"}, {name = "Turks and Caicos Islands", code = "TC"}, {name = "Tuvalu", code = "TV"}, {name = "US Minor Outlying Islands", code = "UM"}, {name = "US Virgin Islands", code = "VI"}, {name = "Uganda", code = "UG"}, {name = "Ukraine", code = "UA"}, {name = "United Arab Emirates", code = "AE"}, {name = "United Kingdom", code = "GB"}, {name = "United States", code = "US"}, {name = "Uruguay", code = "UY"}, {name = "Uzbekistan", code = "UZ"}, {name = "Vanuatu", code = "VU"}, {name = "Vatican City", code = "VA"}, {name = "Venezuela", code = "VE"}, {name = "Vietnam", code = "VN"}, {name = "Wallis and Futuna", code = "WF"}, {name = "Western Sahara", code = "EH"}, {name = "Yemen", code = "YE"}, {name = "Zambia", code = "ZM"}, {name = "Zimbabwe", code = "ZW"}, {name = "Åland Islands", code = "AX"}
}

local function speakText(text)
    if service and service.speak then
        service.speak(text)
    end
end

local function loadLists()
    favorites_list = cjson.decode(prefs.getString("favorites", "[]"))
    play_history = cjson.decode(prefs.getString("play_history", "[]"))
    search_history = cjson.decode(prefs.getString("search_history", "[]"))
end

local function saveFavorites() editor.putString("favorites", cjson.encode(favorites_list)).apply() end
local function savePlayHistory() editor.putString("play_history", cjson.encode(play_history)).apply() end
local function saveSearchHistory() editor.putString("search_history", cjson.encode(search_history)).apply() end

local function addSearchHistory(query)
    if query == nil or query:match("^%s*$") then return end
    for i, v in ipairs(search_history) do
        if v == query then
            table.remove(search_history, i)
            break
        end
    end
    table.insert(search_history, 1, query)
    if #search_history > 10 then table.remove(search_history) end
    saveSearchHistory()
    
    if search_adapter then
        search_adapter.clear()
        for i=1, #search_history do search_adapter.add(search_history[i]) end
    end
end

local function addToPlayHistory(station)
    for i, v in ipairs(play_history) do
        if v.url == station.url then
            table.remove(play_history, i)
            break
        end
    end
    table.insert(play_history, 1, station)
    if #play_history > 10 then table.remove(play_history) end
    savePlayHistory()
end

local function isFavorite(url)
    for i, v in ipairs(favorites_list) do
        if v.url == url then return i end
    end
    return false
end

local function releasePlayer()
    if player ~= nil then
        if player.isPlaying() then player.stop() end
        player.release()
        player = nil
    end
end

local function updatePlayerStatus(text)
    if player_status_tv then player_status_tv.setText(text) end
end

-- Smart Sleep Timer Functionality
local function setSleepTimer(minutes)
    if sleep_timer_runnable ~= nil then
        sleep_timer_handler.removeCallbacks(sleep_timer_runnable)
        sleep_timer_runnable = nil
    end
    sleep_timer_minutes = minutes
    if minutes > 0 then
        sleep_timer_runnable = Runnable{
            run = function()
                sleep_timer_minutes = 0
                releasePlayer()
                updatePlayerStatus("Status: Playback stopped by Sleep Timer")
                speakText("Sleep timer expired. Radio playback stopped.")
                Toast.makeText(this, "Sleep timer expired. Playback stopped.", Toast.LENGTH_LONG).show()
                if btn_sleep_timer then
                    btn_sleep_timer.setText("Sleep Timer: Off")
                    btn_sleep_timer.setContentDescription("Sleep timer. Currently selected: Off")
                end
            end
        }
        sleep_timer_handler.postDelayed(sleep_timer_runnable, minutes * 60 * 1000)
        Toast.makeText(this, "Sleep timer set for " .. minutes .. " minutes", Toast.LENGTH_SHORT).show()
        speakText("Sleep timer set for " .. minutes .. " minutes")
    else
        Toast.makeText(this, "Sleep timer turned off", Toast.LENGTH_SHORT).show()
        speakText("Sleep timer turned off")
    end
    
    if btn_sleep_timer then
        btn_sleep_timer.setText(minutes > 0 and ("Timer: " .. minutes .. "m") or "Sleep Timer: Off")
        btn_sleep_timer.setContentDescription(minutes > 0 and ("Sleep timer. Currently set to " .. minutes .. " minutes remaining") or "Sleep timer. Currently selected: Off")
    end
end

-- Fixed Dialog completely. No more setAdapter error.
local function showSleepTimerDialog()
    local timer_options = {"Off", "15 Minutes", "30 Minutes", "45 Minutes", "60 Minutes", "90 Minutes", "120 Minutes"}
    local timer_values = {0, 15, 30, 45, 60, 90, 120}
    
    local t_layout = {
        ListView, id="lv_timer", layout_width="fill", layout_height="wrap_content"
    }
    local dlg = LuaDialog(this)
    dlg.setView(loadlayout(t_layout))
    dlg.setTitle("Select Sleep Timer")
    
    local adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1)
    for i=1, #timer_options do adapter.add(timer_options[i]) end
    lv_timer.setAdapter(adapter)
    
    lv_timer.setOnItemClickListener(AdapterView.OnItemClickListener{
        onItemClick = function(parent, view, position, id)
            setSleepTimer(timer_values[position + 1])
            dlg.dismiss()
        end
    })
    dlg.show()
end

local function toggleLoadingState(isLoading, message)
    if isLoading then
        tv_loading.setText(message or "Loading...")
        tv_loading.setVisibility(View.VISIBLE)
        lv_stations.setVisibility(View.GONE)
    else
        tv_loading.setVisibility(View.GONE)
        lv_stations.setVisibility(View.VISIBLE)
    end
end

local function renderList(data, adapter, success_message)
    station_list = data
    adapter.clear()
    for i=1, #data do
        adapter.add(data[i].name)
    end
    adapter.notifyDataSetChanged()
    if success_message then
        speakText(success_message)
    end
end

local function getLimitValue()
    local val = edt_limit.getText().toString()
    if val == nil or val == "" then return "5000" end
    local num = tonumber(val)
    if not num or num <= 0 then return "5000" end
    return tostring(math.floor(num))
end

local function reloadData(adapter, query)
    if not is_init_done then return end
    query = query or ""
    
    local sort_idx = spin_sort.getSelectedItemPosition() + 1
    local sort_param = sort_options[sort_idx].param
    
    local cty_idx = prefs.getInt("country_mode", 0)
    local cty_code = country_options[cty_idx + 1].code
    local limit_val = getLimitValue()

    -- Favorites View
    if view_mode == 1 then
        local filtered = {}
        for i, v in ipairs(favorites_list) do
            if query == "" or string.find(string.lower(v.name), string.lower(query), 1, true) then
                table.insert(filtered, v)
            end
        end
        toggleLoadingState(false)
        renderList(filtered, adapter, "Loaded " .. #filtered .. " favorite stations")
        return
    end
    
    -- History View
    if view_mode == 2 then
        local filtered = {}
        for i, v in ipairs(play_history) do
            if query == "" or string.find(string.lower(v.name), string.lower(query), 1, true) then
                table.insert(filtered, v)
            end
        end
        toggleLoadingState(false)
        renderList(filtered, adapter, "Loaded " .. #filtered .. " watch history stations")
        return
    end

    if query ~= "" then
        toggleLoadingState(true, "Searching stations worldwide...")
        local tokens = {}
        for token in string.gmatch(query, "%S+") do
            table.insert(tokens, token)
        end
        if #tokens == 0 then table.insert(tokens, "") end
        local discovery_limit = math.max(tonumber(limit_val) or 5000, 10000)
        local base_params = "limit=" .. discovery_limit .. "&order=votes&reverse=true&hidebroken=true"
        if cty_code ~= "ALL" then
            base_params = base_params .. "&countrycode=" .. cty_code
        end
        local urls = {}
        for i, token in ipairs(tokens) do
            local encoded = URLEncoder.encode(token, "UTF-8")
            table.insert(urls, active_api .. "/stations/search?" .. base_params .. "&name=" .. encoded)
            table.insert(urls, active_api .. "/stations/search?" .. base_params .. "&tag=" .. encoded)
            table.insert(urls, active_api .. "/stations/search?" .. base_params .. "&country=" .. encoded)
        end
        local expected_responses = #urls
        local completed_responses = 0
        local seen_stations = {}
        local any_success = false
        
        for i, url in ipairs(urls) do
            Http.get(url, function(code, content)
                completed_responses = completed_responses + 1
                if code == 200 then
                    any_success = true
                    local success, data = pcall(cjson.decode, content)
                    if success and type(data) == "table" then
                        for j=1, #data do
                            local s = data[j]
                            local uid = s.stationuuid
                            if uid and uid ~= "" and not seen_stations[uid] then
                                seen_stations[uid] = s
                            end
                        end
                    end
                end
                if completed_responses == expected_responses then
                    if not any_success then
                        toggleLoadingState(true, "Connection error! Please check internet.")
                        return
                    end
                    local filtered = {}
                    for uid, s in pairs(seen_stations) do
                        local is_match = true
                        local haystack = string.lower((s.name or "") .. " " .. (s.countrycode or "") .. " " .. (s.country or "") .. " " .. (s.tags or ""))
                        for _, token in ipairs(tokens) do
                            if not string.find(haystack, string.lower(token), 1, true) then
                                is_match = false
                                break
                            end
                        end
                        if is_match then
                            table.insert(filtered, s)
                        end
                    end
                    table.sort(filtered, function(a, b)
                        local vA = tonumber(a.votes) or 0
                        local vB = tonumber(b.votes) or 0
                        return vA > vB
                    end)
                    local final_limit = tonumber(limit_val) or 5000
                    local result = {}
                    for j=1, math.min(#filtered, final_limit) do
                        table.insert(result, {name = filtered[j].name, url = filtered[j].url_resolved})
                    end
                    toggleLoadingState(false)
                    if #result == 0 then
                        toggleLoadingState(true, "No matching stations found!")
                        speakText("No results found")
                    else
                        renderList(result, adapter, "Found " .. #result .. " results")
                    end
                end
            end)
        end
    elseif cty_code ~= "ALL" then
        toggleLoadingState(true, "Loading all country stations...")
        local params = "limit=" .. limit_val .. "&" .. sort_param .. "&countrycode=" .. cty_code .. "&hidebroken=true"
        local search_url = active_api .. "/stations/bycountrycodeexact/" .. cty_code .. "?" .. params
        Http.get(search_url, function(code, content)
            if code == 200 then
                local success, data = pcall(cjson.decode, content)
                local result = {}
                if success and type(data) == "table" then
                    for i=1, #data do
                        table.insert(result, {name = data[i].name, url = data[i].url_resolved})
                    end
                end
                toggleLoadingState(false)
                if #result == 0 then
                    toggleLoadingState(true, "No stations available for this country!")
                else
                    renderList(result, adapter, "Loaded " .. #result .. " stations")
                end
            else
                toggleLoadingState(true, "Connection error! Please retry.")
            end
        end)
    else
        toggleLoadingState(true, "Loading worldwide radio stations...")
        local global_url = active_api .. "/stations/topvote/" .. limit_val .. "?hidebroken=true"
        local country_url = active_api .. "/stations/bycountrycodeexact/" .. my_country_code .. "?limit=" .. limit_val .. "&order=votes&reverse=true&hidebroken=true"
        local completed = 0
        local expected = 2
        local global_data = {}
        local local_data = {}
        local function processMerge()
            local merged = {}
            for i=1, #local_data do table.insert(merged, local_data[i]) end
            for i=1, #global_data do table.insert(merged, global_data[i]) end
            local final_result = {}
            local seen = {}
            for i=1, #merged do
                local s = merged[i]
                local uid = s.stationuuid
                if uid and uid ~= "" and not seen[uid] then
                    seen[uid] = true
                    table.insert(final_result, {name = s.name, url = s.url_resolved})
                end
            end
            toggleLoadingState(false)
            renderList(final_result, adapter, "Loaded " .. #final_result .. " live radio stations")
        end
        Http.get(global_url, function(code, content)
            completed = completed + 1
            if code == 200 then
                local success, data = pcall(cjson.decode, content)
                if success and type(data) == "table" then global_data = data end
            end
            if completed == expected then processMerge() end
        end)
        Http.get(country_url, function(code, content)
            completed = completed + 1
            if code == 200 then
                local success, data = pcall(cjson.decode, content)
                if success and type(data) == "table" then local_data = data end
            end
            if completed == expected then processMerge() end
        end)
    end
end

local function findFastestServerAndStart(adapter)
    local check_count = 0
    local found = false
    toggleLoadingState(true, "Connecting to fastest radio server...")
    for i=1, #api_servers do
        Http.get(api_servers[i] .. "/stats", function(code, content)
            if found then return end
            if code == 200 then
                found = true
                active_api = api_servers[i]
                is_init_done = true
                reloadData(adapter, "")
            end
            check_count = check_count + 1
            if check_count == #api_servers and not found then
                active_api = "https://all.api.radio-browser.info/json"
                is_init_done = true
                reloadData(adapter, "")
            end
        end)
    end
end

local function playStation(index)
    if index < 1 or index > #station_list then return end
    current_station_index = index
    local station = station_list[index]
    
    addToPlayHistory(station) -- Register Watch History
    
    releasePlayer()
    updatePlayerStatus("Status: Loading " .. station.name .. "...")
    if btn_play_pause then 
        btn_play_pause.setText("Pause") 
        btn_play_pause.setContentDescription("Pause audio playback")
    end
    player = MediaPlayer()
    player.setDataSource(station.url)
    
    -- Smart Audio Player Buffering & Info Listeners
    player.setOnInfoListener(MediaPlayer.OnInfoListener{
        onInfo = function(mp, what, extra)
            if what == 701 then -- MEDIA_INFO_BUFFERING_START
                updatePlayerStatus("Status: Buffering audio...")
            elseif what == 702 then -- MEDIA_INFO_BUFFERING_END
                updatePlayerStatus("Status: Playing " .. station.name)
            end
            return true
        end
    })
    
    player.setOnPreparedListener(MediaPlayer.OnPreparedListener{
        onPrepared = function(mp)
            mp.start()
            updatePlayerStatus("Status: Playing " .. station.name)
            speakText("Playing " .. station.name)
        end
    })
    player.setOnErrorListener(MediaPlayer.OnErrorListener{
        onError = function(mp, what, extra)
            updatePlayerStatus("Status: Connection error for this station!")
            speakText("Error loading station. Please try another channel.")
            return true
        end
    })
    player.prepareAsync()
end

local function showPlayerDialog()
    local playerLayout = {
        LinearLayout,
        orientation = "vertical",
        layout_width = "fill",
        layout_height = "wrap_content",
        padding = "16dp",
        {TextView,
            id = "tv_status",
            text = "Status: Loading...",
            textSize = "16sp",
            layout_width = "fill",
            layout_height = "wrap_content",
            layout_marginBottom = "20dp",
        },
        {LinearLayout,
            orientation = "horizontal",
            layout_width = "fill",
            layout_height = "wrap_content",
            gravity = "center",
            {Button, text = "Previous", onClick = function() if current_station_index > 1 then playStation(current_station_index - 1) end end},
            {Button, id = "btn_toggle", text = "Pause", onClick = function()
                if player then
                    if player.isPlaying() then
                        player.pause()
                        btn_play_pause.setText("Play")
                        btn_play_pause.setContentDescription("Play audio playback")
                        updatePlayerStatus("Status: Paused")
                        speakText("Paused")
                    else
                        player.start()
                        btn_play_pause.setText("Pause")
                        btn_play_pause.setContentDescription("Pause audio playback")
                        updatePlayerStatus("Status: Playing")
                        speakText("Resumed playing")
                    end
                end
            end},
            {Button, text = "Next", onClick = function() if current_station_index < #station_list then playStation(current_station_index + 1) end end}
        },
        {Button, id = "btn_dlg_sleep", text = sleep_timer_minutes > 0 and ("Sleep Timer: " .. sleep_timer_minutes .. "m") or "Sleep Timer: Off", layout_width = "fill", layout_height = "wrap_content", layout_marginTop = "10dp", onClick = function() showSleepTimerDialog() end},
        {Button, text = "Close", layout_width = "fill", layout_height = "wrap_content", layout_marginTop = "5dp", onClick = function() playerDlg.dismiss() end}
    }
    playerDlg = LuaDialog(this)
    playerDlg.setView(loadlayout(playerLayout))
    playerDlg.setTitle("Radio Audio Player")
    player_status_tv = tv_status
    btn_play_pause = btn_toggle
    btn_sleep_timer = btn_dlg_sleep
    btn_sleep_timer.setContentDescription(sleep_timer_minutes > 0 and ("Sleep timer. Currently set to " .. sleep_timer_minutes .. " minutes remaining") or "Sleep timer. Currently selected: Off")
    
    playerDlg.setOnDismissListener(DialogInterface.OnDismissListener{
        onDismiss = function(dialog) releasePlayer() end
    })
    playerDlg.show()
    playStation(current_station_index)
end

function showThinhDialog()
    loadLists()
    local adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1)
    
    local sort_mode_items = {}
    for i=1, #sort_options do table.insert(sort_mode_items, sort_options[i].name) end
    
    local adapter_sort = ArrayAdapter(this, android.R.layout.simple_spinner_item, sort_mode_items)
    adapter_sort.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
    
    local current_country_idx = prefs.getInt("country_mode", 0)

    -- Dynamic Accessibility Updater Function
    local function updateFilterAccessibility()
        if btn_view_mode then
            local v_status = "All Stations"
            if view_mode == 1 then v_status = "Favorites" elseif view_mode == 2 then v_status = "History" end
            btn_view_mode.setContentDescription("View mode. Currently showing: " .. v_status)
        end
        if spin_sort then
            local sort_idx = spin_sort.getSelectedItemPosition() + 1
            local sort_name = sort_options[sort_idx] and sort_options[sort_idx].name or "Default"
            spin_sort.setContentDescription("Sort order. Currently selected: " .. sort_name)
        end
        if btn_country_select then
            local c_idx = prefs.getInt("country_mode", 0) + 1
            local c_name = country_options[c_idx] and country_options[c_idx].name or "All"
            btn_country_select.setContentDescription("Country. Currently selected: " .. c_name)
        end
    end

    local function showCountrySearchDialog()
        local cty_adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1)
        for i=1, #country_options do cty_adapter.add(country_options[i].name) end
        
        local c_layout = {
            LinearLayout, orientation = "vertical", layout_width = "fill", layout_height = "fill",
            {EditText, id="edt_c_search", hint="Search your country...", layout_width="fill"},
            {ListView, id="lv_c", layout_width="fill", layout_height="fill"}
        }
        local cdlg = LuaDialog(this)
        cdlg.setView(loadlayout(c_layout))
        lv_c.setAdapter(cty_adapter)
        cdlg.setTitle("Select Country")
        
        edt_c_search.addTextChangedListener(TextWatcher{
            onTextChanged = function(s)
                cty_adapter.clear()
                local q = tostring(s):lower()
                for i=1, #country_options do
                    if country_options[i].name:lower():find(q, 1, true) then
                        cty_adapter.add(country_options[i].name)
                    end
                end
            end
        })
        
        lv_c.setOnItemClickListener(AdapterView.OnItemClickListener{
            onItemClick = function(parent, view, position, id)
                local selected_name = tostring(view.getText())
                local real_idx = 0
                for i=1, #country_options do
                    if country_options[i].name == selected_name then
                        real_idx = i - 1
                        break
                    end
                end
                editor.putInt("country_mode", real_idx).apply()
                btn_country_select.setText(selected_name)
                cdlg.dismiss()
                updateFilterAccessibility()
                reloadData(adapter, edt_search.getText().toString())
            end
        })
        cdlg.show()
    end
    
    local function toggleViewModeBtn()
        view_mode = (view_mode + 1) % 3
        editor.putInt("view_mode", view_mode).apply()
        local btn_text = "All Stations"
        if view_mode == 1 then btn_text = "Favorites" elseif view_mode == 2 then btn_text = "History" end
        btn_view_mode.setText(btn_text)
        updateFilterAccessibility()
        reloadData(adapter, edt_search.getText().toString())
    end

    local thinhLayout = {
        LinearLayout,
        orientation = "vertical",
        layout_width = "fill",
        layout_height = "fill",
        {TextView,
            id = "tv_dev_title",
            text = "Developed by Muhammad Hussain",
            gravity = "center",
            textSize = "15sp",
            textColor = "#0066CC",
            layout_width = "fill",
            layout_height = "wrap_content",
            layout_marginTop = "6dp",
            layout_marginBottom = "4dp",
        },
        {LinearLayout,
            orientation = "horizontal",
            layout_width = "fill",
            layout_height = "wrap_content",
            {Button,
                id = "btn_how_to_use",
                text = "How to use",
                layout_width = "0dp",
                layout_height = "wrap_content",
                layout_weight = 1,
                onClick = function()
                    local intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://youtu.be/FKSIapQBg1Q?si=ZtDsMGZIDIeOSAn6"))
                    service.startActivity(intent)
                end},
            {Button,
                id = "btn_youtube_top",
                text = "YouTube Channel",
                layout_width = "0dp",
                layout_height = "wrap_content",
                layout_weight = 1,
                onClick = function()
                    local intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/@HussainUrduadab"))
                    service.startActivity(intent)
                end}
        },
        {LinearLayout,
            orientation = "horizontal",
            layout_width = "fill",
            layout_height = "wrap_content",
            layout_marginTop = "4dp",
            {Button, id = "btn_view_mode", layout_weight = 1, onClick = toggleViewModeBtn},
            {Spinner, id = "spin_sort", layout_weight = 1},
            {Button, id = "btn_country_select", text = country_options[current_country_idx + 1].name, layout_weight = 1, onClick = function() showCountrySearchDialog() end}
        },
        {LinearLayout,
            orientation = "horizontal",
            layout_width = "fill",
            layout_height = "wrap_content",
            layout_marginTop = "4dp",
            {EditText,
                id = "edt_limit",
                hint = "Limit",
                text = "5000",
                inputType = InputType.TYPE_CLASS_NUMBER,
                layout_width = "wrap_content",
                layout_height = "wrap_content",
                width = "80dp",
                gravity = "center",
            },
            -- Modified to AutoCompleteTextView with threshold=1 to avoid layout error
            {AutoCompleteTextView,
                id = "edt_search",
                hint = "Search radio stations...",
                layout_width = "0dp",
                layout_height = "wrap_content",
                layout_weight = 1,
                threshold = 1,
                singleLine = true
            }
        },
        {TextView,
            id = "tv_loading",
            text = "Initializing radio network...",
            textSize = "15sp",
            gravity = "center",
            layout_width = "fill",
            layout_height = "0dp",
            layout_weight = 1,
            visibility = "gone",
        },
        {ListView,
            id = "lv_stations",
            layout_width = "fill",
            layout_height = "0dp",
            layout_weight = 1,
        },
        {Button,
            text = "Close Application",
            layout_width = "fill",
            layout_height = "wrap_content",
            onClick = function()
                thinhdlg.dismiss()
            end}
    }
    
    thinhdlg = LuaDialog(this)
    thinhdlg.setView(loadlayout(thinhLayout))
    thinhdlg.setTitle("Online Radio Player")
    
    if tv_dev_title then tv_dev_title.setTypeface(Typeface.DEFAULT_BOLD) end
    
    local v_txt = "All Stations"
    if view_mode == 1 then v_txt = "Favorites" elseif view_mode == 2 then v_txt = "History" end
    btn_view_mode.setText(v_txt)
    
    -- Search History Adapter
    search_adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line)
    for i=1, #search_history do search_adapter.add(search_history[i]) end
    edt_search.setAdapter(search_adapter)

    lv_stations.setAdapter(adapter)
    spin_sort.setAdapter(adapter_sort)
    spin_sort.setSelection(prefs.getInt("sort_mode", 3))
    
    updateFilterAccessibility()
    
    spin_sort.setOnItemSelectedListener(AdapterView.OnItemSelectedListener{
        onItemSelected = function(parent, view, position, id)
            editor.putInt("sort_mode", position).apply()
            updateFilterAccessibility()
            reloadData(adapter, edt_search.getText().toString())
        end
    })
    
    lv_stations.setOnItemClickListener(AdapterView.OnItemClickListener{
        onItemClick = function(parent, view, position, id)
            current_station_index = position + 1
            showPlayerDialog()
        end
    })
    
    lv_stations.setOnItemLongClickListener(AdapterView.OnItemLongClickListener{
        onItemLongClick = function(parent, view, position, id)
            local item_idx = position + 1
            local station = station_list[item_idx]
            if not station then return false end
            
            if view_mode == 2 then
                -- In History mode, long click prompts for deletion or clearing history
                local h_dlg = LuaDialog(this)
                h_dlg.setTitle("History Options")
                h_dlg.setMessage("What do you want to do with " .. station.name .. "?")
                h_dlg.setButton("Remove", DialogInterface.OnClickListener{
                    onClick = function()
                        for i, v in ipairs(play_history) do
                            if v.url == station.url then table.remove(play_history, i) break end
                        end
                        savePlayHistory()
                        reloadData(adapter, edt_search.getText().toString())
                        Toast.makeText(this, "Removed from history", Toast.LENGTH_SHORT).show()
                    end
                })
                h_dlg.setButton2("Clear All", DialogInterface.OnClickListener{
                    onClick = function()
                        play_history = {}
                        savePlayHistory()
                        reloadData(adapter, edt_search.getText().toString())
                        Toast.makeText(this, "Watch history cleared", Toast.LENGTH_SHORT).show()
                    end
                })
                h_dlg.setButton3("Cancel", nil)
                h_dlg.show()
            else
                -- In Normal/Favorites mode, long click manages favorites
                local f_idx = isFavorite(station.url)
                if f_idx then
                    table.remove(favorites_list, f_idx)
                    Toast.makeText(this, "Removed from favorites", Toast.LENGTH_SHORT).show()
                    speakText("Removed " .. station.name .. " from favorites")
                else
                    table.insert(favorites_list, station)
                    Toast.makeText(this, "Added to favorites", Toast.LENGTH_SHORT).show()
                    speakText("Added " .. station.name .. " to favorites")
                end
                saveFavorites()
                
                if view_mode == 1 then
                    reloadData(adapter, edt_search.getText().toString())
                end
            end
            return true
        end
    })
    
    thinhdlg.setOnDismissListener(DialogInterface.OnDismissListener{
        onDismiss = function(dialog) releasePlayer() end
    })
    thinhdlg.show()
    
    local searchHandler = Handler()
    local searchRunnable = nil
    local function onInputChanged()
        if searchRunnable ~= nil then searchHandler.removeCallbacks(searchRunnable) end
        local query = edt_search.getText().toString()
        searchRunnable = Runnable{
            run = function()
                addSearchHistory(query)
                reloadData(adapter, query)
            end
        }
        searchHandler.postDelayed(searchRunnable, 1500)
    end
    edt_search.addTextChangedListener(TextWatcher{onTextChanged = onInputChanged})
    edt_limit.addTextChangedListener(TextWatcher{onTextChanged = onInputChanged})
    
    findFastestServerAndStart(adapter)
end

function showWelcomeDialog()
    local welcomeLayout = {
        ScrollView,
        layout_width = "fill",
        layout_height = "fill",
        {LinearLayout,
            orientation = "vertical",
            padding = "20dp",
            layout_width = "fill",
            layout_height = "wrap_content",
            {TextView, id="tv_w_title", text = "Welcome to Online Radio Player!", textSize = "22sp", layout_marginBottom = "15dp", gravity="center"},
            {TextView, text = "We have developed an excellent and easy-to-use radio application where you can listen to thousands of radio stations worldwide for free.", textSize = "16sp", layout_marginBottom = "15dp"},
            {TextView, id="tv_w_sub", text = "Key features of this application:", textSize = "16sp", layout_marginBottom = "10dp"},
            {TextView, text = "✅ Search and listen to thousands of live radio stations from around the globe.", textSize = "16sp", layout_marginBottom = "8dp"},
            {TextView, text = "✅ Easily select your favorite country using the country filter and listen to local channels.", textSize = "16sp", layout_marginBottom = "8dp"},
            {TextView, text = "✅ Long press on any station to save it directly to your Favorites list for quick access.", textSize = "16sp", layout_marginBottom = "8dp"},
            {TextView, text = "✅ New! View Watch History and Search History for quicker accessibility.", textSize = "16sp", layout_marginBottom = "8dp"},
            {TextView, text = "✅ Filter stations by their rating (Votes), trending status, or alphabetical order.", textSize = "16sp", layout_marginBottom = "15dp"},
            {TextView, text = "We hope you enjoy using our application. Please subscribe to our YouTube channel for updates and support.", textSize = "16sp", layout_marginBottom = "20dp"},
            {TextView, id="tv_w_dev", text = "Developed by Muhammad Hussain", textSize = "18sp", gravity = "center", textColor = "#0066CC", layout_marginBottom = "25dp"},
            {Button, text = "Start Exploring", layout_width = "fill", onClick = function()
                editor.putBoolean("isFirstRun", false).apply()
                welcomeDlg.dismiss()
                showThinhDialog()
            end}
        }
    }
    welcomeDlg = LuaDialog(this)
    welcomeDlg.setView(loadlayout(welcomeLayout))
    welcomeDlg.setCancelable(false)
    
    if tv_w_title then tv_w_title.setTypeface(Typeface.DEFAULT_BOLD) end
    if tv_w_sub then tv_w_sub.setTypeface(Typeface.DEFAULT_BOLD) end
    if tv_w_dev then tv_w_dev.setTypeface(Typeface.DEFAULT_BOLD) end
    
    welcomeDlg.show()
end

-- App Start Logic
if prefs.getBoolean("isFirstRun", true) then
    showWelcomeDialog()
else
    showThinhDialog()
end
