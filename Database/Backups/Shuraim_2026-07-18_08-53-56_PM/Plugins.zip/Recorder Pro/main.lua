local recDir = "/storage/emulated/0/recorder_pro/"
local tempDir = service.getFilesDir().getPath() .. "/temp_rec/"
local prefFile = "recorder_pro_prefs"

require "import"
import "android.app.AlertDialog"
import "android.view.WindowManager"
import "android.widget.*"
import "android.view.*"
import "android.media.MediaRecorder"
import "android.media.MediaPlayer"
import "java.io.*"
import "java.lang.String"
import "java.util.Date"
import "android.text.format.DateFormat"
import "android.os.Handler"
import "java.lang.Runnable"
import "android.content.Intent"
import "android.net.Uri"
import "android.content.Intent"
import "android.net.Uri"
import "android.graphics.Color"
import "android.media.session.MediaSession"
import "android.view.KeyEvent"
import "android.content.Context"
import "android.content.DialogInterface"

local prefs = service.getSharedPreferences(prefFile, Context.MODE_PRIVATE)
local recDir = prefs.getString("customPath", "/storage/emulated/0/recorder_pro/")
if not recDir:sub(-1) == "/" then recDir = recDir .. "/" end

local fRec = File(recDir)
if not fRec.exists() then fRec.mkdirs() end
local fTemp = File(tempDir)
if not fTemp.exists() then fTemp.mkdirs() end

_G.recorder = _G.recorder or nil
_G.segments = _G.segments or {}
_G.segDurations = _G.segDurations or {}
_G.lastSegStart = 0
_G.isRecording = _G.isRecording or false
_G.isPaused = _G.isPaused or false
_G.totalSeconds = _G.totalSeconds or 0
_G.mHandler = _G.mHandler or Handler()
_G.mPlayer = _G.mPlayer or MediaPlayer()
_G.clipPlayer = _G.clipPlayer or MediaPlayer()
_G.wasPlayingBeforeEnd = false

_G.audioQuality = prefs.getInt("audioQuality", 128000)
_G.autoSave = prefs.getBoolean("autoSave", false)

function formatDuration(ms)
  local total_seconds = math.floor(ms / 1000)
  local mins = math.floor(total_seconds / 60)
  local secs = total_seconds % 60
  return string.format("%02d:%02d", mins, secs)
end

_G.timerRunnable = _G.timerRunnable or Runnable{
  run=function()
    if _G.isRecording and not _G.isPaused then
      _G.totalSeconds = _G.totalSeconds + 1
      if _G.durationText then
        local mins = math.floor(_G.totalSeconds / 60)
        local secs = _G.totalSeconds % 60
        _G.durationText.setText(tostring("Duration: " .. string.format("%02d:%02d", mins, secs)))
      end
      _G.mHandler.postDelayed(_G.timerRunnable, 1000)
    end
  end
}

function startNewSegment(statusView)
  _G.lastSegStart = _G.totalSeconds
  local fileName = tempDir .. "seg_" .. (#_G.segments + 1) .. ".aac"
  _G.recorder = MediaRecorder()
  _G.recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
  _G.recorder.setOutputFormat(MediaRecorder.OutputFormat.AAC_ADTS)
  _G.recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
  _G.recorder.setAudioEncodingBitRate(_G.audioQuality)
  _G.recorder.setAudioSamplingRate(44100)
  _G.recorder.setOutputFile(fileName)
  _G.recorder.prepare()
  _G.recorder.start()
  table.insert(_G.segments, fileName)
  _G.isRecording = true
  _G.isPaused = false
  _G.durationText = statusView
  _G.mHandler.removeCallbacks(_G.timerRunnable)
  _G.mHandler.postDelayed(_G.timerRunnable, 1000)
end

function stopCurrentSegment()
  if _G.recorder then
    pcall(function() 
      _G.recorder.stop() 
      _G.recorder.reset()
      _G.recorder.release() 
    end)
    _G.recorder = nil
    table.insert(_G.segDurations, _G.totalSeconds - _G.lastSegStart)
  end
  _G.isPaused = true
  _G.mHandler.removeCallbacks(_G.timerRunnable)
end

function stopClipPlayer()
  if _G.clipPlayer then
    pcall(function()
      if _G.clipPlayer.isPlaying() then _G.clipPlayer.stop() end
      _G.clipPlayer.reset()
    end)
  end
end

function playClip(isFull)
  if #_G.segments == 0 then return end
  if _G.clipPlayer.isPlaying() then
    stopClipPlayer()
    service.speak("Stopped")
    return
  end
  stopClipPlayer()
  if isFull then
    local currentIndex = 1
    local function playNext()
      if currentIndex <= #_G.segments then
        local path = _G.segments[currentIndex]
        if File(path).exists() then
          _G.clipPlayer.reset()
          _G.clipPlayer.setDataSource(path)
          _G.clipPlayer.prepare()
          _G.clipPlayer.start()
          _G.clipPlayer.setOnCompletionListener(function(p)
            currentIndex = currentIndex + 1
            playNext()
          end)
        end
      else service.speak("Finished") end
    end
    playNext()
  else
    local path = _G.segments[#_G.segments]
    if File(path).exists() then
      _G.clipPlayer.reset()
      _G.clipPlayer.setDataSource(path)
      _G.clipPlayer.prepare()
      _G.clipPlayer.start()
      _G.clipPlayer.setOnCompletionListener(function(p) service.speak("Finished") end)
    end
  end
end

function showPlayerGUI(fileName, filePath, adFiles, adRec, refreshCallback)
  local context = service
  local layout = LinearLayout(context)
  layout.setOrientation(LinearLayout.VERTICAL)
  layout.setPadding(40, 40, 40, 40)
  _G.wasPlayingBeforeEnd = true
  local header = LinearLayout(context)
  local btnBack = Button(context).setText("Back")
  local txtTitle = TextView(context).setText(tostring(fileName)).setLayoutParams(LinearLayout.LayoutParams(0, -2, 1))
  txtTitle.setGravity(Gravity.CENTER)
  local btnMore = Button(context).setText("More")
  header.addView(btnBack)
  header.addView(txtTitle)
  header.addView(btnMore)
  layout.addView(header)
  local timeLayout = LinearLayout(context)
  timeLayout.setGravity(Gravity.CENTER)
  local txtCurrent = TextView(context).setText("00:00")
  local txtDivider = TextView(context).setText(" / ")
  local txtTotal = TextView(context).setText("00:00")
  timeLayout.addView(txtCurrent)
  timeLayout.addView(txtDivider)
  timeLayout.addView(txtTotal)
  layout.addView(timeLayout)
  local controls = LinearLayout(context)
  controls.setGravity(Gravity.CENTER)
  local btnRewind = Button(context).setText("Rewind 10 Seconds")
  local btnPlayPause = Button(context).setText("Pause")
  local btnForward = Button(context).setText("Fast Forward 10 Seconds")
  controls.addView(btnRewind)
  controls.addView(btnPlayPause)
  controls.addView(btnForward)
  layout.addView(controls)
  local playerDlg = AlertDialog.Builder(context).setView(layout).create()
  playerDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)

  local mSession = MediaSession(context, "CSR_Recorder_Session")
  mSession.setActive(true)
  
  local updateProgress
  updateProgress = function()
    if _G.mPlayer then
      local cp = _G.mPlayer.getCurrentPosition()
      local dur = _G.mPlayer.getDuration()
      txtCurrent.setText(tostring(formatDuration(cp)))
      txtTotal.setText(tostring(formatDuration(dur)))
      if _G.mPlayer.isPlaying() then
        _G.mHandler.postDelayed(Runnable{run=updateProgress}, 800)
      end
    end
  end

  local function togglePlayPause()
    local dur = _G.mPlayer.getDuration()
    local cp = _G.mPlayer.getCurrentPosition()
    if _G.mPlayer.isPlaying() then
      _G.mPlayer.pause()
      _G.wasPlayingBeforeEnd = false
      btnPlayPause.setText("Play")
      service.speak("Paused")
    else
      if cp >= dur - 1000 then _G.mPlayer.seekTo(0) end
      _G.mPlayer.start()
      _G.wasPlayingBeforeEnd = true
      btnPlayPause.setText("Pause")
      service.speak("Resumed")
      updateProgress()
    end
  end

  local function closeAndStop()
    mSession.setActive(false)
    mSession.release()
    if _G.mPlayer then
      pcall(function()
        if _G.mPlayer.isPlaying() then _G.mPlayer.stop() end
        _G.mPlayer.reset()
      end)
    end
    playerDlg.dismiss()
  end

  playerDlg.setOnDismissListener(function(d)
    mSession.setActive(false)
    mSession.release()
    if _G.mPlayer then
      pcall(function()
        if _G.mPlayer.isPlaying() then _G.mPlayer.stop() end
        _G.mPlayer.reset()
      end)
    end
  end)

  local callback = luajava.override(MediaSession.Callback, {
    onMediaButtonEvent = function(callbackInstance, intent)
      local keyEvent = intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT)
      if keyEvent and keyEvent.getAction() == KeyEvent.ACTION_DOWN then
        local keyCode = keyEvent.getKeyCode()
        if keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE or keyCode == KeyEvent.KEYCODE_HEADSETHOOK then
          togglePlayPause()
          return true
        end
      end
      return false
    end
  })
  mSession.setCallback(callback)

  _G.mPlayer.reset()
  _G.mPlayer.setDataSource(filePath)
  _G.mPlayer.prepare()
  _G.mPlayer.start()
  updateProgress()

  btnPlayPause.setOnClickListener(function(v)
    togglePlayPause()
  end)

  btnRewind.setOnClickListener(function(v)
    local pos = _G.mPlayer.getCurrentPosition() - 10000
    local target = math.max(pos, 0)
    _G.mPlayer.seekTo(target)
    service.speak("Rewind 10 seconds")
    if _G.wasPlayingBeforeEnd then
      _G.mPlayer.start()
      btnPlayPause.setText("Pause")
      updateProgress()
    else
      txtCurrent.setText(tostring(formatDuration(target)))
    end
  end)

  btnForward.setOnClickListener(function(v)
    local dur = _G.mPlayer.getDuration()
    local pos = _G.mPlayer.getCurrentPosition() + 10000
    if pos >= dur - 500 then
      _G.mPlayer.pause()
      _G.mPlayer.seekTo(dur - 1000)
      btnPlayPause.setText("Play")
      service.speak("Finished")
      txtCurrent.setText(tostring(formatDuration(dur)))
    else
      _G.mPlayer.seekTo(pos)
      service.speak("Forward 10 seconds")
      updateProgress()
    end
  end)

  btnBack.setOnClickListener(function(v)
    closeAndStop()
  end)

  btnMore.setOnClickListener(function(v)
    local options = {"Rename", "Delete", "Continue Recording"}
    local optDlg = AlertDialog.Builder(context).setTitle("Options").setItems(options, function(d, idx)
      if idx == 0 then
        local et = EditText(context)
        et.setText(tostring(fileName:gsub("%.mp3$", "")))
        local rDlg = AlertDialog.Builder(context).setTitle("Rename").setView(et)
        .setPositiveButton("OK", function()
          local newName = tostring(et.getText()) .. ".mp3"
          File(filePath).renameTo(File(recDir .. newName))
          closeAndStop()
          refreshCallback()
        end).setNegativeButton("Cancel", nil).create()
        rDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
        rDlg.show()
      elseif idx == 1 then
        local dDlg = AlertDialog.Builder(context).setTitle("Delete?").setMessage("Delete this file?")
        .setPositiveButton("Delete", function()
          File(filePath).delete()
          closeAndStop()
          refreshCallback()
          service.speak("Deleted")
        end).setNegativeButton("Cancel", nil).create()
        dDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
        dDlg.show()
      else
        closeAndStop()
        if adFiles then adFiles.dismiss() end
        if adRec then 
          adRec.dismiss()
          adRec = nil
        end
        for _, p in ipairs(_G.segments) do File(p).delete() end
        _G.segments = {}
        _G.segDurations = {}
        local targetPath = tempDir .. "seg_1.aac"
        local inStream = FileInputStream(File(filePath))
        local outStream = FileOutputStream(File(targetPath))
        outStream.write(inStream.readAllBytes())
        inStream.close()
        outStream.close()
        table.insert(_G.segments, targetPath)
        local mp = MediaPlayer()
        mp.setDataSource(filePath)
        mp.prepare()
        local durationMs = mp.getDuration()
        mp.release()
        local durationSec = math.floor(durationMs / 1000)
        table.insert(_G.segDurations, durationSec)
        _G.totalSeconds = durationSec
        _G.lastSegStart = durationSec
        _G.isRecording = true
        _G.isPaused = true
        showRecorderUI()
      end
    end).create()
    optDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
    optDlg.show()
  end)

  _G.mPlayer.setOnCompletionListener(function(p)
    btnPlayPause.setText("Play")
    local dur = _G.mPlayer.getDuration()
    txtCurrent.setText(tostring(formatDuration(dur)))
    service.speak("Finished")
    _G.mPlayer.pause()
    _G.mPlayer.seekTo(dur - 1000)
  end)
  playerDlg.show()
end

function showAbout(adRec)
  local context = service
  local layout = LinearLayout(context)
  layout.setOrientation(LinearLayout.VERTICAL)
  local scroll = ScrollView(context)
  local inner = LinearLayout(context)
  inner.setOrientation(LinearLayout.VERTICAL)
  inner.setPadding(40, 40, 40, 40)
  local function addInfoItem(text, isHeader)
    local tv = TextView(context)
    tv.setText(tostring(text))
    tv.setFocusable(true)
    tv.setPadding(0, 10, 0, 10)
    if isHeader then
      tv.setTextSize(20)
      tv.setTextColor(Color.parseColor("#2196F3"))
    else
      tv.setTextSize(16)
    end
    inner.addView(tv)
  end
  addInfoItem("Recorder Pro - Extension", true)
  addInfoItem("Developed by: Moosa Zaib", false)
  local btnContact = Button(context)
  btnContact.setText("Contact Moosa Zaib")
  btnContact.setOnClickListener(function(v)
    service.speak("Opening WhatsApp")
    local uri = Uri.parse("https://wa.me/923123608972")
    local intent = Intent(Intent.ACTION_VIEW, uri)
    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    service.startActivity(intent)
    if dlg then dlg.dismiss() end
    if adRec then adRec.dismiss() end
  end)
  inner.addView(btnContact)
  addInfoItem("-------------------------", false)
  addInfoItem("Overview:", true)
  addInfoItem("This extension is a powerful voice recording tool designed for CSR users. It allows seamless, high-quality audio capture with advanced management features.", false)
  addInfoItem("Key Logic & Features:", true)
  addInfoItem("1. Segmented Recording: To prevent data loss, the recorder captures audio in segments. You can pause and resume anytime without losing progress.", false)
  addInfoItem("2. Quality Control: Users can choose between Low, Standard, and High bitrates in settings to balance file size and audio clarity.", false)
  addInfoItem("3. Storage Directory: The extension automatically initializes and tracks recordings within the system environment, managing folder creation internally.", false)
  addInfoItem("4. Integrated Player: A full-featured media player with rewind, fast-forward, and media button support (Headset hooks).", false)
  addInfoItem("5. File Management: Easily rename, delete, continue recording, or batch-delete recordings directly within the app interface.", false)
  addInfoItem("How to Use:", true)
  addInfoItem("- Tap 'Start Recording' to begin. Use Pause/Resume to manage clips.", false)
  addInfoItem("- Use 'Play Last Clip' to review your latest segment before saving.", false)
  addInfoItem("- Tap 'Save & Finish' to merge all segments into a single MP3 file.", false)
  addInfoItem("- Access 'View All Recordings' to manage your saved library.", false)
  scroll.addView(inner)
  layout.addView(scroll)
  dlg = AlertDialog.Builder(context).setTitle("About").setView(layout).setPositiveButton("Close", nil).create()
  dlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
  dlg.show()
end

function showSettings()
  local context = service
  local layout = LinearLayout(context)
  layout.setOrientation(LinearLayout.VERTICAL)
  layout.setPadding(50, 40, 50, 40)

  layout.addView(TextView(context).setText("Audio Quality:"))
  local rgQ = RadioGroup(context)
  local rbL = RadioButton(context).setText("Low (64kbps)").setId(1)
  local rbS = RadioButton(context).setText("Standard (128kbps)").setId(2)
  local rbH = RadioButton(context).setText("High (256kbps)").setId(3)
  rgQ.addView(rbL) rgQ.addView(rbS) rgQ.addView(rbH)
  if _G.audioQuality == 64000 then rgQ.check(1)
  elseif _G.audioQuality == 256000 then rgQ.check(3)
  else rgQ.check(2) end
  layout.addView(rgQ)

  layout.addView(TextView(context).setText("Storage Path: " .. tostring(recDir)))

  local cbAuto = CheckBox(context).setText("Auto Save (No naming dialog)")
  cbAuto.setChecked(_G.autoSave)
  layout.addView(cbAuto)

  local btnClose = Button(context).setText("Save & Close")
  layout.addView(btnClose)

  local setDlg = AlertDialog.Builder(context).setTitle("Settings").setView(layout).create()
  setDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)

  btnClose.setOnClickListener(function(v)
    local qId = rgQ.getCheckedRadioButtonId()
    if qId == 1 then _G.audioQuality = 64000
    elseif qId == 3 then _G.audioQuality = 256000
    else _G.audioQuality = 128000 end

    _G.autoSave = cbAuto.isChecked()
    
    local edit = prefs.edit()
    edit.putInt("audioQuality", _G.audioQuality)
    edit.putBoolean("autoSave", _G.autoSave)
    edit.apply()

    service.speak("Settings Saved")
    setDlg.dismiss()
  end)
  setDlg.show()
end

function showSavedRecordings(adRec)
  local context = service
  local selectedFiles = {}
  local isMultiSelect = false
  local function loadFiles()
    local list = {}
    local files = File(recDir).listFiles()
    if files then
      for i=0, #files-1 do
        local name = files[i].getName()
        if files[i].isFile() and name:find("%.mp3$") then
          table.insert(list, name)
        end
      end
    end
    table.sort(list)
    return list
  end
  local fileList = loadFiles()
  local mainLayout = LinearLayout(context)
  mainLayout.setOrientation(LinearLayout.VERTICAL)
  mainLayout.setPadding(30, 30, 30, 30)
  local topBar = LinearLayout(context)
  local btnBack = Button(context).setText("Back")
  local txtHeader = TextView(context).setText("All Recordings").setLayoutParams(LinearLayout.LayoutParams(0, -2, 1))
  txtHeader.setGravity(Gravity.CENTER)
  txtHeader.setTextSize(18)
  topBar.addView(btnBack)
  topBar.addView(txtHeader)
  mainLayout.addView(topBar)
  local lv = ListView(context)
  local currentLayout = #fileList > 0 and android.R.layout.simple_list_item_1 or android.R.layout.simple_list_item_1
  local displayList = #fileList > 0 and fileList or {"No Recordings Found"}
  local adapter = ArrayAdapter(context, currentLayout, displayList)
  lv.setAdapter(adapter)
  mainLayout.addView(lv, LinearLayout.LayoutParams(-1, 0, 1))
  local btnDelete = Button(context).setText("DELETE SELECTED")
  btnDelete.setVisibility(View.GONE)
  btnDelete.setBackgroundColor(Color.RED)
  btnDelete.setTextColor(Color.WHITE)
  mainLayout.addView(btnDelete)
  local adFiles = AlertDialog.Builder(context).setView(mainLayout).create()
  adFiles.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
  local function updateSelectionUI()
    local count = 0
    for _ in pairs(selectedFiles) do count = count + 1 end
    if count > 0 then
      btnDelete.setVisibility(View.VISIBLE)
      btnDelete.setText("DELETE SELECTED (" .. count .. ")")
    else
      btnDelete.setVisibility(View.GONE)
      isMultiSelect = false
      local newAdapter = ArrayAdapter(context, android.R.layout.simple_list_item_1, fileList)
      lv.setAdapter(newAdapter)
      lv.setChoiceMode(ListView.CHOICE_MODE_NONE)
    end
  end
  lv.setOnItemClickListener(function(p, v, pos, id)
    if #fileList == 0 then return end
    local name = fileList[pos+1]
    if isMultiSelect then
      if selectedFiles[name] then
        selectedFiles[name] = nil
        lv.setItemChecked(pos, false)
      else
        selectedFiles[name] = true
        lv.setItemChecked(pos, true)
      end
      updateSelectionUI()
    else
      service.speak("Playing")
      showPlayerGUI(name, recDir .. name, adFiles, adRec, function()
        showSavedRecordings(adRec)
      end)
    end
  end)
  lv.setOnItemLongClickListener(function(p, v, pos, id)
    if #fileList == 0 then return false end
    if not isMultiSelect then
      isMultiSelect = true
      local multiAdapter = ArrayAdapter(context, android.R.layout.simple_list_item_multiple_choice, fileList)
      lv.setAdapter(multiAdapter)
      lv.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE)
      local name = fileList[pos+1]
      selectedFiles[name] = true
      lv.setItemChecked(pos, true)
      service.speak("Selection mode on")
      updateSelectionUI()
    end
    return true
  end)
  btnDelete.setOnClickListener(function(v)
    local dDlg = AlertDialog.Builder(context).setTitle("Delete Selected?").setMessage("Are you sure?")
    .setPositiveButton("Delete", function()
      for name, _ in pairs(selectedFiles) do File(recDir .. name).delete() end
      service.speak("Deleted")
      adFiles.dismiss()
      showSavedRecordings(adRec)
    end).setNegativeButton("Cancel", nil).create()
    dDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
    dDlg.show()
  end)
  btnBack.setOnClickListener(function(v) adFiles.dismiss() end)
  adFiles.show()
end

function performSave(customName)
  local name = customName or tostring(DateFormat.format("MMM dd yyyy 'at' hh mm a", Date()))
  local finalFile = File(recDir .. name .. ".mp3")
  local out = FileOutputStream(finalFile)
  for _, path in ipairs(_G.segments) do
    local f = File(path)
    if f.exists() then
      local fis = FileInputStream(f)
      out.write(fis.readAllBytes())
      fis.close()
      f.delete()
    end
  end
  out.close()
  _G.segments = {} _G.isRecording = false _G.totalSeconds = 0
  service.speak("Saved")
end

function showRecorderUI()
  local context = service
  local layout = LinearLayout(context)
  layout.setOrientation(LinearLayout.VERTICAL)
  layout.setPadding(50, 40, 50, 40)
  local btnToggle = Button(context)
  local timerTxt = TextView(context)
  timerTxt.setGravity(Gravity.CENTER)
  timerTxt.setPadding(0, 20, 0, 20)
  timerTxt.setTextSize(18)
  _G.durationText = timerTxt
  local btnPlayLast = Button(context)
  local btnPlayFull = Button(context)
  local btnDeleteLast = Button(context)
  local btnViewSaved = Button(context)
  local btnSettings = Button(context).setText("SETTINGS")
  local btnAbout = Button(context).setText("ABOUT")
  local btnSave = Button(context)
  local btnCancel = Button(context)
  local btnCloseEx = Button(context).setText("CLOSE")
  local function updateUIStates()
    if not _G.isRecording then btnToggle.setText("START RECORDING")
    elseif _G.isPaused then btnToggle.setText("RESUME RECORDING")
    else btnToggle.setText("PAUSE RECORDING") end
    local hasSegments = (#_G.segments > 0)
    timerTxt.setVisibility((_G.isRecording or hasSegments) and View.VISIBLE or View.GONE)
    local showActions = (_G.isPaused and hasSegments) and View.VISIBLE or View.GONE
    btnPlayLast.setVisibility(showActions)
    btnPlayFull.setVisibility(showActions)
    btnDeleteLast.setVisibility(showActions)
    btnSave.setVisibility(hasSegments and View.VISIBLE or View.GONE)
    btnCancel.setVisibility(hasSegments and View.VISIBLE or View.GONE)
    btnViewSaved.setVisibility((not _G.isRecording) and View.VISIBLE or View.GONE)
    btnSettings.setVisibility((not _G.isRecording) and View.VISIBLE or View.GONE)
    btnAbout.setVisibility((not _G.isRecording) and View.VISIBLE or View.GONE)
    btnCloseEx.setVisibility(View.VISIBLE)
    local mins = math.floor(_G.totalSeconds / 60)
    local secs = _G.totalSeconds % 60
    timerTxt.setText(tostring("Duration: " .. string.format("%02d:%02d", mins, secs)))
  end
  updateUIStates()
  layout.addView(btnToggle)
  layout.addView(timerTxt)
  btnPlayLast.setText("PLAY LAST CLIP")
  layout.addView(btnPlayLast)
  btnPlayFull.setText("PLAY FULL RECORDING")
  layout.addView(btnPlayFull)
  btnDeleteLast.setText("DELETE LAST CLIP")
  layout.addView(btnDeleteLast)
  btnViewSaved.setText("VIEW ALL RECORDINGS")
  layout.addView(btnViewSaved)
  layout.addView(btnSettings)
  layout.addView(btnAbout)
  btnSave.setText("SAVE & FINISH")
  layout.addView(btnSave)
  btnCancel.setText("CANCEL ALL")
  layout.addView(btnCancel)
  layout.addView(btnCloseEx)
  local adRec = AlertDialog.Builder(context).setTitle("Recorder Pro").setView(layout).create()
  adRec.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
  btnToggle.setOnClickListener(function(v)
    stopClipPlayer()
    if not _G.isRecording or _G.isPaused then 
      _G.mHandler.postDelayed(Runnable{run=function() 
        startNewSegment(timerTxt) 
        updateUIStates()
      end}, 500)
    else 
      stopCurrentSegment() 
      updateUIStates()
    end
  end)
  btnSettings.setOnClickListener(function(v) showSettings() end)
  btnAbout.setOnClickListener(function(v) showAbout(adRec) end)
  btnViewSaved.setOnClickListener(function(v) showSavedRecordings(adRec) end)
  btnCloseEx.setOnClickListener(function(v) adRec.dismiss() end)
  btnPlayLast.setOnClickListener(function(v) playClip(false) end)
  btnPlayFull.setOnClickListener(function(v) playClip(true) end)
  btnDeleteLast.setOnClickListener(function(v)
    stopClipPlayer()
    if #_G.segments > 0 then
      local f = File(_G.segments[#_G.segments])
      if f.exists() then f.delete() end
      table.remove(_G.segments)
      local lastDur = table.remove(_G.segDurations) or 0
      _G.totalSeconds = math.max(0, _G.totalSeconds - lastDur)
    end
    if #_G.segments == 0 then _G.isRecording = false _G.totalSeconds = 0 end
    updateUIStates()
  end)
  btnSave.setOnClickListener(function(v)
    stopClipPlayer()
    if _G.isRecording and not _G.isPaused then stopCurrentSegment() end
    if _G.autoSave then
      performSave()
      updateUIStates()
    else
      local editName = EditText(context)
      local defaultName = tostring(DateFormat.format("MMM dd yyyy 'at' hh mm a", Date()))
      editName.setText(tostring(defaultName))
      local sDlg = AlertDialog.Builder(context).setTitle("Save Recording").setView(editName)
      .setPositiveButton("Save", function()
        performSave(tostring(editName.getText()))
        updateUIStates()
      end).setNegativeButton("Back", nil).create()
      sDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
      sDlg.show()
    end
  end)
  btnCancel.setOnClickListener(function(v)
    stopCurrentSegment()
    stopClipPlayer()
    for _, p in ipairs(_G.segments) do File(p).delete() end
    _G.segments = {} _G.isRecording = false _G.totalSeconds = 0
    updateUIStates()
    adRec.dismiss()
    showRecorderUI()
  end)
  adRec.show()
end

showRecorderUI()