if service.click({
{"Voice message, Button. Double tap and hold to record, slide left to cancel recording, slide up to lock recording on. Release to send.$0",
"%Direct swipe up",
}
})
return true
end

if service.click({
{"send",
}
})
return true
end