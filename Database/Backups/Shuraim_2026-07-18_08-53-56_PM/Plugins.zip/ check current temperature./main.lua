require "import"
import "android.content.Intent"
import "android.net.Uri"
import "com.androlua.*"
this.speak("checking current temperature")
service.playSoundTick()
url="https://www.accuweather.com/"

Http.get(url,function(status, data)
if status == 200 then
--open(url)
temp = string.match(data, "%d+°")
service.speak(" current temperature is, " .. temp)
service.playSoundTick()
else
service.speak("no network available! please turn on the mobile data and try again!")
service.playSoundTick()
end
end)