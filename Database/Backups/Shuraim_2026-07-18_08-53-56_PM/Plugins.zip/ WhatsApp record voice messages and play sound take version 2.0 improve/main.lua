if service.click({
{"Send$001",
}
})
return true
end

if service.click({
{"<Voice message, Button*$50",
"%Direct swipe up$700",
"%service.playSoundTick()",}
})
return true
end