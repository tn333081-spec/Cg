require "import"
import "android.widget.*"
import "android.content.Intent"
import "android.speech.SpeechRecognizer"
import "android.speech.RecognitionListener"
import "android.speech.RecognizerIntent"
import "android.view.View"
import "android.content.Context"
import "android.os.Bundle"
import "com.androlua.Http"
import "cjson"

-- ==================== GROQ AI TYPER CONFIG ====================
local AI_PREFS = "digitalTyper"
local aiPrefs = service.getSharedPreferences(AI_PREFS, Context.MODE_PRIVATE)
local aiEditor = aiPrefs.edit()

-- Selected Mode (default: "conversion" or "intelligent")
local selectedMode = "conversion"

-- Groq Models
local GROQ_MODELS = {
    "llama-3.3-70b-versatile",
    "llama-3.1-8b-instant",
    "mixtral-8x7b-32768",
    "gemma2-9b-it",
    "llama-guard-3-8b"
}

function getGroqApiKey()
    return aiPrefs.getString("groq_apiKey", "")
end

function saveGroqApiKey(key)
    aiEditor.putString("groq_apiKey", key)
    aiEditor.commit()
end

function getGroqModel()
    return aiPrefs.getString("groq_model", "llama-3.3-70b-versatile")
end

function saveGroqModel(model)
    aiEditor.putString("groq_model", model)
    aiEditor.commit()
end

function isEmojiEnabled()
    return aiPrefs.getBoolean("emojiEnabled", false)
end

function setEmojiEnabled(enabled)
    aiEditor.putBoolean("emojiEnabled", enabled)
    aiEditor.commit()
end

function getSelectedMode()
    return aiPrefs.getString("selected_mode", "conversion")
end

function setSelectedMode(mode)
    aiEditor.putString("selected_mode", mode)
    aiEditor.commit()
    selectedMode = mode
end

function testGroqAPI(apiKey, model, callback)
    local url = "https://api.groq.com/openai/v1/models"
    local headers = {
        ["Authorization"] = "Bearer " .. apiKey
    }
    
    Http.get(url, headers, function(status, data)
        if status == 200 then
            callback(true, "API key is valid!")
        elseif status == 401 then
            callback(false, "Invalid API key")
        else
            callback(false, "Error: " .. status)
        end
    end)
end

function callGroqAPI(apiKey, model, systemPrompt, userPrompt, callback)
    local url = "https://api.groq.com/openai/v1/chat/completions"
    local headers = {
        ["Content-Type"] = "application/json",
        ["Authorization"] = "Bearer " .. apiKey,
    }
    
    local messages = {}
    if systemPrompt and systemPrompt ~= "" then
        table.insert(messages, {role = "system", content = systemPrompt})
    end
    table.insert(messages, {role = "user", content = userPrompt})
    
    local payload = {
        model = model,
        messages = messages,
        max_tokens = 1024,
        temperature = 0.7
    }
    
    Http.post(url, cjson.encode(payload), headers, function(status, data)
        if status == 200 then
            local ok, decoded = pcall(cjson.decode, data)
            if ok and decoded and decoded.choices and decoded.choices[1] then
                local text = decoded.choices[1].message.content
                if text then
                    callback(text, nil)
                else
                    callback(nil, "Invalid response from Groq")
                end
            else
                callback(nil, "Failed to parse Groq response")
            end
        elseif status == 401 then
            callback(nil, "Invalid API key. Please check your Groq API key")
        elseif status == 429 then
            callback(nil, "Rate limit exceeded. Please wait or check your quota")
        else
            callback(nil, "Groq Error: " .. status)
        end
    end)
end

-- Conversion Mode Prompt (Mix Language)
function getConversionModePrompt()
    return [[Task: Act as a multilingual text processor. Your goal is to convert incoming text into a "Mixed Script" format.
Rule 1: Keep the sentence structure and grammar in the original language (Urdu or Hindi).
Rule 2: Identify proper nouns (names, places), technical terms, and common English loanwords.
Rule 3: Convert only those identified words into English spellings (Latin alphabet). All other words must remain in Urdu (Persian-Arabic script) or Hindi (Devanagari script).
Rule 4: Do not translate the entire sentence; only change the script of specific words.
Rule 5: Return only the converted text without any extra explanation.

Examples:
Input: میرا نام ثابر جمیل ہے۔
Output: میرا نام Sabir Jamil ہے۔

Input: میں پاکستان میں رہتا ہوں۔
Output: میں Pakistan میں رہتا ہوں۔

Input: میں ایک سٹوڈنٹ ہوں اور محنت کرتا ہوں۔
Output: میں ایک Student ہوں اور محنت کرتا ہوں۔

Input: آج کا موسم بہت اچھا ہے۔
Output: آج کا Weather بہت اچھا ہے۔

Input: مجھے اپنی سکلز کو بہتر بنانا ہے۔
Output: مجھے اپنی Skills کو بہتر بنانا ہے۔]]
end

-- Intelligent Writer Mode Prompt (Enhancement)
function getIntelligentWriterPrompt()
    return [[Task: Act as an AI Writing Assistant and Content Improver.
Goal: Enhance the user's input text to make it more professional, articulate, and engaging while preserving the original meaning.
Instructions: Correct any grammatical errors, improve vocabulary choices, and refine the tone. Ensure the output is natural and flows better than the original input. Provide only the enhanced version of the text without any extra explanation.

Examples:
Original: میں کل کام پر نہیں آؤں گا۔
Enhanced: معذرت چاہتا ہوں، میں کچھ ناگزیر وجوہات کی بنا پر کل کام پر حاضر نہیں ہو سکوں گا۔

Original: یہ ایپ بہت اچھی ہے۔
Enhanced: یہ ایپلیکیشن انتہائی کارآمد ہے اور اس کا استعمال بہت ہموار ہے۔

Original: مجھے مدد چاہیے اس کوڈ میں۔
Enhanced: کیا آپ اس کوڈ کو درست کرنے میں میری معاونت کر سکتے ہیں؟

Original: کھانا بہت مزے کا تھا۔
Enhanced: کھانے کا ذائقہ انتہائی لذیذ اور لاجواب تھا۔

Original: میں فارغ ہو کر کال کروں گا۔
Enhanced: میں اپنی مصروفیات سے فارغ ہوتے ہی آپ سے بذریعہ فون رابطہ کروں گا۔]]
end

function processWithAI(spokenText, callback)
    local apiKey = getGroqApiKey()
    
    if not apiKey or apiKey == "" then
        service.speak("Please set Groq API key in AI Engine settings first")
        callback(spokenText)
        return
    end
    
    local model = getGroqModel()
    local mode = getSelectedMode()
    local systemPrompt = ""
    
    if mode == "conversion" then
        systemPrompt = getConversionModePrompt()
        service.speak("Conversion Mode active")
    else
        systemPrompt = getIntelligentWriterPrompt()
        service.speak("Intelligent Writer Mode active")
    end
    
    callGroqAPI(apiKey, model, systemPrompt, spokenText, function(result, error)
        if error then
            service.speak(error)
            callback(spokenText)
        else
            callback(result)
        end
    end)
end

function showModesDialog(parentDlg)
    local dlg = LuaDialog(service)
    dlg.setTitle("Select Typing Mode")
    dlg.setCancelable(true)
    
    local layout = {
        LinearLayout;
        orientation = "vertical";
        padding = "30dp";
        {
            Button;
            text = "Conversion Mode (Mix Language)";
            textSize = "16sp";
            layout_width = "fill";
            layout_marginBottom = "15dp";
            onClick = function()
                setSelectedMode("conversion")
                service.speak("Conversion Mode selected")
                dlg.dismiss()
                if parentDlg then
                    parentDlg.show()
                end
            end;
        };
        {
            Button;
            text = "Intelligent Writer Mode (Enhancement)";
            textSize = "16sp";
            layout_width = "fill";
            layout_marginBottom = "15dp";
            onClick = function()
                setSelectedMode("intelligent")
                service.speak("Intelligent Writer Mode selected")
                dlg.dismiss()
                if parentDlg then
                    parentDlg.show()
                end
            end;
        };
        {
            Button;
            text = "← GO BACK";
            textSize = "16sp";
            layout_width = "fill";
            backgroundColor = "#FF4444";
            textColor = "#FFFFFF";
            onClick = function()
                dlg.dismiss()
                if parentDlg then
                    parentDlg.show()
                end
            end;
        };
    }
    
    dlg.setView(loadlayout(layout))
    dlg.show()
end

function showAISettingsDialog(mainDlg)
    local dlg = LuaDialog(service)
    dlg.setTitle("Groq AI Settings")
    dlg.setCancelable(true)
    
    local mainLayout = LinearLayout(service)
    mainLayout.setOrientation(1)
    mainLayout.setPadding(30, 20, 30, 20)
    
    local infoText = TextView(service)
    infoText.setText("Get API key from: https://console.groq.com/keys")
    infoText.setTextSize(12)
    infoText.setTextColor(0xFFAAAAAA)
    infoText.setPadding(0, 0, 0, 20)
    mainLayout.addView(infoText)
    
    local keyLabel = TextView(service)
    keyLabel.setText("Groq API Key:")
    keyLabel.setTextSize(14)
    keyLabel.setTextColor(0xFFFFFFFF)
    keyLabel.setPadding(0, 0, 0, 10)
    mainLayout.addView(keyLabel)
    
    local keyInput = EditText(service)
    keyInput.setHint("Enter Groq API Key")
    local savedKey = getGroqApiKey()
    if savedKey and savedKey ~= "" then
        keyInput.setText(savedKey)
    end
    keyInput.setTextSize(14)
    keyInput.setPadding(20, 15, 20, 15)
    keyInput.setBackgroundColor(0xFF222222)
    keyInput.setInputType(129)
    local keyParams = LinearLayout.LayoutParams(-1, -2)
    keyParams.setMargins(0, 0, 0, 15)
    keyInput.setLayoutParams(keyParams)
    mainLayout.addView(keyInput)
    
    local modelLabel = TextView(service)
    modelLabel.setText("Select Model:")
    modelLabel.setTextSize(14)
    modelLabel.setTextColor(0xFFFFFFFF)
    modelLabel.setPadding(0, 0, 0, 10)
    mainLayout.addView(modelLabel)
    
    local modelSpinner = Spinner(service)
    local adapter = ArrayAdapter(service, android.R.layout.simple_spinner_item, GROQ_MODELS)
    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
    modelSpinner.setAdapter(adapter)
    
    local currentModel = getGroqModel()
    for i = 1, #GROQ_MODELS do
        if GROQ_MODELS[i] == currentModel then
            modelSpinner.setSelection(i - 1)
            break
        end
    end
    local spinnerParams = LinearLayout.LayoutParams(-1, -2)
    spinnerParams.setMargins(0, 0, 0, 15)
    modelSpinner.setLayoutParams(spinnerParams)
    mainLayout.addView(modelSpinner)
    
    local buttonRow = LinearLayout(service)
    buttonRow.setOrientation(0)
    buttonRow.setPadding(0, 0, 0, 0)
    
    local testBtn = Button(service)
    testBtn.setText("TEST API KEY")
    testBtn.setTextSize(12)
    testBtn.setBackgroundColor(0xFFFF9800)
    testBtn.setPadding(0, 15, 0, 15)
    testBtn.setLayoutParams(LinearLayout.LayoutParams(0, -2, 1))
    local testParams = testBtn.getLayoutParams()
    testParams.setMargins(0, 0, 5, 0)
    testBtn.setLayoutParams(testParams)
    
    local saveBtn = Button(service)
    saveBtn.setText("SAVE")
    saveBtn.setTextSize(12)
    saveBtn.setBackgroundColor(0xFF4CAF50)
    saveBtn.setPadding(0, 15, 0, 15)
    saveBtn.setLayoutParams(LinearLayout.LayoutParams(0, -2, 1))
    local saveParams = saveBtn.getLayoutParams()
    saveParams.setMargins(5, 0, 5, 0)
    saveBtn.setLayoutParams(saveParams)
    
    local backBtn = Button(service)
    backBtn.setText("GO BACK")
    backBtn.setTextSize(12)
    backBtn.setBackgroundColor(0xFFF44336)
    backBtn.setPadding(0, 15, 0, 15)
    backBtn.setLayoutParams(LinearLayout.LayoutParams(0, -2, 1))
    local backParams = backBtn.getLayoutParams()
    backParams.setMargins(5, 0, 0, 0)
    backBtn.setLayoutParams(backParams)
    
    buttonRow.addView(testBtn)
    buttonRow.addView(saveBtn)
    buttonRow.addView(backBtn)
    mainLayout.addView(buttonRow)
    
    testBtn.setOnClickListener(function()
        local testKey = keyInput.getText().toString()
        local testModel = GROQ_MODELS[modelSpinner.getSelectedItemPosition() + 1]
        
        if not testKey or testKey == "" then
            service.speak("Enter API key first")
            return
        end
        
        testBtn.setText("Testing...")
        testBtn.setEnabled(false)
        
        testGroqAPI(testKey, testModel, function(success, message)
            testBtn.setText("TEST API KEY")
            testBtn.setEnabled(true)
            if success then
                service.speak("Success: " .. message)
            else
                service.speak("Failed: " .. message)
            end
        end)
    end)
    
    saveBtn.setOnClickListener(function()
        local newKey = keyInput.getText().toString()
        local newModel = GROQ_MODELS[modelSpinner.getSelectedItemPosition() + 1]
        
        if newKey and newKey ~= "" then
            saveGroqApiKey(newKey)
        end
        if newModel then
            saveGroqModel(newModel)
        end
        
        service.speak("Settings saved")
        dlg.dismiss()
        if mainDlg then
            mainDlg.show()
        end
    end)
    
    backBtn.setOnClickListener(function()
        dlg.dismiss()
        if mainDlg then
            mainDlg.show()
        end
    end)
    
    local scrollView = ScrollView(service)
    scrollView.addView(mainLayout)
    dlg.setView(scrollView)
    dlg.show()
end

local dictFile = os.getenv("EXTERNAL_STORAGE") .. "/groq_ai_typer_dict.dat"
local changeTable = {}

function loadDictionary()
    local f = io.open(dictFile, "r")
    if f then
        local content = f:read("*all")
        f:close()
        if content and content ~= "" then
            local ok, result = pcall(cjson.decode, content)
            if ok and type(result) == "table" then
                changeTable = result
            else
                changeTable = {}
            end
        end
    end
end

function saveDictionary()
    local f = io.open(dictFile, "w")
    if f then
        f:write(cjson.encode(changeTable))
        f:close()
    end
end

function addToDictionary(wrongWord, correctWord)
    if wrongWord and correctWord and wrongWord ~= "" and correctWord ~= "" then
        changeTable[wrongWord] = correctWord
        saveDictionary()
        return true
    end
    return false
end

function getSavedLanguage()
    local langFile = os.getenv("EXTERNAL_STORAGE") .. "/groq_ai_typer_lang.dat"
    local f = io.open(langFile, "r")
    if f then
        local content = f:read("*all")
        f:close()
        if content and content ~= "" then
            return content:gsub("%s+", "")
        end
    end
    return "ur-PK"
end

function saveLanguage(code)
    local langFile = os.getenv("EXTERNAL_STORAGE") .. "/groq_ai_typer_lang.dat"
    local f = io.open(langFile, "w")
    if f then
        f:write(code)
        f:close()
        service.speak("Language saved")
    end
end

local languageItems = {
    "Urdu (Pakistan)",
    "English (US)",
    "English (UK)",
    "Hindi (India)",
    "Arabic (Saudi Arabia)",
    "Spanish (Spain)",
    "French (France)",
    "German (Germany)",
    "Chinese (Mandarin)",
    "Japanese (Japan)",
    "Turkish (Turkey)",
    "Russian (Russia)",
    "Portuguese (Brazil)",
    "Italian (Italy)",
    "Dutch (Netherlands)"
}

local languageCodes = {
    "ur-PK",
    "en-US",
    "en-GB",
    "hi-IN",
    "ar-SA",
    "es-ES",
    "fr-FR",
    "de-DE",
    "zh-CN",
    "ja-JP",
    "tr-TR",
    "ru-RU",
    "pt-BR",
    "it-IT",
    "nl-NL"
}

function showDictionaryDialog()
    local dlg = LuaDialog(service)
    dlg.setTitle("Add to Dictionary")
    local layout = {
        LinearLayout;
        orientation = "vertical";
        padding = "20dp";
        {
            EditText;
            id = "wrongWord";
            hint = "Wrong word (غلط لفظ)";
            textSize = "16sp";
            layout_width = "fill";
            layout_marginBottom = "15dp";
        };
        {
            EditText;
            id = "correctWord";
            hint = "Correct word (صحیح لفظ)";
            textSize = "16sp";
            layout_width = "fill";
            layout_marginBottom = "15dp";
        };
        {
            Button;
            text = "Add to Dictionary";
            textSize = "16sp";
            layout_width = "fill";
            onClick = function()
                local wrong = wrongWord.getText().toString()
                local correct = correctWord.getText().toString()
                if wrong ~= "" and correct ~= "" then
                    addToDictionary(wrong, correct)
                    service.speak("Added: " .. wrong .. " → " .. correct)
                    dlg.dismiss()
                else
                    service.speak("Both fields required")
                end
            end;
        };
    }
    dlg.setView(loadlayout(layout))
    dlg.show()
end

function showDictionaryList()
    if next(changeTable) == nil then
        service.speak("Dictionary is empty")
        return
    end
    local items = {}
    for wrong, correct in pairs(changeTable) do
        table.insert(items, wrong .. " → " .. correct)
    end
    local listDlg = LuaDialog(service)
    listDlg.setTitle("My Dictionary")
    local layout = {
        LinearLayout;
        orientation = "vertical";
        padding = "10dp";
        {
            ListView;
            id = "list";
            layout_width = "fill";
            layout_height = "400dp";
        };
        {
            Button;
            text = "Close";
            layout_width = "fill";
            onClick = function()
                listDlg.dismiss()
            end;
        };
    }
    local view = loadlayout(layout)
    list.setAdapter(ArrayAdapter(service, android.R.layout.simple_list_item_1, items))
    listDlg.setView(view)
    listDlg.show()
end

local editText = service.getEditText()

function startVoiceTyping(langCode)
    local context = service.getApplicationContext()
    local speechRec = SpeechRecognizer.createSpeechRecognizer(context)
    
    local listener = RecognitionListener {
        onResults = function(results)
            local resultsArray = results.getParcelableArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if resultsArray and resultsArray.size() > 0 then
                local spokenText = resultsArray.get(0)
                for wrongWord, correctWord in pairs(changeTable) do
                    local pattern = "(%f[%a])" .. wrongWord:gsub("(%W)", "%%%1") .. "(%f[%W])"
                    spokenText = spokenText:gsub(pattern, function(prefix, suffix)
                        return prefix .. correctWord .. suffix
                    end)
                    if spokenText:lower() == wrongWord:lower() then
                        spokenText = correctWord
                    end
                end
                spokenText = spokenText:gsub("%s([?,!])", "%1")
                if not spokenText:match("[.?!,.]$") then
                    spokenText = spokenText .. ". "
                end
                
                local apiKey = getGroqApiKey()
                if apiKey and apiKey ~= "" then
                    service.speak("AI processing...")
                    processWithAI(spokenText, function(enhancedText)
                        service.insertText(editText, enhancedText)
                        service.speak(enhancedText)
                    end)
                else
                    service.insertText(editText, spokenText)
                    service.speak(spokenText)
                end
            end
            speechRec.destroy()
        end,
        onError = function(errorCode)
            service.speak("I did not understand your message")
            speechRec.destroy()
            return false
        end,
    }
    
    local intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, langCode)
    speechRec.setRecognitionListener(listener)
    speechRec.startListening(intent)
end

loadDictionary()

-- Set default mode if not set
if getSelectedMode() == "" then
    setSelectedMode("conversion")
end

if editText then
    startVoiceTyping(getSavedLanguage())
else
    local dlg = LuaDialog(service)
    dlg.setTitle("Groq AI Typer")
    
    local emojiState = isEmojiEnabled()
    local emojiButtonText = emojiState and "Emoji: ON" or "Emoji: OFF"
    local currentModeText = (getSelectedMode() == "conversion") and "Current: Conversion Mode" or "Current: Intelligent Mode"
    
    local layout = {
        LinearLayout;
        orientation = "vertical";
        padding = "30dp";
        {
            Button;
            text = "Developer: Sabir Jamil";
            textSize = "16sp";
            layout_width = "fill";
            layout_marginBottom = "10dp";
        };
        {
            Button;
            text = "Select Language For Typing";
            textSize = "16sp";
            layout_width = "fill";
            layout_marginBottom = "10dp";
            onClick = function()
                local listDlg = LuaDialog(service)
                listDlg.setTitle("Select Language")
                local list = ListView(service)
                list.setAdapter(ArrayAdapter(service, android.R.layout.simple_list_item_1, languageItems))
                list.onItemClick = function(l, v, p, i)
                    local selectedCode = languageCodes[p+1]
                    local selectedItem = languageItems[p+1]
                    saveLanguage(selectedCode)
                    listDlg.dismiss()
                    service.speak("Language selected: " .. selectedItem)
                end
                listDlg.setView(list)
                listDlg.show()
            end;
        };
        {
            TextView;
            text = currentModeText;
            textSize = "12sp";
            textColor = "#FFAAAAAA";
            layout_width = "fill";
            gravity = "center";
            layout_marginBottom = "5dp";
        };
        {
            Button;
            text = "MODES";
            textSize = "16sp";
            layout_width = "fill";
            layout_marginBottom = "10dp";
            backgroundColor = "#FF5722";
            textColor = "#FFFFFF";
            onClick = function()
                dlg.dismiss()
                showModesDialog(dlg)
            end;
        };
        {
            Button;
            text = "Dictionary (Add Words)";
            textSize = "16sp";
            layout_width = "fill";
            layout_marginBottom = "10dp";
            onClick = function()
                showDictionaryDialog()
            end;
        };
        {
            Button;
            text = "View Dictionary";
            textSize = "16sp";
            layout_width = "fill";
            layout_marginBottom = "10dp";
            onClick = function()
                showDictionaryList()
            end;
        };
        {
            Button;
            id = "emojiToggle";
            text = emojiButtonText;
            textSize = "16sp";
            layout_width = "fill";
            layout_marginBottom = "10dp";
            onClick = function()
                local newState = not isEmojiEnabled()
                setEmojiEnabled(newState)
                local newText = newState and "Emoji: ON" or "Emoji: OFF"
                emojiToggle.setText(newText)
                service.speak("Emoji " .. (newState and "enabled" or "disabled"))
            end;
        };
        {
            Button;
            text = "AI Engine Settings";
            textSize = "16sp";
            layout_width = "fill";
            layout_marginBottom = "10dp";
            onClick = function()
                dlg.dismiss()
                showAISettingsDialog(dlg)
            end;
        };
        {
            Button;
            text = "Exit";
            textSize = "16sp";
            layout_width = "fill";
            onClick = function()
                dlg.dismiss()
            end;
        };
    }
    
    dlg.setView(loadlayout(layout))
    dlg.show()
end