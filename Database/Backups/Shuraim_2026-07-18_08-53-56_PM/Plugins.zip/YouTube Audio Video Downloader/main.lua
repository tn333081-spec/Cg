require "import"
import "android.widget.*"
import "android.view.*"
import "android.graphics.Typeface"
import "android.content.Context"
import "android.net.Uri"
import "android.app.DownloadManager"
import "android.os.Environment"
import "com.androlua.Http"
import "android.app.AlertDialog"
import "com.androlua.LuaDialog"

-- فیڈ بک اب انگلش میں
local function showToast(msg)
    if service then
        service.speak(msg)
    end
end

-- ڈاؤن لوڈ فنکشن (اب فیڈ بک انگلش میں)
local function downloadFile(url, filename)
    if not url or url == "" then
        showToast("Invalid URL")
        return
    end
    local safeName = filename:gsub('[\\/:"*?<>|]', "_")
    local request = DownloadManager.Request(Uri.parse(url))
    request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE)
    request.setTitle("Downloading: " .. safeName)
    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, safeName)
    local manager = service.getSystemService(Context.DOWNLOAD_SERVICE)
    manager.enqueue(request)
    showToast("Download started")
end

local function aboutAndSupport(mainDialogToClose)
    local help_views = {}
    local help_layout = {
        LinearLayout;
        orientation = "vertical";
        padding = "16dp";
        layout_width = "fill";
        layout_height = "wrap";
        {
            TextView;
            text = "Universal Social Media Video Downloader - Download videos from YouTube, Facebook, TikTok, Instagram and more platforms directly to your device.\n\nFeatures: Supports multiple formats including MP3 audio extraction, high quality video downloads, fast processing, and direct save to Downloads folder";
            textSize = 14;
            textColor = "#666666";
            gravity = "left";
            paddingBottom = "20dp";
        };
        {
            TextView;
            text = "Join Our Community";
            textSize = 16;
            textColor = "#000000";
            gravity = "center";
            paddingBottom = "10dp";
        };
        {
            ScrollView;
            layout_width = "fill";
            layout_height = "wrap_content";
            {
                LinearLayout;
                orientation = "vertical";
                layout_width = "fill";
                layout_height = "wrap_content";
                gravity = "center";
                layout_marginTop = "5dp";
                {
                    Button;
                    id = "joinWhatsAppGroupButton";
                    text = "JOIN WHATSAPP GROUP";
                    layout_width = "fill";
                    layout_height = "wrap_content";
                    layout_margin = "2dp";
                    textSize = "12sp";
                    padding = "8dp";
                    backgroundColor = "#25D366";
                    textColor = "#FFFFFF";
                };
                {
                    Button;
                    id = "joinYouTubeChannelButton";
                    text = "JOIN YOUTUBE CHANNEL";
                    layout_width = "fill";
                    layout_height = "wrap_content";
                    layout_margin = "2dp";
                    textSize = "12sp";
                    padding = "8dp";
                    backgroundColor = "#FF0000";
                    textColor = "#FFFFFF";
                };
                {
                    Button;
                    id = "joinTelegramChannelButton";
                    text = "JOIN TELEGRAM CHANNEL";
                    layout_width = "fill";
                    layout_height = "wrap_content";
                    layout_margin = "2dp";
                    textSize = "12sp";
                    padding = "8dp";
                    backgroundColor = "#2196F3";
                    textColor = "#FFFFFF";
                };
                {
                    Button;
                    id = "goBackButton";
                    text = "GO BACK";
                    layout_width = "fill";
                    layout_height = "wrap_content";
                    layout_margin = "2dp";
                    textSize = "12sp";
                    padding = "8dp";
                    backgroundColor = "#9E9E9E";
                    textColor = "#FFFFFF";
                };
            };
        };
    }
    local help_dialog = LuaDialog(service)
    help_dialog.setTitle("Developer: Sabir Jamil")
    help_dialog.setView(loadlayout(help_layout, help_views))
    help_dialog.setCancelable(true)
    
    help_views.joinWhatsAppGroupButton.onClick = function()
        service.speak("Opening WhatsApp Group")
        help_dialog.dismiss()
        pcall(function()
            local message = "Assalam%20o%20Alaikum.%20I%20hope%20you%20are%20doing%20well.%20I%20would%20like%20to%20join%20your%20WhatsApp%20group.%20Kindly%20share%20the%20instructions.%20group%20rules%20and%20regulations.%20Thank%20you.%20so%20much"
            local url = "https://wa.me/923486623399?text=" .. message
            local intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            service.startActivity(intent)
        end)
    end
    
    help_views.joinYouTubeChannelButton.onClick = function()
        service.speak("Opening YouTube Channel")
        help_dialog.dismiss()
        pcall(function()
            local url = "https://www.youtube.com/@TechForVI"
            local intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            service.startActivity(intent)
        end)
    end
    
    help_views.joinTelegramChannelButton.onClick = function()
        service.speak("Opening Telegram Channel")
        help_dialog.dismiss()
        pcall(function()
            local url = "https://t.me/TechForVI"
            local intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            intent.setPackage("org.telegram.messenger")
            service.startActivity(intent)
        end)
    end
    
    help_views.goBackButton.onClick = function()
        help_dialog.dismiss()
    end
    
    help_dialog.show()
end

local layout = {
    LinearLayout,
    orientation = "vertical",
    layout_width = "fill",
    layout_height = "fill",
    padding = "16dp",
    {
        TextView,
        text = "All downloader platforms are fully supported by soffiapis.",
        textSize = "18sp",
        textColor = "#FF0000",
        gravity = "center",
        layout_marginBottom = "8dp",
        typeface = Typeface.DEFAULT_BOLD,
    },
    {
        EditText,
        id = "urlInput",
        hint = "Enter YouTube, Facebook, TikTok, Instagram video link...",
        layout_width = "fill",
        singleLine = true,
    },
    {
        Button,
        id = "btnCheck",
        text = "Process Video",
        layout_width = "fill",
        layout_marginTop = "8dp",
    },
    {
        ProgressBar,
        id = "progBar",
        layout_width = "fill",
        style = "android:attr/progressBarStyleHorizontal",
        visibility = View.GONE,
    },
    {
        ScrollView,
        layout_width = "fill",
        layout_height = "0",
        layout_weight = "1",
        {
            LinearLayout,
            id = "resultLayout",
            orientation = "vertical",
            layout_width = "fill",
            visibility = View.GONE,
            {
                TextView,
                id = "videoTitle",
                textSize = "14sp",
                typeface = Typeface.DEFAULT_BOLD,
            },
            {
                LinearLayout,
                id = "downloadContainer",
                orientation = "vertical",
                layout_width = "fill",
            }
        }
    },
    {
        LinearLayout,
        layout_width = "fill",
        orientation = "horizontal",
        gravity = "center",
        {
            Button,
            id = "btnAbout",
            text = "ABOUT & SUPPORT",
            layout_width = "0dp",
            layout_weight = "1",
            backgroundColor = "#607D8B",
            textColor = "#FFFFFF",
            layout_marginRight = "5dp",
        },
        {
            Button,
            id = "btnExit",
            text = "EXIT",
            layout_width = "0dp",
            layout_weight = "1",
            backgroundColor = "#D32F2F",
            textColor = "#FFFFFF",
            layout_marginLeft = "5dp",
        }
    }
}

local builder = AlertDialog.Builder(service)
local view = loadlayout(layout)
builder.setView(view)
builder.setCancelable(false)
local window = builder.create()
window.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
window.show()

btnCheck.onClick = function()
    local url = urlInput.getText().toString():gsub("%s+", "")
    if url == "" then
        showToast("Please enter video link from YouTube, Facebook, TikTok, or Instagram!")
        return
    end
    
    if url:find("youtu.be/") then
        local id = url:match("youtu.be/([^%?&]+)")
        if id then
            url = "https://www.youtube.com/watch?v=" .. id
        end
    end
    
    progBar.setVisibility(View.VISIBLE)
    resultLayout.setVisibility(View.GONE)
    downloadContainer.removeAllViews()
    
    Http.get("https://apis.scraper.web.id/ol?url=" .. url, nil, "utf8", nil, function(code, body)
        progBar.setVisibility(View.GONE)
        if code ~= 200 then
            showToast("Server error: " .. code)
            return
        end
        local json = require "cjson"
        local ok, data = pcall(function() return json.decode(body) end)
        if ok and data and data.status == true and data.data and data.data.result then
            local res = data.data.result
            resultLayout.setVisibility(View.VISIBLE)
            videoTitle.setText(res.title or "Untitled Video")
            downloadContainer.removeAllViews()
            
            if res.medias and #res.medias > 0 then
                local buttonCount = 0
                for _, media in ipairs(res.medias) do
                    if media.url then
                        buttonCount = buttonCount + 1
                        local btn = Button(service)
                        local lp = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        )
                        lp.setMargins(0, 15, 0, 0)
                        btn.setLayoutParams(lp)
                        
                        local extInfo = (media.ext or "mp4"):upper()
                        local qualityInfo = media.label or media.quality or "Unknown Quality"
                        local typeInfo = (media.type or "video"):upper()
                        
                        local isAudio = false
                        if media.type == "audio" or extInfo == "MP3" or (qualityInfo and qualityInfo:lower():find("mp3")) then
                            isAudio = true
                        end
                        
                        local extraInfo = ""
                        if media.clen then
                            local sizeMb = tonumber(media.clen) / (1024 * 1024)
                            extraInfo = string.format(" (~%.2f MB)", sizeMb)
                        elseif media.bitrate then
                            extraInfo = string.format(" (%dkbps)", math.floor(media.bitrate / 1000))
                        end
                        
                        local displayText = ""
                        if isAudio and extInfo == "MP3" then
                            displayText = string.format("[AUDIO] MP3 - %s%s", qualityInfo, extraInfo)
                        elseif isAudio then
                            displayText = string.format("[AUDIO] %s - %s%s", extInfo, qualityInfo, extraInfo)
                        else
                            displayText = string.format("[VIDEO] %s - %s%s", extInfo, qualityInfo, extraInfo)
                        end
                        
                        btn.setText(displayText)
                        
                        if extInfo == "MP3" then
                            btn.setBackgroundColor(0xFFFF9800)
                        elseif isAudio then
                            btn.setBackgroundColor(0xFF009688)
                        else
                            btn.setBackgroundColor(0xFF2196F3)
                        end
                        
                        btn.setTextColor(0xFFFFFFFF)
                        btn.onClick = function()
                            showToast("Downloading: " .. qualityInfo .. " (" .. extInfo .. ")")
                            local fileExt = media.ext or (isAudio and "mp3" or "mp4")
                            local fileName = (res.title or "video") .. "_" .. qualityInfo
                            fileName = fileName:gsub("%s+", "_")
                            downloadFile(media.url, fileName .. "." .. fileExt)
                        end
                        downloadContainer.addView(btn)
                    end
                end
                if buttonCount > 0 then
                    showToast("Successfully loaded " .. buttonCount .. " download options (including MP3 if available).")
                else
                    showToast("No download links available to display.")
                end
            else
                showToast("Media array empty from server")
            end
        else
            showToast("Failed to process data or API structure changed")
        end
    end)
end

btnAbout.onClick = function()
    window.dismiss()
    aboutAndSupport(window)
end

btnExit.onClick = function()
    window.dismiss()
end

