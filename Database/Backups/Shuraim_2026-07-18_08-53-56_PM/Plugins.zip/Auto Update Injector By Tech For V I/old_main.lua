require "import"
import "com.androlua.Http"
import "android.widget.Toast"
import "java.io.File"

local scriptUrl = "https://raw.githubusercontent.com/TechForVI/Auto-Update-Injector/main/Auto%20Update%20Injector%20By%20Tech%20For%20V%20I"
local scriptPath = service.getLuaDir() .. "/bootloaded_script.lua"

Http.get(scriptUrl, function(code, content)
    if code == 200 and content then
        local file = io.open(scriptPath, "w")
        if file then
            file:write(content)
            file:close()
            Toast.makeText(service, "Script loaded successfully!", Toast.LENGTH_SHORT).show()
            
            -- Execute the downloaded script
            local func, err = loadfile(scriptPath)
            if func then
                func()
            else
                Toast.makeText(service, "Error executing script: " .. tostring(err), Toast.LENGTH_LONG).show()
            end
        else
            Toast.makeText(service, "Error saving script file!", Toast.LENGTH_LONG).show()
        end
    else
        Toast.makeText(service, "Failed to download script! HTTP Code: " .. tostring(code), Toast.LENGTH_LONG).show()
    end
end)