require "import"
import "com.androlua.*"
Http.get("https://hamariweb.com/cricket/live_cricket.aspx", function(status, result)
if status == 200 then
for data in result:gmatch('<div class="match_update">(.-)</a>') do
t1, ts1 = data:match('<div class="teamname">.-<span>(.-)</span>.-<span class="score">(.-)</span>')
t2, ts2 = data:match('<div class="teamname">.-<div class="teamname">.-<span>(.-)</span>.-<span class="score">(.-)</span>')
if t1 and t2 then
print(data:match("<p>(.-)<small>").."\n\n"..t1.." - "..ts1.."\n"..t2.." - "..ts2.."\n\nStatus: "..data:match('<div class="match_result">(.-)</div>'))
end
end
else
print("Error :-(")
end
end)