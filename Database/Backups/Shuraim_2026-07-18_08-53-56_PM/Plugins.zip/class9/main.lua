require "import"
import "android.widget.*"
import "android.content.Intent"
import "android.speech.SpeechRecognizer"
import "android.speech.RecognitionListener"
import "android.speech.RecognizerIntent"
import "android.view.View"
import "android.content.Context"
import "android.os.Bundle"
import "cjson"

-- ==================== AI & EMOJI SETTINGS ====================
local AI_PREFS = "UniqueTyperAI"
local aiPrefs = service.getSharedPreferences(AI_PREFS, Context.MODE_PRIVATE)
local aiEditor = aiPrefs.edit()

local geminiModels = {"Gemini 2.5 Flash", "Gemini 2.5 Pro"}
local modelApiDetails = {
    ["Gemini 2.5 Pro"] = { id = "models/gemini-2.5-pro", version = "v1beta" },
    ["Gemini 2.5 Flash"] = { id = "models/gemini-2.5-flash", version = "v1beta" }
}

function getApiKey()
    return aiPrefs.getString("apiKey", "")
end

function saveApiKey(key)
    aiEditor.putString("apiKey", key)
    aiEditor.commit()
end

function getSelectedModel()
    return aiPrefs.getString("model", geminiModels[1])
end

function saveSelectedModel(model)
    aiEditor.putString("model", model)
    aiEditor.commit()
end

function isEmojiEnabled()
    return aiPrefs.getBoolean("emojiEnabled", false)
end

function setEmojiEnabled(enabled)
    aiEditor.putBoolean("emojiEnabled", enabled)
    aiEditor.commit()
end

-- ==================== GEMINI API ====================
function handleResponse(data)
    local ok, decoded = pcall(cjson.decode, data)
    if ok and decoded then
        if decoded.candidates and decoded.candidates[1] and
           decoded.candidates[1].content and decoded.candidates[1].content.parts and
           decoded.candidates[1].content.parts[1] and decoded.candidates[1].content.parts[1].text then
            return decoded.candidates[1].content.parts[1].text
        end
        if decoded.candidates and decoded.candidates[1] and
           decoded.candidates[1].finishReason and
           decoded.candidates[1].finishReason == "SAFETY" then
            return "ERROR: Request was blocked by safety settings."
        end
        if decoded.error and decoded.error.message then
            return "ERROR: " .. decoded.error.message
        end
    end
    return nil
end

function callGemini(prompt, callback)
    local apiKey = getApiKey()
    if not apiKey or apiKey == "" then
        service.speak("Please set API key in AI Engine settings first")
        return
    end
    local modelName = getSelectedModel()
    local modelInfo = modelApiDetails[modelName]
    if not modelInfo then
        service.speak("Error: Model details not found")
        return
    end
    local url = "https://generativelanguage.googleapis.com/" .. modelInfo.version .. "/" .. modelInfo.id .. ":generateContent?key=" .. apiKey
    local payload = {
        contents = {{parts = {{text = prompt}}}}
    }
    local jsonPayload = cjson.encode(payload)
    local headers = {["Content-Type"] = "application/json"}
    
    Http.post(url, jsonPayload, headers, function(status, data)
        if status == 200 then
            local result = handleResponse(data)
            if result and not result:find("^ERROR:") then
                callback(result)
            else
                service.speak(result or "API returned invalid response")
            end
        else
            service.speak("API request failed: " .. status)
        end
    end)
end

function processWithAI(spokenText, callback)
    local apiKey = getApiKey()
    if not apiKey or apiKey == "" then
        -- No AI, just return original (already dictionary processed)
        callback(spokenText)
        return
    end
    
    local emojiEnabled = isEmojiEnabled()
    local prompt
    if emojiEnabled then
        prompt = [[Process the following voice transcription:
1. Fix spelling mistakes (Urdu and English both)
2. Add proper punctuation (. , ? !)
3. Keep natural language flow
4. IMPORTANT: After each sentence, add ONE relevant emoji based on the sentence's sentiment (happy, sad, professional, angry, romantic, etc.). Use standard emojis. Do not add any extra text or explanation.
5. Return only the final text with emojis.

Raw text: ]] .. spokenText
    else
        prompt = [[Process the following voice transcription:
1. Fix spelling mistakes (Urdu and English both)
2. Add proper punctuation (. , ? !)
3. Keep natural language flow
4. Do NOT add any emojis.
5. Return only the corrected text.

Raw text: ]] .. spokenText
    end
    
    callGemini(prompt, function(corrected)
        callback(corrected)
    end)
end

-- ==================== AI SETTINGS DIALOG ====================
function showAISettingsDialog()
    local dlg = LuaDialog(service)
    dlg.setTitle("AI Engine Settings")
    
    local layout = {
        LinearLayout;
        orientation = "vertical";
        padding = "20dp";
        {
            TextView;
            text = "Google Gemini API Key:";
            textSize = "14sp";
            layout_marginBottom = "5dp";
        };
        {
            EditText;
            id = "apiKeyInput";
            hint = "Enter your API Key";
            textSize = "14sp";
            layout_width = "fill";
            layout_marginBottom = "15dp";
        };
        {
            TextView;
            text = "Select Model:";
            textSize = "14sp";
            layout_marginBottom = "5dp";
        };
        {
            Spinner;
            id = "modelSpinner";
            layout_width = "fill";
            layout_marginBottom = "20dp";
        };
        {
            LinearLayout;
            orientation = "horizontal";
            layout_width = "fill";
            {
                Button;
                text = "Save";
                layout_weight = 1;
                layout_marginRight = "5dp";
                onClick = function()
                    local newKey = apiKeyInput.getText().toString()
                    local modelIndex = modelSpinner.getSelectedItemPosition() + 1
                    local newModel = geminiModels[modelIndex]
                    saveApiKey(newKey)
                    saveSelectedModel(newModel)
                    service.speak("AI settings saved")
                    dlg.dismiss()
                end;
            };
            {
                Button;
                text = "Cancel";
                layout_weight = 1;
                onClick = function()
                    dlg.dismiss()
                end;
            };
        };
    }
    
    local view = loadlayout(layout)
    
    local adapter = ArrayAdapter(service, android.R.layout.simple_spinner_item, geminiModels)
    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
    modelSpinner.setAdapter(adapter)
    
    local savedKey = getApiKey()
    if savedKey ~= "" then
        apiKeyInput.setText(savedKey)
    end
    local savedModel = getSelectedModel()
    for i, model in ipairs(geminiModels) do
        if model == savedModel then
            modelSpinner.setSelection(i - 1)
            break
        end
    end
    
    dlg.setView(view)
    dlg.show()
end

-- ==================== ORIGINAL DICTIONARY CODE ====================
local langFile = os.getenv("EXTERNAL_STORAGE") .. "/unique_typer_lang.dat"
local dictFile = os.getenv("EXTERNAL_STORAGE") .. "/unique_typer_dict.dat"
local changeTable = {}

function loadDictionary()
    local f = io.open(dictFile, "r")
    if f then
        local content = f:read("*all")
        f:close()
        if content and content ~= "" then
            local func = loadstring("return " .. content)
            if func then
                changeTable = func()
            end
            if type(changeTable) ~= "table" then
                changeTable = {}
            end
        end
    end
end

function saveDictionary()
    local f = io.open(dictFile, "w")
    if f then
        local items = {}
        for wrong, correct in pairs(changeTable) do
            table.insert(items, string.format("[%q]=%q", wrong, correct))
        end
        local content = "{" .. table.concat(items, ",") .. "}"
        f:write(content)
        f:close()
    end
end

function addToDictionary(wrongWord, correctWord)
    if wrongWord and correctWord and wrongWord ~= "" and correctWord ~= "" then
        changeTable[wrongWord] = correctWord
        saveDictionary()
        return true
    end
    return false
end

function getSavedLanguage()
    local f = io.open(langFile, "r")
    if f then
        local content = f:read("*all")
        f:close()
        return content:gsub("%s+", "")
    end
    return "ur-PK"
end

function saveLanguage(code)
    local f = io.open(langFile, "w")
    if f then
        f:write(code)
        f:close()
        service.speak("Language saved")
    end
end

local languageItems = {
    "Afrikaans (South Africa)", "Azerbaijani (Azerbaijan)", "Indonesian (Indonesia)", "Malay (Malaysia)", "Javanese (Indonesia)", "Sundanese (Indonesia)", "Catalan (Spain)", "Czech (Czech Republic)", "Danish (Denmark)", "German (Belgium)", "German (Germany)", "German (Austria)", "German (Switzerland)", "Estonian (Estonia)", "English (Australia)", "English (Canada)", "English (Generic)", "English (Ghana)", "English (India)", "English (Indonesia)", "English (Ireland)", "English (Kenya)", "English (New Zealand)", "English (Nigeria)", "English (Philippines)", "English (Singapore)", "English (South Africa)", "English (Tanzania)", "English (Thailand)", "English (UK)", "English (US)", "Spanish (Argentina)", "Spanish (Bolivia)", "Spanish (Chile)", "Spanish (Colombia)", "Spanish (Costa Rica)", "Spanish (Ecuador)", "Spanish (USA)", "Spanish (El Salvador)", "Spanish (Spain)", "Spanish (Guatemala)", "Spanish (Honduras)", "Spanish (Mexico)", "Spanish (Nicaragua)", "Spanish (Panama)", "Spanish (Paraguay)", "Spanish (Peru)", "Spanish (Puerto Rico)", "Spanish (Dominican Republic)", "Spanish (Uruguay)", "Spanish (Venezuela)", "Basque (Spain)", "Filipino (Philippines)", "French (Belgium)", "French (France)", "French (Canada)", "French (Switzerland)", "Galician (Spain)", "Croatian (Croatia)", "Kinyarwanda (Rwanda)", "Southern Ndebele (South Africa)", "Xhosa (South Africa)", "Zulu (South Africa)", "Icelandic (Iceland)", "Italian (Switzerland)", "Italian (Italy)", "Lithuanian (Lithuania)", "Swahili (Kenya)", "Swahili (Tanzania)", "Latvian (Latvia)", "Hungarian (Hungary)", "Dutch (Netherlands)", "Norwegian Bokmål (Norway)", "Uzbek (Uzbekistan)", "Polish (Poland)", "Portuguese (Brazil)", "Portuguese (Portugal)", "Romanian (Romania)", "Sotho (South Africa)", "Sotho (Lesotho)", "Northern Sotho (South Africa)", "Tswana (South Africa)", "Tswana (Botswana)", "Albanian (Albania)", "Swati (eSwatini)", "Swati (South Africa)", "Slovenian (Slovenia)", "Slovak (Slovakia)", "Finnish (Finland)", "Swedish (Sweden)", "Vietnamese (Vietnam)", "Venda (South Africa)", "Turkish (Turkey)", "Tsonga (South Africa)", "Greek (Greece)", "Bulgarian (Bulgaria)", "Macedonian (North Macedonia)", "Mongolian (Mongolia)", "Russian (Russia)", "Serbian (Serbia)", "Ukrainian (Ukraine)", "Kazakh (Kazakhstan)", "Georgian (Georgia)", "Armenian (Armenia)", "Hebrew (Israel)", "Arabic (Israel)", "Arabic (Jordan)", "Arabic (UAE)", "Arabic (Bahrain)", "Arabic (Algeria)", "Arabic (Saudi Arabia)", "Arabic (Kuwait)", "Arabic (Morocco)", "Arabic (Tunisia)", "Arabic (Oman)", "Arabic (Palestine)", "Arabic (Egypt)", "Persian (Iran)", "Arabic (Qatar)", "Arabic (Lebanon)", "Urdu (Pakistan)", "Urdu (India)", "Amharic (Ethiopia)", "Hindi (India)", "Punjabi (India)", "Tamil (India)", "Tamil (Sri Lanka)", "Tamil (Singapore)", "Tamil (Malaysia)", "Bengali (Bangladesh)", "Bengali (India)", "Khmer (Cambodia)", "Kannada (India)", "Marathi (India)", "Gujarati (India)", "Sinhala (Sri Lanka)", "Telugu (India)", "Malayalam (India)", "Nepali (Nepal)", "Lao (Laos)", "Thai (Thailand)", "Mandarin Chinese (Taiwan)", "Burmese (Myanmar)", "Korean (South Korea)", "Mandarin Chinese (Mainland China)", "Mandarin Chinese (Hong Kong)", "Cantonese (Hong Kong)", "Japanese (Japan)"
}

local languageCodes = {
    "af-ZA", "az-AZ", "id-ID", "ms-MY", "jv-ID", "su-ID", "ca-ES", "cs-CZ", "da-DK", "de-BE", "de-DE", "de-AT", "de-CH", "et-EE", "en-AU", "en-CA", "en", "en-GH", "en-IN", "en-ID", "en-IE", "en-KE", "en-NZ", "en-NG", "en-PH", "en-SG", "en-ZA", "en-TZ", "en-TH", "en-GB", "en-US", "es-AR", "es-BO", "es-CL", "es-CO", "es-CR", "es-EC", "es-US", "es-SV", "es-ES", "es-GT", "es-HN", "es-MX", "es-NI", "es-PA", "es-PY", "es-PE", "es-PR", "es-DO", "es-UY", "es-VE", "eu-ES", "fil-PH", "fr-BE", "fr-FR", "fr-CA", "fr-CH", "gl-ES", "hr-HR", "rw-RW", "nr-ZA", "xh-ZA", "zu-ZA", "is-IS", "it-CH", "it-IT", "lt-LT", "sw-KE", "sw-TZ", "lv-LV", "hu-HU", "nl-NL", "nb-NO", "uz-UZ", "pl-PL", "pt-BR", "pt-PT", "ro-RO", "st-ZA", "st-LS", "nso-ZA", "tn-ZA", "tn-BW", "sq-AL", "ss-SZ", "ss-ZA", "sl-SI", "sk-SK", "fi-FI", "sv-SE", "vi-VN", "ve-ZA", "tr-TR", "ts-ZA", "el-GR", "bg-BG", "mk-MK", "mn-MN", "ru-RU", "sr-RS", "uk-UA", "kk-KZ", "ka-GE", "hy-AM", "iw-IL", "ar-IL", "ar-JO", "ar-AE", "ar-BH", "ar-DZ", "ar-SA", "ar-KW", "ar-MA", "ar-TN", "ar-OM", "ar-PS", "ar-EG", "fa-IR", "ar-QA", "ar-LB", "ur-PK", "ur-IN", "am-ET", "hi-IN", "pa-IN", "ta-IN", "ta-LK", "ta-SG", "ta-MY", "bn-BD", "bn-IN", "km-KH", "kn-IN", "mr-IN", "gu-IN", "si-LK", "te-IN", "ml-IN", "ne-NP", "lo-LA", "th-TH", "zh-TW", "my-MM", "ko-KR", "zh-CN", "zh-HK", "yue-Hant-HK", "ja-JP"
}

function showDictionaryDialog()
    local dlg = LuaDialog(service)
    dlg.setTitle("Add to Dictionary")
    local layout = {
        LinearLayout;
        orientation = "vertical";
        padding = "20dp";
        {
            EditText;
            id = "wrongWord";
            hint = "Wrong word (غلط لفظ)";
            textSize = "16sp";
            layout_width = "fill";
            layout_marginBottom = "15dp";
        };
        {
            EditText;
            id = "correctWord";
            hint = "Correct word (صحیح لفظ)";
            textSize = "16sp";
            layout_width = "fill";
            layout_marginBottom = "15dp";
        };
        {
            Button;
            text = "Add to Dictionary";
            textSize = "16sp";
            layout_width = "fill";
            onClick = function()
                local wrong = wrongWord.getText().toString()
                local correct = correctWord.getText().toString()
                if wrong ~= "" and correct ~= "" then
                    addToDictionary(wrong, correct)
                    service.speak("Added: " .. wrong .. " → " .. correct)
                    dlg.dismiss()
                else
                    service.speak("Both fields required")
                end
            end;
        };
    }
    dlg.setView(loadlayout(layout))
    dlg.show()
end

function showDictionaryList()
    if next(changeTable) == nil then
        service.speak("Dictionary is empty")
        return
    end
    local items = {}
    for wrong, correct in pairs(changeTable) do
        table.insert(items, wrong .. " → " .. correct)
    end
    local listDlg = LuaDialog(service)
    listDlg.setTitle("My Dictionary")
    local layout = {
        LinearLayout;
        orientation = "vertical";
        padding = "10dp";
        {
            ListView;
            id = "list";
            layout_width = "fill";
            layout_height = "400dp";
        };
        {
            Button;
            text = "Close";
            layout_width = "fill";
            onClick = function()
                listDlg.dismiss()
            end;
        };
    }
    local view = loadlayout(layout)
    list.setAdapter(ArrayAdapter(service, android.R.layout.simple_list_item_1, items))
    listDlg.setView(view)
    listDlg.show()
end

-- ==================== VOICE TYPING WITH AI & EMOJI ====================
local editText = service.getEditText()

function startVoiceTyping(langCode)
    local context = service.getApplicationContext()
    local speechRec = SpeechRecognizer.createSpeechRecognizer(context)
    
    local listener = RecognitionListener {
        onResults = function(results)
            local resultsArray = results.getParcelableArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if resultsArray and resultsArray.size() > 0 then
                local spokenText = resultsArray.get(0)
                -- Apply dictionary corrections first
                for wrongWord, correctWord in pairs(changeTable) do
                    spokenText = spokenText:gsub(wrongWord, correctWord)
                end
                spokenText = spokenText:gsub("%s([?,!])", "%1")
                if not spokenText:match("[.?!,.]$") then
                    spokenText = spokenText .. ". "
                end
                
                -- Use AI if API key exists, otherwise just insert dictionary-corrected text
                local apiKey = getApiKey()
                if apiKey and apiKey ~= "" then
                    service.speak("AI processing...")
                    processWithAI(spokenText, function(enhancedText)
                        service.insertText(editText, enhancedText)
                        service.speak(enhancedText)
                    end)
                else
                    service.insertText(editText, spokenText)
                    service.speak(spokenText)
                end
            end
            speechRec.destroy()
        end,
        onError = function(errorCode)
            service.asyncSpeak("I did not understand your message")
            speechRec.destroy()
            return false
        end,
    }
    
    local intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, langCode)
    speechRec.setRecognitionListener(listener)
    speechRec.startListening(intent)
end

-- ==================== MAIN MENU (with Emoji Toggle Button) ====================
loadDictionary()

if editText then
    startVoiceTyping(getSavedLanguage())
else
    local dlg = LuaDialog(service)
    dlg.setTitle("Unique Typer")
    
    -- Emoji toggle state
    local emojiState = isEmojiEnabled()
    local emojiButtonText = emojiState and "Emoji: ON" or "Emoji: OFF"
    
    local layout = {
        LinearLayout;
        orientation = "vertical";
        padding = "30dp";
        {
            Button;
            text = "Developer Sabir Jamil";
            textSize = "16sp";
            layout_width = "fill";
            layout_marginBottom = "10dp";
        };
        {
            Button;
            text = "Select Language For Typing";
            textSize = "16sp";
            layout_width = "fill";
            layout_marginBottom = "10dp";
            onClick = function()
                local listDlg = LuaDialog(service)
                listDlg.setTitle("Select Language")
                local list = ListView(service)
                list.setAdapter(ArrayAdapter(service, android.R.layout.simple_list_item_1, languageItems))
                list.onItemClick = function(l, v, p, i)
                    saveLanguage(languageCodes[p+1])
                    listDlg.dismiss()
                    service.speak("Language selected: " .. languageItems[p+1])
                end
                listDlg.setView(list)
                listDlg.show()
            end;
        };
        {
            Button;
            text = "Dictionary (Add Words)";
            textSize = "16sp";
            layout_width = "fill";
            layout_marginBottom = "10dp";
            onClick = function()
                showDictionaryDialog()
            end;
        };
        {
            Button;
            text = "View Dictionary";
            textSize = "16sp";
            layout_width = "fill";
            layout_marginBottom = "10dp";
            onClick = function()
                showDictionaryList()
            end;
        };
        {
            Button;
            text = "AI Engine";
            textSize = "16sp";
            layout_width = "fill";
            layout_marginBottom = "10dp";
            onClick = function()
                showAISettingsDialog()
            end;
        };
        {
            Button;
            id = "emojiToggle";
            text = emojiButtonText;
            textSize = "16sp";
            layout_width = "fill";
            layout_marginBottom = "10dp";
            onClick = function()
                local newState = not isEmojiEnabled()
                setEmojiEnabled(newState)
                local newText = newState and "Emoji: ON" or "Emoji: OFF"
                emojiToggle.setText(newText)
                service.speak("Emoji " .. (newState and "enabled" or "disabled"))
            end;
        };
        {
            Button;
            text = "About";
            textSize = "16sp";
            layout_width = "fill";
            layout_marginBottom = "10dp";
            onClick = function()
                service.speak("Unique Typer helps you type by voice in multiple languages. You can add custom word replacements in Dictionary. AI Engine uses Google Gemini for enhanced accuracy and optional auto-emoji per sentence.")
            end;
        };
        {
            Button;
            text = "Exit";
            textSize = "16sp";
            layout_width = "fill";
            onClick = function()
                dlg.dismiss()
            end;
        };
    }
    
    dlg.setView(loadlayout(layout))
    dlg.show()
end