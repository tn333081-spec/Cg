require "import"
import "java.text.SimpleDateFormat"
import "java.util.Date"
import "android.content.Context"
import "android.content.Intent"
import "android.content.IntentFilter"
import "android.os.BatteryManager"
import "android.net.ConnectivityManager"

function speakDateTime(context)
    local hour = tonumber(os.date("%H"))
    local greeting = ""
    
    if hour >= 5 and hour < 12 then
        greeting = "Good morning!"
    elseif hour >= 12 and hour < 18 then
        greeting = "Good afternoon!"
    elseif hour >= 18 or hour < 5 then
        greeting = "Good evening!"
    end

    local currentDate = os.date("%A, %B %d, %Y")
    local formattedTime = SimpleDateFormat("hh:mm a").format(Date())
    -- Get battery level
    local batteryIntent = context.registerReceiver(nil, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    local level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    local scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
    local batteryPercent = (level / scale) * 100
    -- Get temperature
    local temperatureIntent = context.registerReceiver(nil, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    local temperature = temperatureIntent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10
    local isCharging = batteryIntent.getIntExtra(BatteryManager.EXTRA_STATUS, -1) == BatteryManager.BATTERY_STATUS_CHARGING

    local chargingStatus = ""
    if isCharging then
        chargingStatus = "The phone is currently charging."
    else
        chargingStatus = "The phone is not currently charging."
    end

    -- Check mobile data status
    local connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE)
    local mobileDataActive = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).isConnectedOrConnecting()

    local mobileDataStatus = ""
    if mobileDataActive then
        mobileDataStatus = "Mobile data is active."
    else
        mobileDataStatus = "Mobile data is not active."
    end

    -- Additional Features
    local tomorrowDate = os.date("%A, %B %d, %Y", os.time() + 86400)
    local dayOfWeek = os.date("%A")
    local endOfMonthDate = os.date("%d", os.time({year=os.date("%Y"), month=os.date("%m")+1, day=0}))
    local timeSinceEpoch = os.time()
    
    -- Speak the message
    local message = greeting .. " Today is " .. currentDate .. ". Tomorrow is " .. tomorrowDate .. ". It is " .. dayOfWeek .. ". The time is " .. formattedTime .. ". The battery level is " .. batteryPercent .. " percent. The battery temperature is " .. temperature .. " degree Celsius. " .. chargingStatus .. " " .. mobileDataStatus .. " This month ends on the " .. endOfMonthDate .. ". Current time since epoch is " .. timeSinceEpoch .. " seconds."
    context.speak(message)
end

speakDateTime(this)
service.playSoundClock()
return true