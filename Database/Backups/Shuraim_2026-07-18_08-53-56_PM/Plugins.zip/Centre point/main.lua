--[[在解说拓展公益班同学圣洁制作的获取当前焦点中心坐标插件基础上修改制作，
用一对方括号将提示结果扩上，省去手动添加方括号环节，可以直接复制提示结果后粘贴到字符串内使用。]]

require "import"
import "android.graphics.Rect"
    local p=Rect()
    node.getBoundsInScreen(p)
print("["..string.format("%.0f,%.0f",(p.left+(p.right-p.left)/2),(p.top+(p.bottom-p.top)/2)).."]")