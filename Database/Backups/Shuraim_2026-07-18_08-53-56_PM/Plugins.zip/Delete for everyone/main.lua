
if service.click({
{"%Long press$300",
"%Go back$300",
"Delete$300",
"Delete for everyone$300",
}
})
return true
end
