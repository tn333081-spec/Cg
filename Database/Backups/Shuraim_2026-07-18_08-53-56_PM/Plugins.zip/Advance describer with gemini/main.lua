require "import"
import "com.androlua.Http"
import "android.widget.Toast"
import "android.app.AlertDialog"
import "android.view.WindowManager"
import "android.os.Handler"
import "android.os.Looper"
import "java.io.File"
import "android.widget.ScrollView"
import "android.widget.LinearLayout"
import "android.widget.TextView"
import "android.widget.EditText"
import "android.widget.CheckBox"

local updateURL = "https://raw.githubusercontent.com/MohammadHusain/Auto-Update-Injector/main/version.txt"
local downloadURL = "https://raw.githubusercontent.com/MohammadHusain/Auto-Update-Injector/main/main.lua"
local messageURL = "" -- Optional: Insert Message URL manually
local requireUpdate = false -- "Require Update" checkbox option
local currentVersion = "2.1"
local currentDir = "/storage/emulated/0/解说/Plugins/Auto Update Injector By Mohammad Husain"
local oldPath = currentDir .. "/old_main.lua"
local mainPath = currentDir .. "/main.lua"

local mainDialog = nil

local mainLayout = {
    LinearLayout,
    orientation="vertical",
    {
        EditText,
        text=updateURL,
        hint="Update URL"
    },
    {
        EditText,
        text=downloadURL,
        hint="Download URL"
    },
    {
        EditText,
        text=messageURL,
        hint="Message URL",
        id="messageURLInput"
    },
    {
        CheckBox,
        text="Require Update",
        checked=requireUpdate,
        id="requireUpdateCheck"
    }
}

mainDialog = AlertDialog.Builder(service or activity)
    .setTitle("Auto Update Injector")
    .setView(loadlayout(mainLayout))
    .create()
mainDialog.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
mainDialog.show()

local function runOriginalCode()
    if File(oldPath).exists() then
        local func, err = loadfile(oldPath)
        if func then pcall(func) end
    end
end

local function checkUpdate()
    Http.get(updateURL, function(code, response)
        if code == 200 and response then
            local onlineVersion = tostring(response):gsub("^%s*(.-)%s*$", "%1")
            if onlineVersion ~= currentVersion then
                
                local function showUpdateDialog(customMsg)
                    Handler(Looper.getMainLooper()).post(Runnable{run=function()
                        local updateAlertDlg = AlertDialog.Builder(service or activity)
                        updateAlertDlg.setTitle("Update Available!")
                        
                        if customMsg then
                            local sv = ScrollView(service or activity)
                            local ll = LinearLayout(service or activity)
                            ll.setOrientation(1)
                            
                            local textToSplit = customMsg:gsub("\r\n", "\n"):gsub("\r", "\n")
                            for line in (textToSplit .. "\n"):gmatch("(.-)\n") do
                                local tv = TextView(service or activity)
                                tv.setText(line)
                                ll.addView(tv)
                            end
                            sv.addView(ll)
                            updateAlertDlg.setView(sv)
                        else
                            updateAlertDlg.setMessage("New version " .. onlineVersion .. " is ready. Your current version is " .. currentVersion)
                        end
                        
                        updateAlertDlg.setPositiveButton("Update Now", {onClick=function(v)
                            v.dismiss()
                            Toast.makeText(service, "Downloading...", 0).show()
                            Http.get(downloadURL, function(c, content)
                                if c == 200 and content then
                                    local f = io.open(oldPath, "w")
                                    if f then f:write(content):close() end
                                    
                                    local mf = io.open(mainPath, "r")
                                    if mf then
                                        local mainContent = mf:read("*a")
                                        mf:close()
                                        local newMainContent = mainContent:gsub('local currentVersion = "2.0"', 'local currentVersion = "2.0"')
                                        local mf2 = io.open(mainPath, "w")
                                        if mf2 then mf2:write(newMainContent):close() end
                                    end
                                    
                                    local successDialog = AlertDialog.Builder(service or activity)
                                    successDialog.setTitle("Update Successful")
                                    successDialog.setMessage("Plugin updated to "..onlineVersion..". Restarting...")
                                    successDialog.setPositiveButton("OK", {onClick=function(v2)
                                        v2.dismiss()
                                        if mainDialog then
                                            mainDialog.dismiss()
                                        end
                                        Handler(Looper.getMainLooper()).postDelayed(Runnable{run=function()
                                            local func, err = loadfile(mainPath)
                                            if func then
                                                pcall(func)
                                            else
                                                Toast.makeText(service, "Error loading updated plugin: " .. tostring(err), Toast.LENGTH_LONG).show()
                                            end
                                        end}, 1000)
                                    end})
                                    local d2 = successDialog.create()
                                    d2.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
                                    d2.show()
                                end
                            end)
                        end})
                        
                        if requireUpdate then
                            updateAlertDlg.setCancelable(false)
                            updateAlertDlg.setNegativeButton("Later", {onClick=function(v)
                                Toast.makeText(service or activity, "Update is required.", 0).show()
                                showUpdateDialog(customMsg)
                            end})
                        else
                            updateAlertDlg.setNegativeButton("Later", nil)
                        end
                        
                        local d1 = updateAlertDlg.create()
                        d1.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
                        d1.show()
                    end})
                end

                if messageURL and messageURL ~= "" then
                    Http.get(messageURL, function(mCode, mContent)
                        if mCode == 200 and mContent and tostring(mContent):gsub("^%s*(.-)%s*$", "%1") ~= "" then
                            showUpdateDialog(tostring(mContent))
                        else
                            showUpdateDialog(nil)
                        end
                    end)
                else
                    showUpdateDialog(nil)
                end
                
            end
        end
    end)
end

runOriginalCode()

Handler(Looper.getMainLooper()).postDelayed(Runnable{run=function()
    checkUpdate()
end}, 3000)
