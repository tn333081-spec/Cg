if service.click({
{"Send$1",
}
})
return true
end

if service.click({
{"<Voice message, Button*$1",
"%Direct swipe up$800",
"%service.playSoundTick()",}
})
return true
end