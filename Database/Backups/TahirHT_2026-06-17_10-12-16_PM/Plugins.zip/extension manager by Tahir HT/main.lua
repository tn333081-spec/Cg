
if service.click({
{"%extensions$50",
"manage",}
})
return true
end
