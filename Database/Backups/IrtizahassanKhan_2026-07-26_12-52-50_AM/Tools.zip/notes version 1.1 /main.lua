require "import"
import "android.widget.*"
import "android.view.*"
import "android.content.*"
import "android.app.*"
import "java.io.*"
import "android.net.Uri"
import "android.view.KeyEvent"

-- Notes folder
noteDir = "/sdcard/NotesVirgin/"
File(noteDir).mkdirs()

-- Load notes
function loadNotes()
  local list = {}
  local files = File(noteDir).listFiles()
  if files then
    for i = 0, #files - 1 do
      local name = files[i].getName()
      name = name:gsub("%.txt", "")
      table.insert(list, name)
    end
  end
  return list
end

-- Save note
function saveNote(title, content)
  local f = io.open(noteDir .. title .. ".txt", "w")
  if f then
    f:write(content)
    f:close()
  end
end

-- Read note
function readNote(title)
  local f = io.open(noteDir .. title .. ".txt", "r")
  if not f then return "" end
  local c = f:read("*a")
  f:close()
  return c
end

-- Delete note
function deleteNote(title)
  File(noteDir .. title .. ".txt").delete()
end

-- Main layout
layout = {
  LinearLayout,
  orientation = "vertical",
  padding = "16dp",

  { TextView, text = "Notes", textSize = "22sp" },
  { TextView, text = "Version 1.1", textSize = "14sp" },
  {
    TextView,
    text = "This tool is developed by Irtiza Hassan",
    textSize = "12sp",
    layout_marginBottom = "12dp"
  },

  { Button, id = "createBtn", text = "Create Note" },
  { ListView, id = "noteList" },

  {
    Button,
    id = "whatsappBtn",
    text = "Contact on WhatsApp",
    layout_marginTop = "12dp"
  },

  {
    Button,
    id = "closeBtn",
    text = "Close",
    layout_marginTop = "8dp"
  }
}

dlg = LuaDialog(this)
dlg.View = loadlayout(layout)
dlg.setCancelable(false)
dlg.show()

-- Back button fix
dlg.setOnKeyListener(function(d, keyCode, event)
  if keyCode == KeyEvent.KEYCODE_BACK
     and event.getAction() == KeyEvent.ACTION_UP then
    dlg.dismiss()
    this.finish()
    return true
  end
  return false
end)

closeBtn.onClick = function()
  dlg.dismiss()
  this.finish()
end

-- WhatsApp
whatsappBtn.onClick = function()
  local number = "923193929648"
  local url = "https://wa.me/" .. number
  this.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
end

-- Refresh list
function refreshList()
  notes = loadNotes()
  noteList.adapter =
    ArrayAdapter(this, android.R.layout.simple_list_item_1, notes)
end

refreshList()

-- Create note
createBtn.onClick = function()
  noteLayout = {
    LinearLayout,
    orientation = "vertical",
    padding = "16dp",

    { EditText, id = "titleInput", hint = "Note title here" },
    {
      EditText,
      id = "noteInput",
      hint = "Write your note here",
      minLines = 4
    }
  }

  nd = LuaDialog(this)
  nd.View = loadlayout(noteLayout)
  nd.setTitle("Create Note")

  nd.setButton("Save", function()
    if titleInput.text == "" or noteInput.text == "" then
      Toast.makeText(this,"Please fill all fields",Toast.LENGTH_SHORT).show()
      return
    end
    saveNote(titleInput.text, noteInput.text)
    nd.dismiss()
    refreshList()
  end)

  nd.setButton2("Cancel", nil)
  nd.show()
end

-- View note
noteList.onItemClick = function(l, v, p, i)
  local oldTitle = notes[p + 1]
  local content = readNote(oldTitle)

  viewLayout = {
    LinearLayout,
    orientation = "vertical",
    padding = "16dp",

    { TextView, text = oldTitle, textSize = "18sp" },
    {
      TextView,
      text = content,
      textSize = "16sp",
      layout_marginTop = "8dp"
    },
    {
      Button,
      id = "moreBtn",
      text = "More Options",
      layout_marginTop = "12dp"
    }
  }

  vd = LuaDialog(this)
  vd.View = loadlayout(viewLayout)
  vd.setTitle("View Note")
  vd.show()

  -- More options
  moreBtn.onClick = function()
    local options = {"Share", "Copy", "Edit Note", "Delete"}

    AlertDialog.Builder(this)
      .setTitle("More Options")
      .setItems(options, function(d, which)

        if which == 0 then
          local intent = Intent(Intent.ACTION_SEND)
          intent.setType("text/plain")
          intent.putExtra(
            Intent.EXTRA_TEXT,
            oldTitle .. "\n\n" .. content
          )
          this.startActivity(
            Intent.createChooser(intent, "Share note")
          )

        elseif which == 1 then
          local clipboard =
            this.getSystemService(Context.CLIPBOARD_SERVICE)
          local clip = ClipData.newPlainText(
            "Note",
            oldTitle .. "\n\n" .. content
          )
          clipboard.setPrimaryClip(clip)
          Toast.makeText(
            this,
            "Copied to clipboard",
            Toast.LENGTH_SHORT
          ).show()

        elseif which == 2 then
          editLayout = {
            LinearLayout,
            orientation = "vertical",
            padding = "16dp",

            {
              EditText,
              id = "editTitle",
              text = oldTitle
            },

            {
              EditText,
              id = "editContent",
              text = content,
              minLines = 4
            }
          }

          ed = LuaDialog(this)
          ed.View = loadlayout(editLayout)
          ed.setTitle("Edit Note")

          ed.setButton("Save", function()
            if editTitle.text == "" or editContent.text == "" then
              Toast.makeText(this,"Please fill all fields",Toast.LENGTH_SHORT).show()
              return
            end

            if editTitle.text ~= oldTitle then
              deleteNote(oldTitle)
            end

            saveNote(editTitle.text, editContent.text)
            ed.dismiss()
            vd.dismiss()
            refreshList()
          end)

          ed.setButton2("Cancel", nil)
          ed.show()

        elseif which == 3 then
          AlertDialog.Builder(this)
            .setTitle("Delete Note")
            .setMessage("Do you want to delete this note?")
            .setPositiveButton("OK", function()
              deleteNote(oldTitle)
              refreshList()
              vd.dismiss()
            end)
            .setNegativeButton("Cancel", nil)
            .show()
        end

      end)
      .show()
  end
end
