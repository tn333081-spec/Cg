import "android.view.MotionEvent"
import "android.media.MediaPlayer"
import "android.view.View"
import "android.widget.LinearLayout"
import "android.widget.Button"
import "android.widget.TextView"
import "java.lang.System"

local Mode2vs10 = {}

local state = {
  is_playing = false,
  current_level = 1,
  my_health = 100,
  partner_health = 100,
  my_ammo = 10,
  partner_ammo = 20,
  enemies_killed = 0,
  partner_kills = 0,
  total_enemies = 10,
  enemy_dir = "Front",
  enemy_dist = 50,
  can_fire = true,
  current_weapon = "Default Pistol"
}

local startX, startY = 0, 0
local swipeThreshold = 120
local maxPointers = 1
local lastTwoFingerTapTime = 0

local host = {
  context = nil,
  weapons_database = nil,
  announce = nil,
  vibrate = nil,
  onGameFinished = nil
}

local function playLocalSound(soundName)
  local luaDir = tostring(host.context.getLuaDir())
  local paths = {
    luaDir .. "/" .. soundName,
    luaDir .. "/sound/" .. soundName,
    luaDir .. "/sounds/" .. soundName
  }
  
  for _, path in ipairs(paths) do
    local mp = MediaPlayer()
    local success = pcall(function()
      mp.setDataSource(path)
      mp.prepare()
      mp.start()
      mp.setOnCompletionListener(MediaPlayer.OnCompletionListener{
        onCompletion = function(v) v.release() end
      })
    end)
    if success then break end
  end
end

local function autoAnnounceLoop()
  if not state.is_playing then return end
  if host.announce and state.enemy_dist > 0 then
    host.announce("Distance " .. state.enemy_dist .. " meters")
  end
  task(3500, function() autoAnnounceLoop() end)
end

local function spawnEnemy()
  if not state.is_playing then return end
  local total_dead = state.enemies_killed + state.partner_kills
  if total_dead >= state.total_enemies then
    state.is_playing = false
    if host.onGameFinished then host.onGameFinished(true, state.enemies_killed, state.current_level) end
    return
  end
  
  state.enemy_dir = ({"Front", "Back", "Left", "Right"})[math.random(1, 4)]
  state.enemy_dist = math.random(30, 70)
  if host.announce then host.announce("Target " .. (total_dead + 1) .. " at " .. state.enemy_dir .. ", " .. state.enemy_dist .. " meters.") end
end

local function partnerLoop()
  if not state.is_playing or state.partner_health <= 0 then return end
  if state.enemy_dist <= 35 and state.partner_ammo > 0 then
    state.partner_ammo = state.partner_ammo - 1
    
    -- Teammate logic nerfed (Ab chance sirf 20% hai, warna pehle 60% tha)
    if math.random(1, 10) <= 2 then 
      state.partner_kills = state.partner_kills + 1
      if host.vibrate then host.vibrate({0, 200, 100, 200}) end
      playLocalSound("headshot.mp3")
      if host.announce then host.announce("Partner headshot!") end
      task(1500, function() spawnEnemy() end)
    end
  end
  task(4500, function() partnerLoop() end) -- Partner firing rate decreased
end

local function enemyLoop()
  if not state.is_playing then return end
  
  state.enemy_dist = math.max(0, state.enemy_dist - (5 + (state.current_level * 2)))
  
  if state.enemy_dist <= 15 and state.enemy_dist > 0 then
    -- Enemy attacking logic
    if math.random(1, 3) == 1 and state.partner_health > 0 then
      state.partner_health = state.partner_health - 20
      if state.partner_health <= 0 then
         playLocalSound("teammate_death.mp3")
         if host.announce then host.announce("Partner is dead!") end
      else
         if host.announce then host.announce("Partner hit!") end
      end
    else
      if state.my_health > 0 then
         state.my_health = state.my_health - 20
         if host.announce then host.announce("Hit! Health " .. state.my_health) end
         if host.vibrate then host.vibrate({0, 300}) end
      end
    end
  end
  
  -- Game Over Logic (Agar Player kill ho jaye)
  if state.my_health <= 0 then
    state.is_playing = false
    playLocalSound("player_death.mp3")
    if host.announce then host.announce("You are dead! Game Over.") end
    if host.onGameFinished then host.onGameFinished(false, state.enemies_killed, state.current_level) end
    return
  end
  
  task(4000, function() enemyLoop() end)
end

function Mode2vs10.fireWeapon()
  if not state.is_playing or not state.can_fire or state.my_ammo <= 0 then 
    if state.my_ammo <= 0 and host.announce then host.announce("Out of ammo!") end
    return 
  end
  state.can_fire = false
  state.my_ammo = state.my_ammo - 1
  
  local gunSoundName = string.lower(string.gsub(string.gsub(state.current_weapon, "%-", ""), " ", "_")) .. ".mp3"
  playLocalSound(gunSoundName)
  
  local weaponData = host.weapons_database[state.current_weapon]
  local gunRange = weaponData and weaponData.range or 15
  
  if state.enemy_dist <= gunRange then
    state.enemies_killed = state.enemies_killed + 1
    state.my_ammo = state.my_ammo + 10 -- Ammo Boost on Kill
    if host.vibrate then host.vibrate(500) end
    
    if math.random(1, 10) <= 3 then -- 30% Headshot chance
      playLocalSound("headshot.mp3")
      if host.announce then host.announce("Headshot! Target down. Ammo boosted.") end
    else
      playLocalSound("kill.mp3")
      if host.announce then host.announce("Target down! Ammo boosted.") end
    end
    
    task(1500, function() spawnEnemy() end)
  else
    if host.announce then host.announce("Missed!") end
  end
  task(1000, function() state.can_fire = true end)
end

function Mode2vs10.executeMovement(direction)
  if not state.is_playing then return end
  
  playLocalSound("move.mp3")
  
  if direction == state.enemy_dir then state.enemy_dist = math.max(0, state.enemy_dist - 10) else state.enemy_dist = state.enemy_dist + 10 end
  if host.announce then host.announce("Moved " .. direction .. ". Distance " .. state.enemy_dist) end
end

function Mode2vs10.initialize(config)
  host.context = config.context
  host.weapons_database = config.weapons_info
  host.announce = config.announce
  host.vibrate = config.vibrate
  host.onGameFinished = config.onGameFinished
end

function Mode2vs10.startMatch(level, weaponName)
  state.current_level = level
  state.current_weapon = weaponName or "Default Pistol"
  state.total_enemies = 10 + (level - 1)
  state.my_health, state.partner_health = 100, 100
  state.my_ammo, state.partner_ammo = 10, 20
  state.enemies_killed, state.partner_kills = 0, 0
  state.is_playing, state.can_fire = true, true
  
  local views = {}
  local layout = {
    LinearLayout,
    orientation="vertical",
    layout_width="fill",
    layout_height="fill",
    backgroundColor="#000000",
    {
      LinearLayout,
      id="gesture_pad",
      layout_width="fill",
      layout_weight=1,
      gravity="center",
      clickable=true,
      focusable=true,
      backgroundColor="#111111",
      {TextView, text="GESTURE PAD\nSwipe to move, Tap to fire\n2-Finger Gestures Active", textColor="#FFFFFF", gravity="center", textSize="18sp"}
    },
    {
      LinearLayout,
      orientation="vertical",
      layout_width="fill",
      padding="5dp",
      backgroundColor="#222222",
      {
         LinearLayout, orientation="horizontal", layout_width="fill",
         {Button, text="Fire", layout_weight=1, onClick=function() Mode2vs10.fireWeapon() end},
         {Button, text="Health", layout_weight=1, onClick=function() 
            host.announce("My Health " .. state.my_health .. ", Partner Health " .. state.partner_health) 
         end},
         {Button, text="Status", layout_weight=1, onClick=function() 
            host.announce("Enemy at " .. state.enemy_dir .. ", " .. state.enemy_dist .. " meters") 
         end},
      },
      {
         LinearLayout, orientation="horizontal", layout_width="fill",
         {Button, text="Left", layout_weight=1, onClick=function() Mode2vs10.executeMovement("Left") end},
         {Button, text="Right", layout_weight=1, onClick=function() Mode2vs10.executeMovement("Right") end},
         {Button, text="Front", layout_weight=1, onClick=function() Mode2vs10.executeMovement("Front") end},
         {Button, text="Back", layout_weight=1, onClick=function() Mode2vs10.executeMovement("Back") end},
      }
    }
  }
  
  host.context.setContentView(loadlayout(layout, views))
  
  views.gesture_pad.setImportantForAccessibility(2)
  views.gesture_pad.setOnTouchListener(View.OnTouchListener{
    onTouch = function(v, event) return Mode2vs10.processTouchEvent(v, event) end
  })
  
  if host.announce then host.announce("Duo Mode Started. Target: " .. state.total_enemies) end
  spawnEnemy()
  task(2000, function() enemyLoop() end)
  task(3500, function() partnerLoop() end)
  task(4500, function() autoAnnounceLoop() end)
end

function Mode2vs10.processTouchEvent(view, event)
  local action = event.getActionMasked()
  local pointerCount = event.getPointerCount()
  
  if pointerCount > maxPointers then maxPointers = pointerCount end

  if action == 0 then
    startX, startY = event.getX(), event.getY()
    maxPointers = 1
    if view.getParent() then view.getParent().requestDisallowInterceptTouchEvent(true) end
    return true
  elseif action == 5 then
    maxPointers = event.getPointerCount()
    return true
  elseif action == 1 then
    local deltaX = event.getX() - startX
    local deltaY = event.getY() - startY
    
    if math.abs(deltaX) > swipeThreshold or math.abs(deltaY) > swipeThreshold then
      if math.abs(deltaX) > math.abs(deltaY) then
        if deltaX > 0 then 
          if maxPointers >= 2 then host.announce("Enemy at " .. state.enemy_dir .. ", " .. state.enemy_dist .. " meters") else Mode2vs10.executeMovement("Right") end
        else 
          if maxPointers >= 2 then host.announce("My Health " .. state.my_health .. ", Partner Health " .. state.partner_health) else Mode2vs10.executeMovement("Left") end
        end
      else
        if deltaY > 0 then Mode2vs10.executeMovement("Back") else Mode2vs10.executeMovement("Front") end
      end
    else
      if maxPointers >= 2 then
        local currentTime = System.currentTimeMillis()
        if (currentTime - lastTwoFingerTapTime) < 500 then
           Mode2vs10.fireWeapon()
           lastTwoFingerTapTime = 0
        else lastTwoFingerTapTime = currentTime end
      else Mode2vs10.fireWeapon() end
    end
    return true
  end
  return true
end

return Mode2vs10
