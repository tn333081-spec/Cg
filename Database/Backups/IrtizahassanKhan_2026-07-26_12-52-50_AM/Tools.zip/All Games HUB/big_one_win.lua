-- File: big_one_wins.lua
-- Modernized Big One Wins Module (Synced with Profile Stats)

local bigOneWinsModule = {}

function bigOneWinsModule.start(params)
    -- Required Parameters Extraction
    local activity = params.activity
    local prefs = params.prefs
    local handler = params.handler
    local playSound = params.playSound
    local speak = params.speak
    local showHome = params.showHome -- Callback to return to the main menu
    
    -- Sound Paths
    local clickSoundPath = params.clickSoundPath
    local diceSoundPath = params.diceSoundPath
    local winSoundPath = params.winSoundPath
    local looseSoundPath = params.looseSoundPath

    -- Player Data
    local currentUser = prefs.getString("username", "Player")
    local announceTotal = prefs.getBoolean("announceTotal", true)
    
    -- Local Game State (Encapsulated, No Global Variables)
    local playerScore = 0
    local robotScore = 0

    activity.setTitle("Big One Wins")

    -- Modernized UI Layout
    local ids = {}
    local layout = {
        LinearLayout,
        orientation="vertical",
        padding="20dp",
        background="#000000",
        layout_width="fill",
        layout_height="fill",
        gravity="center_horizontal",
        {Button, id="boOptBtn", text="Game Options", layout_width="fill", layout_marginBottom="15dp"},
        {Button, id="rollBtn", text="Roll a Dice", layout_width="fill", layout_marginBottom="25dp"},
        {TextView, id="statusText", text="Ready to Play", textSize="18sp", textColor="#FFFFFF", layout_marginBottom="25dp", gravity="center", focusable=true},
        {LinearLayout, orientation="horizontal", layout_width="fill", gravity="space_between", layout_marginBottom="30dp",
            {TextView, id="pScore", text=currentUser.." Wins: 0", textSize="18sp", textColor="#4CAF50", focusable=true, layout_weight="1"},
            {TextView, id="rScore", text="Robot Wins: 0", textSize="18sp", textColor="#F44336", focusable=true, layout_weight="1", gravity="right"}
        },
        {Button, id="quitBtn", text="Quit Game", layout_width="fill", background="#333333", textColor="#FFFFFF"}
    }
    
    local view = loadlayout(layout, ids)
    activity.setContentView(view)

    -- --- Helper Functions ---
    
    -- Saves Win or Loss to SharedPreferences (Synced with profile.lua)
    local function saveGameResult(isWin)
        local editor = prefs.edit()
        if isWin then
            editor.putInt("wins", prefs.getInt("wins", 0) + 1)
        else
            editor.putInt("losses", prefs.getInt("losses", 0) + 1)
        end
        editor.apply()
    end

    -- Records Incomplete Match to SharedPreferences (Synced with profile.lua)
    local function recordQuit()
        local editor = prefs.edit()
        editor.putInt("quits", prefs.getInt("quits", 0) + 1)
        editor.apply()
    end

    local function showResult(title, message, isWin)
        if isWin then playSound(winSoundPath) else playSound(looseSoundPath) end
        
        AlertDialog.Builder(activity)
            .setTitle(title)
            .setMessage(message)
            .setCancelable(false)
            .setPositiveButton("OK", {onClick=function() 
                playSound(clickSoundPath) 
                showHome() 
            end})
            .show()
    end

    -- --- Button Listeners ---

    ids.boOptBtn.onClick = function()
        playSound(clickSoundPath)
        local mIds = {}
        local mLayout = {
            LinearLayout, orientation="vertical", padding="20dp",
            {Button, id="howBtn", text="How to Play", layout_width="fill"}
        }
        local mView = loadlayout(mLayout, mIds)
        local d = AlertDialog.Builder(activity).setTitle("Game Options").setView(mView).show()
        
        mIds.howBtn.onClick = function()
            playSound(clickSoundPath)
            d.dismiss()
            local hIds = {}
            local hLayout = {
                LinearLayout, orientation="vertical", padding="20dp",
                {TextView, text="How to Play Big One Wins", textSize="22sp", layout_marginBottom="15dp", textColor="#000000"},
                {TextView, text="In Big One Wins, both you and the robot roll two dice each. Your goal is to get a higher total sum than the robot. The first player to win 5 rounds wins the entire game. Good luck!", focusable=true, layout_marginBottom="25dp", textColor="#333333"},
                {Button, id="backBtn", text="Back to Game", layout_width="fill"}
            }
            local hView = loadlayout(hLayout, hIds)
            local hd = AlertDialog.Builder(activity).setView(hView).show()
            hIds.backBtn.onClick = function() playSound(clickSoundPath) hd.dismiss() end
        end
    end
    
    ids.quitBtn.onClick = function()
        playSound(clickSoundPath)
        AlertDialog.Builder(activity)
            .setTitle("Quit Game")
            .setMessage("Do you really want to quit? This will count as a quit in your stats.")
            .setPositiveButton("Quit", {onClick=function() 
                playSound(clickSoundPath)
                -- Only count as a quit if the match has actually started
                if playerScore > 0 or robotScore > 0 then
                    recordQuit()
                end
                showHome() 
            end})
            .setNegativeButton("Cancel", {onClick=function() playSound(clickSoundPath) end})
            .show()
    end

    ids.rollBtn.onClick = function()
        ids.rollBtn.setEnabled(false)
        playSound(diceSoundPath, function()
            local p1, p2 = math.random(1,6), math.random(1,6)
            local pT = p1 + p2
            local pMsg = currentUser.." got "..p1.." and Pe "..p2
            
            if announceTotal then pMsg = pMsg..". Total "..pT end
            ids.statusText.setText(pMsg)
            
            speak(pMsg, function()
                handler.postDelayed(Runnable{run=function()
                    playSound(diceSoundPath, function()
                        local r1, r2 = math.random(1,6), math.random(1,6)
                        local rT = r1 + r2
                        local rMsg = "Robot got "..r1.." and "..r2
                        
                        if announceTotal then rMsg = rMsg..". Total "..rT end
                        
                        local resText = ""
                        if pT > rT then 
                            playerScore = playerScore + 1 
                            resText = currentUser.." win this round"
                        elseif rT > pT then 
                            robotScore = robotScore + 1 
                            resText = "Robot win this round"
                        else 
                            resText = "Draw" 
                        end
                        
                        -- Update UI Nodes for Accessibility
                        ids.statusText.setText(pMsg.."\n"..rMsg.."\n"..resText)
                        ids.pScore.setText(currentUser.." Wins: "..playerScore)
                        ids.rScore.setText("Robot Wins: "..robotScore)
                        
                        speak(rMsg..". Pe "..resText, function()
                            if playerScore >= 5 then 
                                saveGameResult(true)
                                showResult("Congratulations!", "You have won the game against the Robot! Well played!", true)
                            elseif robotScore >= 5 then 
                                saveGameResult(false)
                                showResult("You Lost This Time", "The Robot won the game. Try again!", false)
                            else 
                                ids.rollBtn.setEnabled(true) 
                            end
                        end)
                    end)
                end}, 200)
            end)
        end)
    end
end

return bigOneWinsModule
