local GameLogicManager = {}

-- Load Both Game Modules
local bmnModule = require("beggar_my_neighbor")
local memoryModule = require("memory")

-- Safely get the activity context to prevent "LinearLayout@activity" crash
local function safeGetActivity(viewport, context)
    if context and context.activity then return context.activity end
    if _G.activity then return _G.activity end
    if type(viewport) == "userdata" and viewport.getContext then
        return viewport.getContext()
    end
    return nil
end

-- Progress Dialog bananay aur show karne ka function
local function showLoading(act, title, message)
    if act then
        import "android.app.ProgressDialog"
        local pd = ProgressDialog(act)
        pd.setTitle(title or "Loading")
        pd.setMessage(message or "Please wait...")
        pd.setCancelable(false) -- User screen par tap karke isay band na kar sakay
        pd.show()
        return pd
    end
    return nil
end

local function runBeggarmynaighbor(context, pd)
    local viewport = context.viewport
    local role = context.role
    local username = context.username
    local syncAction = context.syncAction

    if context.gameConfig and context.gameConfig.onGameReady then
        context.gameConfig.onGameReady({
            viewport = viewport,
            role = role,
            username = username,
            syncAction = syncAction
        })
    end
    
    local act = safeGetActivity(viewport, context)
    
    -- Dependencies map karke Start Online Method Call Karo (ALL sounds injected here now)
    local dependencies = {
        activity = act,
        prefs = act.getSharedPreferences("userdata", 0),
        editor = act.getSharedPreferences("userdata", 0).edit(),
        mainUI = context.mainUI or _G.mainUI,
        playSound = context.playSound or _G.playSound,
        playBGM = context.playBGM or _G.playBGM,
        winSound = context.winSound or _G.winSound,
        loseSound = context.loseSound or _G.loseSound,
        shuffleSound = context.shuffleSound or _G.shuffleSound,
        cardPlaySound = context.cardPlaySound or _G.cardPlaySound,
        bg = context.bg or _G.bg,
        wrapClick = context.wrapClick or _G.wrapClick,
        styleButton = context.styleButton or _G.styleButton
    }
    
    context.opponentName = context.opponentName or "Opponent"
    bmnModule.startOnline(dependencies, context)
    
    -- Game load hone ke baad Progress Bar hata dein
    if pd then pd.dismiss() end
end

local function runGameTwoLogic(context, pd)
    local viewport = context.viewport
    local role = context.role
    local username = context.username
    local syncAction = context.syncAction
    
    if context.gameConfig and context.gameConfig.onGameReady then
        context.gameConfig.onGameReady({
            viewport = viewport,
            role = role,
            username = username,
            syncAction = syncAction
        })
    end
    
    local act = safeGetActivity(viewport, context)
    
    local params = {
        activity = act,
        mainUI = context.mainUI or _G.mainUI,
        difficulty = context.difficulty or "Medium" 
    }
    
    context.opponentName = context.opponentName or "Opponent"
    
    -- Call the memory game online module logic
    memoryModule.startOnline(params, context)
    
    -- Game load hone ke baad Progress Bar hata dein
    if pd then pd.dismiss() end
end

local function runGameThreeLogic(context, pd)
    -- Add custom parameters, rules for Game 3 here
    if pd then pd.dismiss() end
end

function GameLogicManager.routeGameExecution(context)
    -- Game ke naam ko small letters mein convert karein taake matching mein ghalti na ho
    local targetGame = context.gameName and string.lower(context.gameName) or "beggarmynaighbor"
    local act = safeGetActivity(context.viewport, context)
    
    -- Sab se pehle Progress Dialog show karein
    local pd = showLoading(act, "Starting Game", "Game load ho rahi hai, please wait...")
    
    -- Handler use kar ke thora delay dein, taake UI par Loading popup render ho jaye hang hone se pehle
    if act then
        import "android.os.Handler"
        import "java.lang.Runnable"
        
        Handler().postDelayed(Runnable({
            run = function()
                -- Ab string.find use kar rahay hain, agar "memory" word aaya to MemoryGame chalegi
                if string.find(targetGame, "memory") or targetGame == "game two" then
                    runGameTwoLogic(context, pd)
                elseif string.find(targetGame, "game three") or targetGame == "gamethreename" then
                    runGameThreeLogic(context, pd)
                else
                    runBeggarmynaighbor(context, pd)
                end
            end
        }), 250) -- 250 milliseconds ka delay
    else
        -- Agar by chance activity nahi milti (jiska chance kam hai) to seedha chala dein
        if string.find(targetGame, "memory") or targetGame == "game two" then
            runGameTwoLogic(context, pd)
        elseif string.find(targetGame, "game three") or targetGame == "gamethreename" then
            runGameThreeLogic(context, pd)
        else
            runBeggarmynaighbor(context, pd)
        end
    end
end

return GameLogicManager
