local onlineEngineModule = {}

local DB_URL = "https://game-fa3dc-default-rtdb.firebaseio.com"
local Network = require("NetworkEngine")
local UIData = require("onlineEngineUI") 
local JoinRoomModule = require("join") 
local Helper = require("onlineEngineHelper")
local GameLogicManager = require("GameLogicManager")

function onlineEngineModule.showUniversalLobby(activity, prefs, params, gameConfig)
    import "android.app.*"
    import "android.os.*"
    import "android.widget.*"
    import "android.view.*"
    import "android.graphics.*"
    import "android.content.*" 
    import "org.json.JSONObject"
    import "org.json.JSONArray"
    import "android.speech.tts.TextToSpeech"
    import "java.lang.Runnable"
    import "android.text.InputFilter"
    import "android.media.MediaPlayer"
    import "java.io.File"

    local System = luajava.bindClass("java.lang.System")
    local function nowTimeMs() return System.currentTimeMillis() end

    local isActionInFlight, actionFlightTime, isNetworkAvailableCached, bgMusicPlayer = false, 0, true, nil
    local gameTitle = gameConfig.title or "Generic Game"
    local gamePathNode = gameTitle:gsub("%s+", "") 
    local currentRoom, myRole, gameCurrentState = "", "waiting", "MAIN_MENU"
    local myUsername = prefs.getString("username", "Player_" .. math.random(1000, 9999))
    local safeUsernameKey = myUsername:gsub("[%.$#%[%]/%s]", "_")
    local globalChatMuted, isMuteButtonCooldown, activeRoomHostName, syncScoreData = false, false, "", 0
    local selectedGameName, selectedGameHealth = "BEGGAR MY NEIGHBOR", "5" 
    local lastSyncedGameName, lastSyncedGameHealth, lastSyncedMuteState = "", "", nil
    
    local trackedOnlinePlayersMap, previousPlayerSlotsMap, joinSpeechGuards, establishedListeners = {}, {}, {}, {}
    local lastAudienceHashStr, lastWaitingHashStr, lastP1RowCacheStr, lastP2RowCacheStr, lastHeadingCacheStr, lastRawBodyCache = "", "", "", "", "", ""
    local lastHbTime, trackedHeartbeats, lastChatTimestamp = 0, {}, 0
    local player_names, player_statuses = { player1 = "Empty", player2 = "Empty" }, { player1 = "empty", player2 = "empty" }

    -- Performance and Accessibility Optimization Variables
    local currentPollInterval, idleCycles = 1500, 0
    local movementQueue, isProcessingMovement = {}, false
    local lastSpeechTime, recentMovements = 0, {}
    local activeDialogs = {} 

    -- FIX: Inter-module continuous syncing pointers
    local activeGameContext = nil
    local lastSeenSyncScore = 0

    local txtTotal, layoutGame, genericGameViewport, layoutOnlineMenu, btnStartMatchSignal
    local txtChatDisplay, btnInGameSendMsg, btnInGameChatHistory, btnUpdateGameRoom, btnToggleGlobalChat
    local txtPlayer1Row, txtPlayer2Row, txtAudienceHeading, txtWaitingListHeading 
    local containerAudienceList, containerWaitingList, layoutInGameControls, lblHeadingCustom
    local containerAvailableRoomsList, btnRefreshServerRooms, mainRoot, btnExitRoom
    
    local systemHandler = Handler(Looper.getMainLooper())
    local listenRunnable, menuListenRunnable = nil, nil

    local function safeUI(func)
        if activity and not activity.isFinishing() and not activity.isDestroyed() then activity.runOnUiThread(Runnable({run = func})) end
    end
    local function asyncNetwork(action) pcall(function() Network.executeTask(action) end) end
    local function updateTextIfChanged(view, newText)
        if view and tostring(view.getText()) ~= tostring(newText) then view.setText(tostring(newText)) end
    end
    local function setVisibilityIfChanged(view, visibility)
        if view and view.getVisibility() ~= visibility then view.setVisibility(visibility) end
    end
    local function safeName(n) return (not n or n == "") and "empty" or n:gsub("[%.$#%[%]/%s]", "_"):lower() end
    local function showToast(text) safeUI(function() Toast.makeText(activity, text, Toast.LENGTH_SHORT).show() end) end

    local ttsEngine = Helper.setupTTSEngine(activity, prefs)
    local function speakText(text)
        if ttsEngine then pcall(function()
            local paramsBundle = Bundle() paramsBundle.putFloat("volume", prefs.getInt("tts_volume", 100) / 100)
            ttsEngine.speak(text, TextToSpeech.QUEUE_ADD, paramsBundle, "engine_audio") 
        end) end
    end

    local function processedSpeakText(text, isMovement, playerName)
        local nowTime = os.time()
        if isMovement and playerName then
            if not recentMovements[playerName] then
                recentMovements[playerName] = { count = 1, lastTime = nowTime }
            else
                local mData = recentMovements[playerName]
                if nowTime - mData.lastTime < 4 then
                    mData.count = mData.count + 1
                    mData.lastTime = nowTime
                    if mData.count >= 2 then
                        if mData.timer then systemHandler.removeCallbacks(mData.timer) end
                        mData.timer = Runnable({run = function()
                            speakText(playerName .. " changed positions multiple times")
                            mData.count = 0
                        end})
                        systemHandler.postDelayed(mData.timer, 1500)
                        return
                    end
                else
                    mData.count = 1
                    mData.lastTime = nowTime
                end
            end
        end

        if not isMovement then
            if nowTime - lastSpeechTime < 2 then return end
        end

        lastSpeechTime = nowTime
        speakText(text)
    end

    local function playMainMenuMusic()
        pcall(function()
            if params then
                if type(params.pauseMusic) == "function" then pcall(params.pauseMusic) end
                if type(params.stopMusic) == "function" then pcall(params.stopMusic) end
                if type(params.stopMainMenuMusic) == "function" then pcall(params.stopMainMenuMusic) end
            end
            for _, player in ipairs({_G.bgMusicPlayer, _G.mediaPlayer, _G.bgMusic, _G.musicPlayer}) do
                if player and type(player.pause) == "function" then pcall(function() player.pause() end) end
            end
            if not bgMusicPlayer then
                local f = File(activity.getLuaDir() .. "/sounds/online.mp3")
                if f.exists() then
                    bgMusicPlayer = MediaPlayer() bgMusicPlayer.setDataSource(f.getAbsolutePath())
                    bgMusicPlayer.setLooping(true) bgMusicPlayer.prepare()
                end
            end
            if bgMusicPlayer and not bgMusicPlayer.isPlaying() then bgMusicPlayer.start() end
        end)
    end

    local function stopMainMenuMusic()
        if bgMusicPlayer then pcall(function() if bgMusicPlayer.isPlaying() then bgMusicPlayer.stop() end bgMusicPlayer.release() bgMusicPlayer = nil end) end
    end

    local lastClickClock = 0
    local function withNet(action)
        return function(...)
            if nowTimeMs() - lastClickClock < 400 then return end
            lastClickClock = nowTimeMs()
            if not isNetworkAvailableCached then
                safeUI(function() AlertDialog.Builder(activity).setTitle("No Internet").setMessage("Internet connection lost. Please connect to the internet.").setPositiveButton("OK", nil).show() end)
                return
            end
            if action then return action(...) end
        end
    end

    local wrapClick = function(view, action) (params.wrapClick or function(v, act) v.setOnClickListener(View.OnClickListener({onClick=act})) end)(view, withNet(action)) end
    local styleButton = params.styleButton or function(btn) end

    local fetchAndRefreshActiveRooms, startListeningEngine, startMenuListeningEngine, stopMenuListeningEngine, applyGenericRulesAndSync, handleDynamicPlayerManagement, showSmartExitConfirmation

    local function triggerEngineSyncUI() safeUI(function() if listenRunnable then systemHandler.removeCallbacks(listenRunnable) systemHandler.postDelayed(listenRunnable, 200) end end) end

    local function deepLockdownView(v)
        if not v then return end
        pcall(function()
            if v.setClickable then v.setClickable(false) end if v.setEnabled then v.setEnabled(false) end if v.setOnClickListener then v.setOnClickListener(nil) end
            if v.getChildCount then for idx = 0, v.getChildCount() - 1 do deepLockdownView(v.getChildAt(idx)) end end
        end)
    end

    local function stopListening() if listenRunnable then systemHandler.removeCallbacks(listenRunnable) listenRunnable = nil end end
    stopMenuListeningEngine = function() if menuListenRunnable then systemHandler.removeCallbacks(menuListenRunnable) menuListenRunnable = nil end end

    local function forceExitToMenu(msg)
        safeUI(function()
            stopListening()
            for _, d in ipairs(activeDialogs) do if d and d.isShowing() then d.dismiss() end end
            activeDialogs = {}
            if msg then showToast(msg) end
            Helper.clearLobbyDataAndViews({ containerAudienceList = containerAudienceList, containerWaitingList = containerWaitingList, txtChatDisplay = txtChatDisplay, txtPlayer1Row = txtPlayer1Row, txtPlayer2Row = txtPlayer2Row })
            lastAudienceHashStr, lastWaitingHashStr, lastP1RowCacheStr, lastP2RowCacheStr, lastHeadingCacheStr, lastRawBodyCache = "", "", "", "", "", ""
            trackedHeartbeats, trackedOnlinePlayersMap, previousPlayerSlotsMap, joinSpeechGuards = {}, {}, {}, {}
            currentRoom, myRole, gameCurrentState, activeRoomHostName, isActionInFlight = "", "waiting", "MAIN_MENU", "", false
            player_names, player_statuses = { player1 = "Empty", player2 = "Empty" }, { player1 = "empty", player2 = "empty" }
            lastChatTimestamp, syncScoreData, globalChatMuted = 0, 0, false
            lastSyncedGameName, lastSyncedGameHealth, lastSyncedMuteState = "", "", nil
            movementQueue, isProcessingMovement = {}, false
            currentPollInterval, idleCycles = 1500, 0
            
            activeGameContext = nil
            lastSeenSyncScore = 0
            
            if lblHeadingCustom then updateTextIfChanged(lblHeadingCustom, "CUSTOM ROOMS") end
            setVisibilityIfChanged(layoutGame, View.GONE) setVisibilityIfChanged(layoutOnlineMenu, View.VISIBLE)
            playMainMenuMusic() startMenuListeningEngine()
        end)
    end

    local function mutateRoomData(modifier, callback)
        local nodeTarget = DB_URL .. "/rooms/" .. gamePathNode .. "/" .. currentRoom .. ".json"
        asyncNetwork(function()
            Network.get(nodeTarget, function(body, success)
                if not success or not body or body == "null" or body == "" then 
                    isActionInFlight = false 
                    if callback then callback(false) end
                    return 
                end
                asyncNetwork(function() pcall(function()
                    local rObj = JSONObject(body)
                    if modifier(rObj) then 
                        Network.put(nodeTarget, rObj.toString(), function(ok) 
                            isActionInFlight = false 
                            triggerEngineSyncUI() 
                            if callback then callback(ok) end
                        end) 
                    else 
                        isActionInFlight = false 
                        if callback then callback(false) end
                    end
                end) end)
            end)
        end)
    end

    local function removePlayerFromArrays(rObj, pName)
        if rObj.optString("player1_name") == pName then rObj.put("player1_name", "Empty") rObj.put("player1_status", "empty") end
        if rObj.optString("player2_name") == pName then rObj.put("player2_name", "Empty") rObj.put("player2_status", "empty") end
        local function filter(arrName)
            local arr = rObj.has(arrName) and not rObj.isNull(arrName) and rObj.getJSONArray(arrName) or JSONArray()
            local newArr = JSONArray()
            for i=0, arr.length()-1 do if arr.getString(i) ~= pName and arr.getString(i) ~= "" then newArr.put(arr.getString(i)) end end
            rObj.put(arrName, newArr)
        end
        filter("audience") filter("waitingList")
    end

    local function joinRoomById(targetPathNode, roomKey)
        if not roomKey or roomKey == "" or not targetPathNode or targetPathNode == "" then return end
        if isActionInFlight then return end
        
        if not isNetworkAvailableCached then showToast("Waiting for network...") return end
        isActionInFlight = true
        stopMenuListeningEngine() 

        asyncNetwork(function()
            Network.get(DB_URL .. "/rooms/" .. targetPathNode .. "/" .. roomKey .. ".json", function(body, success)
                if not success or not body or body == "null" or body == "" then
                    isActionInFlight = false
                    startMenuListeningEngine()
                    showToast("Room no longer exists.")
                    return
                end
                
                local userIsBanned = false
                pcall(function()
                    local rObj = JSONObject(body)
                    local localKickBanStamp = rObj.optLong("banned_player_" .. safeName(myUsername), 0)
                    if localKickBanStamp > 0 and os.time() < localKickBanStamp then
                        userIsBanned = true
                    end
                end)

                if userIsBanned then
                    isActionInFlight = false
                    startMenuListeningEngine()
                    safeUI(function()
                        local bDialog = AlertDialog.Builder(activity)
                            .setTitle("Access Denied")
                            .setMessage("You are banned from this room.")
                            .setPositiveButton("OK", nil)
                            .show()
                        table.insert(activeDialogs, bDialog)
                    end)
                    return
                end

                systemHandler.postDelayed(Runnable({run = function()
                    JoinRoomModule.execute(roomKey, {
                        DB_URL = DB_URL, gamePathNode = targetPathNode, myUsername = myUsername, Network = Network, JSONObject = JSONObject, JSONArray = JSONArray,
                        asyncNetwork = asyncNetwork, safeUI = safeUI, safeName = safeName, getCurrentRoom = function() return currentRoom end,
                        setCurrentRoom = function(r) currentRoom = r end, setMyRole = function(r) myRole = r end, forceExitToMenu = function(m) isActionInFlight = false forceExitToMenu(m) end,
                        onJoinSuccess = function()
                            isActionInFlight = false
                            gamePathNode = targetPathNode 
                            stopMainMenuMusic()
                            trackedOnlinePlayersMap, previousPlayerSlotsMap, joinSpeechGuards = {}, {}, {}
                            setVisibilityIfChanged(layoutOnlineMenu, View.GONE) setVisibilityIfChanged(layoutGame, View.VISIBLE) 
                            gameCurrentState = "LOBBY" startListeningEngine() 
                        end
                    })
                end}), 150)
            end)
        end)
    end

    local function processExitFlow(shouldDeleteEntireRoom)
        local nodeTarget = DB_URL .. "/rooms/" .. gamePathNode .. "/" .. currentRoom .. ".json"
        local leavingRoomKey = currentRoom
        safeUI(function() forceExitToMenu(nil) end)
        
        if shouldDeleteEntireRoom then 
            asyncNetwork(function() Network.delete(nodeTarget, function() end) end) 
            return 
        end
        
        local backgroundNodeTarget = DB_URL .. "/rooms/" .. gamePathNode .. "/" .. leavingRoomKey .. ".json"
        asyncNetwork(function()
            Network.get(backgroundNodeTarget, function(body, success)
                if not success or not body or body == "null" or body == "" then return end
                pcall(function()
                    local rObj = JSONObject(body)
                    local currentHost = rObj.optString("hostName", "")
                    
                    if rObj.optString("player1_name") == myUsername then rObj.put("player1_name", "Empty") rObj.put("player1_status", "empty") end
                    if rObj.optString("player2_name") == myUsername then rObj.put("player2_name", "Empty") rObj.put("player2_status", "empty") end
                    
                    local function filter(arrName)
                        local arr = rObj.has(arrName) and not rObj.isNull(arrName) and rObj.getJSONArray(arrName) or JSONArray()
                        local newArr = JSONArray()
                        for i=0, arr.length()-1 do 
                            if arr.getString(i) ~= myUsername and arr.getString(i) ~= "" then newArr.put(arr.getString(i)) end 
                        end
                        rObj.put(arrName, newArr)
                    end
                    filter("audience") filter("waitingList")
                    
                    if currentHost == myUsername then
                        local candidateHost = "Empty"
                        for _, key in ipairs({"player1_name", "player2_name"}) do
                            local n = rObj.optString(key, "Empty") if n ~= "Empty" and n ~= "" then candidateHost = n break end
                        end
                        if candidateHost == "Empty" then
                            for _, arrKey in ipairs({"waitingList", "audience"}) do
                                if rObj.has(arrKey) and not rObj.isNull(arrKey) and rObj.getJSONArray(arrKey).length() > 0 then 
                                    candidateHost = rObj.getJSONArray(arrKey).getString(0) 
                                    break 
                                end
                            end
                        end
                        if candidateHost == "Empty" then 
                            Network.delete(backgroundNodeTarget) 
                            return 
                        end
                        rObj.put("hostName", candidateHost)
                    end
                    Network.put(backgroundNodeTarget, rObj.toString())
                end)
            end)
        end)
    end

    showSmartExitConfirmation = function()
        local container = LinearLayout(activity) container.setOrientation(LinearLayout.VERTICAL) container.setPadding(40, 20, 40, 20)
        local txtTitle = TextView(activity) txtTitle.setText("Exit Room?") txtTitle.setTextSize(20) txtTitle.setTypeface(Typeface.DEFAULT_BOLD) txtTitle.setTextColor(Color.WHITE) container.addView(txtTitle)
        local txtWarn = TextView(activity) txtWarn.setText("Are you sure you want to exit the custom room?") txtWarn.setTextSize(16) txtWarn.setTextColor(Color.WHITE) txtWarn.setPadding(0, 20, 0, 20) container.addView(txtWarn)
        local chkDelete = nil
        if activeRoomHostName == myUsername then chkDelete = CheckBox(activity) chkDelete.setText("Delete Room from Server") chkDelete.setTextColor(Color.WHITE) container.addView(chkDelete) end
        
        local exitDialog = AlertDialog.Builder(activity).setView(container)
        .setPositiveButton("Exit", DialogInterface.OnClickListener({
            onClick = function(dialog, which)
                withNet(function() processExitFlow(chkDelete and chkDelete.isChecked()) end)()
            end
        }))
        .setNegativeButton("Cancel", DialogInterface.OnClickListener({onClick = function() end}))
        .show()
        table.insert(activeDialogs, exitDialog)
    end

    local function applyOptimisticRoomsRecycler(roomListTemp)
        if not containerAvailableRoomsList or gameCurrentState ~= "MAIN_MENU" then return end
        local currentChildCount = containerAvailableRoomsList.getChildCount()
        
        if currentChildCount > 0 and tostring(containerAvailableRoomsList.getChildAt(0).getTag()) == "status_msg" then
            containerAvailableRoomsList.removeAllViews() currentChildCount = 0
        end

        local desiredCount = #roomListTemp
        for i = 1, math.max(currentChildCount, desiredCount) do
            if i <= desiredCount then
                local item = roomListTemp[i]
                local joinerCount = (item.p1 ~= "Empty" and item.p1 ~= "" and 1 or 0) + (item.p2 ~= "Empty" and item.p2 ~= "" and 1 or 0) + item.audCount + item.waitCount
                local formattedTime = item.time > 0 and os.date("%I:%M %p, %d %b %Y", item.time) or "Unknown Time"
                local modeText = (item.gameName ~= "BEGGAR MY NEIGHBOR" and item.gameMode ~= "") and (" (Mode: " .. item.gameMode .. ")") or ""
                local displayRoomTitleText = string.format("Room: %s\nGame: %s%s\nActive Since: %s\nTotal Joiners: %d", item.hostName:upper(), item.gameName, modeText, formattedTime, joinerCount)

                local roomRow, roomInfo, btnJoinItem
                if i <= currentChildCount then
                    roomRow = containerAvailableRoomsList.getChildAt(i - 1) setVisibilityIfChanged(roomRow, View.VISIBLE)
                    roomInfo, btnJoinItem = roomRow.getChildAt(0), roomRow.getChildAt(1)
                else
                    roomRow = LinearLayout(activity) roomRow.setOrientation(LinearLayout.HORIZONTAL) roomRow.setPadding(20, 25, 20, 25)
                    roomRow.setBackgroundColor(Color.parseColor("#FF262626")) roomRow.setGravity(Gravity.CENTER_VERTICAL)
                    local lp = LinearLayout.LayoutParams(-1, -2) lp.setMargins(0, 10, 0, 10) roomRow.setLayoutParams(lp)
                    
                    roomInfo = TextView(activity) roomInfo.setTextColor(Color.WHITE) roomInfo.setTextSize(14) roomInfo.setLineSpacing(0, 1.3)
                    roomInfo.setLayoutParams(LinearLayout.LayoutParams(0, -2, 1.0)) roomRow.addView(roomInfo)
                    
                    btnJoinItem = Button(activity) btnJoinItem.setText("JOIN") btnJoinItem.setBackgroundColor(Color.parseColor("#FF00AA55")) btnJoinItem.setTextColor(Color.WHITE)
                    roomRow.addView(btnJoinItem) containerAvailableRoomsList.addView(roomRow)
                end

                updateTextIfChanged(roomInfo, displayRoomTitleText) btnJoinItem.setTag(item.gamePathNode .. "|" .. tostring(item.key))
                
                local joinBtnId = tostring(btnJoinItem)
                if not establishedListeners[joinBtnId] then
                    establishedListeners[joinBtnId] = true wrapClick(btnJoinItem, function(v) 
                        local tagStr = tostring(v.getTag() or "") 
                        local sep = tagStr:find("|", 1, true)
                        if sep then joinRoomById(tagStr:sub(1, sep-1), tagStr:sub(sep+1)) end 
                    end)
                end
            else
                local child = containerAvailableRoomsList.getChildAt(i - 1)
                setVisibilityIfChanged(child, View.GONE) child.setTag("")
                if establishedListeners[tostring(child)] then child.setOnClickListener(nil) establishedListeners[tostring(child)] = nil end
            end
        end
    end

    fetchAndRefreshActiveRooms = function(silent)
        if gameCurrentState ~= "MAIN_MENU" then return end
        safeUI(function() if btnRefreshServerRooms then btnRefreshServerRooms.setEnabled(false) btnRefreshServerRooms.setText("Refreshing...") systemHandler.postDelayed(Runnable({run = function() if btnRefreshServerRooms then btnRefreshServerRooms.setEnabled(true) btnRefreshServerRooms.setText("Refresh") end end}), 5000) end end)
        
        asyncNetwork(function()
            Network.get(DB_URL .. "/rooms.json", function(body, connected)
                isNetworkAvailableCached = connected
                if not connected then
                    safeUI(function()
                        if btnRefreshServerRooms then btnRefreshServerRooms.setEnabled(true) btnRefreshServerRooms.setText("Refresh") end
                        if containerAvailableRoomsList then containerAvailableRoomsList.removeAllViews() local noConnTxt = TextView(activity) noConnTxt.setText("Network error. Please try again.") noConnTxt.setTextColor(Color.RED) noConnTxt.setGravity(Gravity.CENTER) noConnTxt.setTag("status_msg") containerAvailableRoomsList.addView(noConnTxt) end
                        if not silent then showToast("Connection failed! Retrying...") end
                    end) return
                end
                asyncNetwork(function()
                    local roomListTemp, trimmedBody = {}, body:gsub("^%s*(.-)%s*$", "%1")
                    local isValidData = (trimmedBody ~= "null" and trimmedBody ~= "" and trimmedBody ~= "{}")
                    if isValidData then
                        pcall(function()
                            local rootObj, nowTime = JSONObject(trimmedBody), os.time()
                            local gameCategories = rootObj.names()
                            if gameCategories then
                                for g = 0, gameCategories.length() - 1 do
                                    local cNode = gameCategories.getString(g)
                                    local roomsObj = rootObj.optJSONObject(cNode)
                                    if roomsObj then
                                        local keysArray = roomsObj.names()
                                        if keysArray then
                                            for i = 0, keysArray.length() - 1 do
                                                local roomKey = keysArray.getString(i) local sRoom = roomsObj.optJSONObject(roomKey)
                                                if sRoom then
                                                    local createdAt = sRoom.optLong("createdAtTimestamp", 0)
                                                    if createdAt > 0 and (nowTime - createdAt) >= 600 and sRoom.optString("gameState", "") ~= "STARTED" then Network.delete(DB_URL .. "/rooms/" .. cNode .. "/" .. roomKey .. ".json")
                                                    elseif sRoom.optString("gameState", "") == "WAITING" then
                                                        table.insert(roomListTemp, { key = roomKey, gamePathNode = cNode, hostName = sRoom.optString("hostName", "Unknown"), gameName = sRoom.optString("selectedGame", "Generic Game"), gameMode = sRoom.optString("gameHealthConfig", ""), p1 = sRoom.optString("player1_name", "Empty"), p2 = sRoom.optString("player2_name", "Empty"), audCount = sRoom.has("audience") and not sRoom.isNull("audience") and sRoom.getJSONArray("audience").length() or 0, waitCount = sRoom.has("waitingList") and not sRoom.isNull("waitingList") and sRoom.getJSONArray("waitingList").length() or 0, time = createdAt })
                                                    end
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end)
                    end
                    
                    safeUI(function()
                        if btnRefreshServerRooms then btnRefreshServerRooms.setEnabled(true) btnRefreshServerRooms.setText("Refresh") end
                        if #roomListTemp == 0 then 
                            if containerAvailableRoomsList then containerAvailableRoomsList.removeAllViews() local noRoomTxt = TextView(activity) noRoomTxt.setText("No Rooms Available to Join.") noRoomTxt.setTextColor(Color.parseColor("#88FFFFFF")) noRoomTxt.setGravity(Gravity.CENTER) noRoomTxt.setTag("status_msg") containerAvailableRoomsList.addView(noRoomTxt) end
                            return 
                        end
                        table.sort(roomListTemp, function(a, b) return a.time > b.time end) applyOptimisticRoomsRecycler(roomListTemp)
                        if not silent then showToast("Rooms refreshed successfully!") end
                    end)
                end)
            end)
        end)
    end

    startMenuListeningEngine = function() 
        stopMenuListeningEngine() 
        playMainMenuMusic() 
        fetchAndRefreshActiveRooms(false)
        menuListenRunnable = Runnable({
            run = function()
                if gameCurrentState == "MAIN_MENU" then
                    fetchAndRefreshActiveRooms(true)
                    systemHandler.postDelayed(menuListenRunnable, 5000)
                end
            end
        })
        systemHandler.postDelayed(menuListenRunnable, 5000)
    end

    local function patchRoomState(patchObj, callback)
        asyncNetwork(function() Network.patch(DB_URL .. "/rooms/" .. gamePathNode .. "/" .. currentRoom .. ".json", patchObj.toString(), callback) end)
    end

    local function openSendMessageCustomDialog()
        if globalChatMuted and activeRoomHostName ~= myUsername then showToast("Host has disabled all player messages!") return end
        local editMsg = EditText(activity) editMsg.setHint("Type message here...") editMsg.setTextColor(0xFF000000) editMsg.setFilters({InputFilter.LengthFilter(50)})
        local container = LinearLayout(activity) container.setOrientation(LinearLayout.VERTICAL) container.setPadding(45, 20, 45, 20) container.addView(editMsg)
        
        local cDialog = AlertDialog.Builder(activity).setTitle("Send Message").setView(container).setPositiveButton("Send", DialogInterface.OnClickListener({
            onClick = function(dialog, which)
                withNet(function()
                    local msgText = tostring(editMsg.getText()):gsub("^%s*(.-)%s*$", "%1") if msgText == "" then return end
                    safeUI(function() if txtChatDisplay then txtChatDisplay.setText("Chat: " .. myUsername:upper() .. " -> " .. msgText) end processedSpeakText("You say " .. msgText, false) end)

                    if btnInGameSendMsg then btnInGameSendMsg.setEnabled(false) systemHandler.postDelayed(Runnable({run = function() if btnInGameSendMsg then btnInGameSendMsg.setEnabled(true) end end}), 10000) end
                    pcall(function()
                        local ts = os.time() * 1000 local chatObj, patchData = JSONObject(), JSONObject()
                        chatObj.put("sender", myUsername:upper()) chatObj.put("text", msgText) chatObj.put("timestamp", ts)
                        patchData.put("chatHistory/" .. ts, chatObj) patchData.put("lastChat", chatObj)
                        patchRoomState(patchData, function(ok) if ok then triggerEngineSyncUI() end end)
                    end)
                end)()
            end
        })).setNegativeButton("Cancel", nil).show()
        table.insert(activeDialogs, cDialog)
    end

    local function openChatHistoryDialog()
        asyncNetwork(function()
            Network.get(DB_URL .. "/rooms/" .. gamePathNode .. "/" .. currentRoom .. "/chatHistory.json", function(body)
                if not body or body == "null" or body == "" then showToast("No chat history available!") return end
                asyncNetwork(function() pcall(function()
                    local cObj, keys, items, sortedKeys = JSONObject(body), JSONObject(body).names(), {}, {}
                    if keys then
                        for i = 0, keys.length() - 1 do table.insert(sortedKeys, keys.getString(i)) end table.sort(sortedKeys)
                        for _, k in ipairs(sortedKeys) do table.insert(items, cObj.getJSONObject(k).optString("sender") .. ": " .. cObj.getJSONObject(k).optString("text")) end
                    end
                    safeUI(function() local d = AlertDialog.Builder(activity).setTitle("Chat History").setItems(items, nil).setPositiveButton("Close", nil).show() table.insert(activeDialogs, d) end)
                end) end)
            end)
        end)
    end

    local function executeSlotMove(targetSlot, pName)
        local updated = false
        for i = #movementQueue, 1, -1 do
            if movementQueue[i].pName == pName then
                movementQueue[i].targetSlot = targetSlot
                updated = true
                break
            end
        end
        if not updated then
            table.insert(movementQueue, {targetSlot = targetSlot, pName = pName})
        end
        
        local function processMovementQueue()
            if isProcessingMovement or #movementQueue == 0 then return end
            isProcessingMovement = true
            
            local currentMove = table.remove(movementQueue, 1)
            local tSlot, pN = currentMove.targetSlot, currentMove.pName
            
            trackedOnlinePlayersMap[pN], previousPlayerSlotsMap[pN] = true, tSlot

            safeUI(function()
                local function wipe(container)
                    if container then 
                        for idx = 0, container.getChildCount() - 1 do 
                            local v = container.getChildAt(idx) 
                            if tostring(v.getTag()) == pN then 
                                setVisibilityIfChanged(v, View.GONE) 
                                v.setTag("") 
                                if establishedListeners[tostring(v)] then 
                                    v.setOnClickListener(nil) 
                                    establishedListeners[tostring(v)] = nil 
                                end 
                            end 
                        end 
                    end
                end
                wipe(containerAudienceList) 
                wipe(containerWaitingList)
                if txtPlayer1Row and tostring(txtPlayer1Row.getText()):find(pN:upper(), 1, true) then txtPlayer1Row.setText("Player One: EMPTY") end
                if txtPlayer2Row and tostring(txtPlayer2Row.getText()):find(pN:upper(), 1, true) then txtPlayer2Row.setText("Player Two: EMPTY") end
                
                local msgs = {player1="Player One", player2="Player Two", audience="Audience", waitingList="Waiting List"}
                if tSlot == "player1" and txtPlayer1Row then txtPlayer1Row.setText("Player One: " .. pN:upper() .. " - ONLINE") end
                if tSlot == "player2" and txtPlayer2Row then txtPlayer2Row.setText("Player Two: " .. pN:upper() .. " - ONLINE") end
                processedSpeakText(pN .. " moved to " .. (msgs[tSlot] or tSlot), true, pN)
            end)

            mutateRoomData(function(rObj)
                removePlayerFromArrays(rObj, pN)
                if tSlot == "player1" then 
                    rObj.put("player1_name", pN) 
                    rObj.put("player1_status", "joined")
                elseif tSlot == "player2" then 
                    rObj.put("player2_name", pN) 
                    rObj.put("player2_status", "joined")
                else 
                    local arr = rObj.has(tSlot) and not rObj.isNull(tSlot) and rObj.getJSONArray(tSlot) or JSONArray()
                    arr.put(pN)
                    rObj.put(tSlot, arr) 
                end
                return true
            end, function(ok)
                isProcessingMovement = false
                systemHandler.post(Runnable({run = processMovementQueue}))
            end)
        end
        
        processMovementQueue()
    end

    handleDynamicPlayerManagement = function(targetName, currentSlotType)
        if activeRoomHostName ~= myUsername then return end 
        local opts, actions = {}, {}
        
        if targetName == myUsername then
            if player_names["player1"] == "Empty" then table.insert(opts, "Move to Player 1 Seat") table.insert(actions, "MOVE_P1") end
            if player_names["player2"] == "Empty" then table.insert(opts, "Move to Player 2 Seat") table.insert(actions, "MOVE_P2") end
            if currentSlotType ~= "audience" then table.insert(opts, "Move to Audience") table.insert(actions, "MOVE_AUD") end
            if currentSlotType ~= "waitingList" then table.insert(opts, "Move to Waiting List") table.insert(actions, "MOVE_WAIT") end
        else
            table.insert(opts, "Kick Player") table.insert(actions, "KICK") table.insert(opts, "Transfer Online Ownership") table.insert(actions, "OWNER")
            if player_names["player1"] == "Empty" or player_names["player1"] == "" then table.insert(opts, "Move to Player 1") table.insert(actions, "MOVE_P1") end
            if player_names["player2"] == "Empty" or player_names["player2"] == "" then table.insert(opts, "Move to Player 2") table.insert(actions, "MOVE_P2") end
            if currentSlotType ~= "audience" then table.insert(opts, "Move to Audience") table.insert(actions, "MOVE_AUD") end
            if currentSlotType ~= "waitingList" then table.insert(opts, "Move to Waiting List") table.insert(actions, "MOVE_WAIT") end
        end

        local String = luajava.bindClass("java.lang.String") local optsArray = String[#opts]
        for i=1, #opts do optsArray[i-1] = opts[i] end

        local mDialog = AlertDialog.Builder(activity).setTitle("Manage: " .. targetName:upper()).setItems(optsArray, DialogInterface.OnClickListener({
            onClick = function(dialog, which)
                withNet(function()
                    local act = actions[which + 1]
                    if act == "KICK" then
                        if isActionInFlight and (nowTimeMs() - actionFlightTime < 2500) then return end
                        isActionInFlight, actionFlightTime = true, nowTimeMs()
                        safeUI(function() processedSpeakText("Kicking player " .. targetName, false) end)
                        mutateRoomData(function(rObj)
                            removePlayerFromArrays(rObj, targetName)
                            local sysObj = JSONObject() sysObj.put("sender", "SYSTEM") sysObj.put("text", targetName:upper() .. " kicked out.") sysObj.put("timestamp", os.time()*1000)
                            rObj.put("lastChat", sysObj) rObj.put("banned_player_" .. safeName(targetName), os.time() + 315360000)
                            return true
                        end)
                    elseif act == "OWNER" then safeUI(function() processedSpeakText("Transferring ownership to " .. targetName, false) end) pcall(function() local po = JSONObject() po.put("hostName", targetName) patchRoomState(po) end)
                    else executeSlotMove(act:sub(6):lower() == "p1" and "player1" or act:sub(6):lower() == "p2" and "player2" or act:sub(6):lower() == "aud" and "audience" or "waitingList", targetName) end
                end)()
            end
        })).show()
        table.insert(activeDialogs, mDialog)
    end

    local function openRoomConfigurationSetup(isUpdateMode)
        Helper.openRoomConfigurationSetup(activity, isUpdateMode, {
            selectedGameName = selectedGameName, selectedGameHealth = selectedGameHealth, wrapClickCallback = withNet,
            onUpdateExecuted = function(gameName, gameHealth)
                gameName = (gameName and gameName ~= "") and gameName or selectedGameName
                gameHealth = (gameHealth and gameHealth ~= "") and gameHealth or selectedGameHealth
                
                if isActionInFlight and (nowTimeMs() - actionFlightTime < 1000) then return end
                isActionInFlight, actionFlightTime = true, nowTimeMs()
                pcall(function() local patch = JSONObject() patch.put("selectedGame", gameName) patch.put("gameHealthConfig", gameHealth) patchRoomState(patch, function(s) isActionInFlight = false if s then showToast("Game mode dynamically updated!") triggerEngineSyncUI() end end) end)
            end,
            onCreateExecuted = function(gameName, gameHealth)
                gameName = (gameName and gameName ~= "") and gameName or selectedGameName
                gameHealth = (gameHealth and gameHealth ~= "") and gameHealth or selectedGameHealth
                
                selectedGameName = gameName
                selectedGameHealth = gameHealth
                local targetLocalPathNode = gameName:gsub("%s+", "")

                asyncNetwork(function() pcall(function()
                    currentRoom, activeRoomHostName = safeUsernameKey:lower() .. "_rm", myUsername
                    local jobj = JSONObject() jobj.put("syncScoreData", 0) jobj.put("maxLives", 5) jobj.put("maxPlayersLimit", 2) jobj.put("gameState", "WAITING") jobj.put("hostName", myUsername) jobj.put("selectedGame", gameName) jobj.put("gameHealthConfig", gameHealth) jobj.put("globalChatMuted", false) jobj.put("createdAtTimestamp", os.time()) jobj.put("player1_name", myUsername) jobj.put("player1_status", "joined") jobj.put("player1_life", 5) jobj.put("player2_name", "Empty") jobj.put("player2_status", "empty") jobj.put("player2_life", 5) jobj.put("audience", JSONArray()) jobj.put("waitingList", JSONArray()) jobj.put("hb_" .. safeName(myUsername), os.time())
                    
                    isActionInFlight = true 
                    Network.put(DB_URL .. "/rooms/" .. targetLocalPathNode .. "/" .. currentRoom .. ".json", jobj.toString(), function(ok) safeUI(function()
                        isActionInFlight = false 
                        if ok then 
                            gamePathNode = targetLocalPathNode
                            stopMenuListeningEngine() stopMainMenuMusic() trackedOnlinePlayersMap, previousPlayerSlotsMap, joinSpeechGuards = {}, {}, {} setVisibilityIfChanged(layoutOnlineMenu, View.GONE) setVisibilityIfChanged(layoutGame, View.VISIBLE) gameCurrentState = "LOBBY" startListeningEngine() if mainRoot then mainRoot.setFocusableInTouchMode(true) mainRoot.requestFocus() end 
                        end
                    end) end)
                end) end)
            end
        })
    end

    local function toggleGlobalChatMuteState()
        if activeRoomHostName ~= myUsername or isMuteButtonCooldown then return end
        isMuteButtonCooldown, globalChatMuted, lastSyncedMuteState = true, not globalChatMuted, not globalChatMuted
        safeUI(function()
            if btnToggleGlobalChat then btnToggleGlobalChat.setEnabled(false) btnToggleGlobalChat.setAlpha(0.5) btnToggleGlobalChat.setText(globalChatMuted and "Enable Messages" or "Disable All Messages") end
            processedSpeakText(globalChatMuted and "All player messages have been disabled" or "Player messages have been enabled", false)
            systemHandler.postDelayed(Runnable({run = function() isMuteButtonCooldown = false if btnToggleGlobalChat then btnToggleGlobalChat.setEnabled(true) btnToggleGlobalChat.setAlpha(1.0) end end}), 10000)
        end)
        pcall(function() local patch = JSONObject() patch.put("globalChatMuted", globalChatMuted) patchRoomState(patch) end)
    end

    local function applyDynamicLayoutRecycler(container, dataList, onActionClick)
        local childCount, desiredMap, usedNames = container.getChildCount(), {}, {}
        for _, data in ipairs(dataList) do desiredMap[data.name] = data end
        
        for i = 0, childCount - 1 do
            local child, boundName = container.getChildAt(i), tostring(container.getChildAt(i).getTag() or "")
            if boundName ~= "" and desiredMap[boundName] then
                setVisibilityIfChanged(child, View.VISIBLE) updateTextIfChanged(child, boundName:upper() .. (desiredMap[boundName].state ~= "ONLINE" and " (OFFLINE)" or "")) usedNames[boundName] = true
                if not establishedListeners[tostring(child)] then establishedListeners[tostring(child)] = true wrapClick(child, function(v) local bName = tostring(v.getTag() or "") if bName ~= "" and v.getVisibility() == View.VISIBLE then onActionClick(bName) end end) end
            else
                setVisibilityIfChanged(child, View.GONE) child.setTag("")
                if establishedListeners[tostring(child)] then child.setOnClickListener(nil) establishedListeners[tostring(child)] = nil end
            end
        end
        for _, data in ipairs(dataList) do
            if not usedNames[data.name] then
                local targetView = nil
                for i = 0, container.getChildCount() - 1 do if container.getChildAt(i).getVisibility() == View.GONE then targetView = container.getChildAt(i) break end end
                if not targetView then targetView = Button(activity) targetView.setTransformationMethod(nil) styleButton(targetView) container.addView(targetView) end
                targetView.setTag(data.name) setVisibilityIfChanged(targetView, View.VISIBLE) updateTextIfChanged(targetView, data.name:upper() .. (data.state ~= "ONLINE" and " (OFFLINE)" or ""))
                if not establishedListeners[tostring(targetView)] then establishedListeners[tostring(targetView)] = true wrapClick(targetView, function(v) local bName = tostring(v.getTag() or "") if bName ~= "" and v.getVisibility() == View.VISIBLE then onActionClick(bName) end end) end
            end
        end
    end

    startListeningEngine = function()
        stopListening() lastRawBodyCache = ""
        listenRunnable = Runnable({
            run = function()
                if not listenRunnable then return end

                local now = os.time()
                asyncNetwork(function()
                    if now - lastHbTime >= 6 then pcall(function() local po = JSONObject() po.put("hb_" .. safeName(myUsername), now) patchRoomState(po) end) lastHbTime = now end
                    Network.get(DB_URL .. "/rooms/" .. gamePathNode .. "/" .. currentRoom .. ".json", function(body, statusOk)
                        isNetworkAvailableCached = statusOk
                        
                        local function scheduleNextPoll() 
                            safeUI(function() 
                                if listenRunnable then 
                                    systemHandler.removeCallbacks(listenRunnable)
                                    systemHandler.postDelayed(listenRunnable, currentPollInterval) 
                                end 
                            end) 
                        end

                        if not statusOk or isActionInFlight then scheduleNextPoll() return end
                        if not body or body == "null" or body == "" then forceExitToMenu("Room was deleted or closed by host.") return end
                        
                        if body == lastRawBodyCache then 
                            idleCycles = idleCycles + 1
                            if idleCycles > 15 then
                                currentPollInterval = 3000
                            elseif idleCycles > 5 then
                                currentPollInterval = 1500
                            end
                            scheduleNextPoll() 
                            return 
                        end
                        
                        lastRawBodyCache = body
                        currentPollInterval = 1000
                        idleCycles = 0

                        local success = pcall(function()
                            local jobj, liveTime = JSONObject(body), os.time()
                            local localKickBanStamp = jobj.optLong("banned_player_" .. safeName(myUsername), 0)
                            
                            if localKickBanStamp > 0 and liveTime < localKickBanStamp then 
                                pcall(function() if prefs and prefs.edit then prefs.edit().putLong("kick_ban_" .. currentRoom, localKickBanStamp).apply() end end)
                                safeUI(function() deepLockdownView(layoutGame) forceExitToMenu("You were kicked out of the room by Host!") end) 
                                return 
                            end

                            local function getPlayerState(pName)
                                if pName == "Empty" or pName == "" then return "EMPTY" end
                                local hb = jobj.optLong("hb_" .. safeName(pName), 0)
                                if not trackedHeartbeats[pName] then trackedHeartbeats[pName] = { value = hb, localTime = liveTime } return "ONLINE" end
                                if trackedHeartbeats[pName].value ~= hb then trackedHeartbeats[pName].value = hb trackedHeartbeats[pName].localTime = liveTime return "ONLINE" end
                                return (liveTime - trackedHeartbeats[pName].localTime > 18) and "OFFLINE" or "ONLINE"
                            end

                            local state, currentLiveGame, currentLiveHealth, createdTime = jobj.optString("gameState", "WAITING"), jobj.optString("selectedGame", "BEGGAR MY NEIGHBOR"), jobj.optString("gameHealthConfig", "5"), jobj.optLong("createdAtTimestamp", 0)
                            activeRoomHostName, syncScoreData, globalChatMuted = jobj.optString("hostName", "Admin"), jobj.optInt("syncScoreData", 0), jobj.optBoolean("globalChatMuted", false)
                            
                            local formattedHeading = currentLiveGame:upper() .. (currentLiveGame ~= "BEGGAR MY NEIGHBOR" and " (" .. currentLiveHealth .. ")" or "")
                            local amIStillInRoom, seenNames, currentActivePlayersList = false, {}, {}

                            local function reg(pName, slot) if pName == "Empty" or pName == "" or seenNames[pName] then return false end seenNames[pName], currentActivePlayersList[pName] = true, slot return true end
                            
                            local p1NameServer, p2NameServer = reg(jobj.optString("player1_name"), "player1") and jobj.optString("player1_name") or "Empty", reg(jobj.optString("player2_name"), "player2") and jobj.optString("player2_name") or "Empty"
                            if p1NameServer == myUsername then myRole, amIStillInRoom = "player1", true elseif p2NameServer == myUsername then myRole, amIStillInRoom = "player2", true else myRole = "spectator" end

                            local audCount, waitCount, audienceHashBuilder, waitingHashBuilder, computedAudList, computedWaitList = 0, 0, {}, {}, {}, {}
                            local function parseList(arrKey, slot, cList, hBuild)
                                if jobj.has(arrKey) and not jobj.isNull(arrKey) then
                                    local arr = jobj.getJSONArray(arrKey)
                                    for i=0, arr.length()-1 do
                                        local n = arr.getString(i)
                                        if reg(n, slot) then local pState = getPlayerState(n) table.insert(hBuild, n .. ":" .. pState) table.insert(cList, {name=n, state=pState}) if n == myUsername then myRole, amIStillInRoom = slot, true end end
                                    end
                                end
                            end
                            parseList("audience", "audience", computedAudList, audienceHashBuilder) parseList("waitingList", "waitingList", computedWaitList, waitingHashBuilder)
                            audCount, waitCount = #computedAudList, #computedWaitList

                            local p1_ActiveReady, p2_ActiveReady, computedP1RowStr, computedP2RowStr = false, false, "", ""
                            for i = 1, 2 do
                                local pName = i == 1 and p1NameServer or p2NameServer
                                local pStat = pName == "Empty" and "empty" or jobj.optString("player" .. i .. "_status", "empty")
                                player_names["player"..i], player_statuses["player"..i] = pName, pStat
                                local liveDisplayStatus = pName == "Empty" and "EMPTY" or getPlayerState(pName)
                                local formattedRowStr = string.format("Player %s: %s - %s", i == 1 and "One" or "Two", pName:upper(), liveDisplayStatus)
                                if i == 1 then computedP1RowStr = formattedRowStr if pStat == "joined" and liveDisplayStatus == "ONLINE" then p1_ActiveReady = true end else computedP2RowStr = formattedRowStr if pStat == "joined" and liveDisplayStatus == "ONLINE" then p2_ActiveReady = true end end
                            end
                            
                            local lastChatObj = nil
                            if jobj.has("lastChat") and not jobj.isNull("lastChat") then local cObj = jobj.getJSONObject("lastChat") local cTime = cObj.optLong("timestamp", 0) if cTime > lastChatTimestamp then lastChatObj = { time = cTime, sender = cObj.optString("sender"), text = cObj.optString("text") } end end

                            safeUI(function()
                                if createdTime > 0 and (liveTime - createdTime) >= 600 and state ~= "STARTED" then asyncNetwork(function() Network.delete(DB_URL .. "/rooms/" .. gamePathNode .. "/" .. currentRoom .. ".json", nil) end) forceExitToMenu("Room strictly expired.") return end
                                if not amIStillInRoom then forceExitToMenu("You have been removed from the room!") return end

                                if lastHeadingCacheStr ~= formattedHeading then lastHeadingCacheStr = formattedHeading if lblHeadingCustom then updateTextIfChanged(lblHeadingCustom, formattedHeading) end end

                                local currentAudienceHashStr = table.concat(audienceHashBuilder, ",")
                                if lastAudienceHashStr ~= currentAudienceHashStr then lastAudienceHashStr = currentAudienceHashStr applyDynamicLayoutRecycler(containerAudienceList, computedAudList, function(n) handleDynamicPlayerManagement(n, "audience") end) end
                                updateTextIfChanged(txtAudienceHeading, "Audience (" .. audCount .. ")")
                                
                                local currentWaitingHashStr = table.concat(waitingHashBuilder, ",")
                                if lastWaitingHashStr ~= currentWaitingHashStr then lastWaitingHashStr = currentWaitingHashStr applyDynamicLayoutRecycler(containerWaitingList, computedWaitList, function(n) handleDynamicPlayerManagement(n, "waitingList") end) end
                                updateTextIfChanged(txtWaitingListHeading, "Waiting List (" .. waitCount .. ")")

                                for pName, currentSlot in pairs(currentActivePlayersList) do
                                    if not trackedOnlinePlayersMap[pName] then
                                        trackedOnlinePlayersMap[pName], previousPlayerSlotsMap[pName] = true, currentSlot
                                        if not joinSpeechGuards[pName] then joinSpeechGuards[pName] = true processedSpeakText(pName .. " entered the lobby", false) end
                                    elseif previousPlayerSlotsMap[pName] ~= currentSlot then 
                                        previousPlayerSlotsMap[pName] = currentSlot 
                                        local slotNames = {player1="Player One", player2="Player Two", audience="Audience", waitingList="Waiting List"}
                                        processedSpeakText(pName .. " moved to " .. (slotNames[currentSlot] or currentSlot), true, pName) 
                                    end
                                end
                                for oldPlayer, _ in pairs(trackedOnlinePlayersMap) do if not currentActivePlayersList[oldPlayer] then trackedOnlinePlayersMap[oldPlayer], previousPlayerSlotsMap[oldPlayer], joinSpeechGuards[oldPlayer] = nil, nil, nil end end

                                local hostVis = (activeRoomHostName == myUsername) and View.VISIBLE or View.GONE
                                setVisibilityIfChanged(btnToggleGlobalChat, hostVis)

                                if lastSyncedMuteState ~= globalChatMuted then lastSyncedMuteState = globalChatMuted processedSpeakText(globalChatMuted and "Messages disabled" or "Messages enabled", false) end
                                if lastSyncedGameName ~= currentLiveGame or lastSyncedGameHealth ~= currentLiveHealth then 
                                    lastSyncedGameName, lastSyncedGameHealth = currentLiveGame, currentLiveHealth 
                                    selectedGameName, selectedGameHealth = currentLiveGame, currentLiveHealth
                                    processedSpeakText("Game dynamic layout changed", false) 
                                end

                                if lastP1RowCacheStr ~= computedP1RowStr then lastP1RowCacheStr = computedP1RowStr updateTextIfChanged(txtPlayer1Row, computedP1RowStr) end
                                if lastP2RowCacheStr ~= computedP2RowStr then lastP2RowCacheStr = computedP2RowStr updateTextIfChanged(txtPlayer2Row, computedP2RowStr) end
                                
                                if lastChatObj and lastChatTimestamp ~= lastChatObj.time then
                                    lastChatTimestamp = lastChatObj.time updateTextIfChanged(txtChatDisplay, "Chat: " .. lastChatObj.sender .. " -> " .. lastChatObj.text)
                                    if lastChatObj.sender:upper() ~= myUsername:upper() then 
                                        systemHandler.postDelayed(Runnable({ run = function() processedSpeakText(lastChatObj.sender .. " say " .. lastChatObj.text, false) end }), 200) 
                                    end
                                end
                                
                                if state == "WAITING" then
                                    gameCurrentState = "LOBBY" 
                                    setVisibilityIfChanged(btnStartMatchSignal, hostVis) 
                                    btnStartMatchSignal.setEnabled(p1_ActiveReady or p2_ActiveReady) 
                                    setVisibilityIfChanged(layoutInGameControls, View.GONE)
                                    
                                    setVisibilityIfChanged(containerAudienceList, View.VISIBLE)
                                    setVisibilityIfChanged(txtAudienceHeading, View.VISIBLE)
                                    setVisibilityIfChanged(containerWaitingList, View.VISIBLE)
                                    setVisibilityIfChanged(txtWaitingListHeading, View.VISIBLE)
                                    setVisibilityIfChanged(btnUpdateGameRoom, hostVis)
                                    setVisibilityIfChanged(txtPlayer1Row, View.VISIBLE)
                                    setVisibilityIfChanged(txtPlayer2Row, View.VISIBLE)
                                    
                                elseif state == "STARTED" then
                                    setVisibilityIfChanged(btnUpdateGameRoom, View.GONE) 
                                    if gameCurrentState ~= "STARTED" then
                                        gameCurrentState = "STARTED" 
                                        setVisibilityIfChanged(btnStartMatchSignal, View.GONE) 
                                        setVisibilityIfChanged(layoutInGameControls, View.VISIBLE)
                                        
                                        setVisibilityIfChanged(containerAudienceList, View.GONE)
                                        setVisibilityIfChanged(txtAudienceHeading, View.GONE)
                                        setVisibilityIfChanged(containerWaitingList, View.GONE)
                                        setVisibilityIfChanged(txtWaitingListHeading, View.GONE)
                                        setVisibilityIfChanged(txtPlayer1Row, View.GONE)
                                        setVisibilityIfChanged(txtPlayer2Row, View.GONE)
                                        
                                        if btnInGameSendMsg then setVisibilityIfChanged(btnInGameSendMsg, View.VISIBLE) btnInGameSendMsg.bringToFront() end
                                        if btnInGameChatHistory then setVisibilityIfChanged(btnInGameChatHistory, View.VISIBLE) btnInGameChatHistory.bringToFront() end
                                        if btnToggleGlobalChat then btnToggleGlobalChat.bringToFront() end
                                        if btnExitRoom then setVisibilityIfChanged(btnExitRoom, View.VISIBLE) btnExitRoom.bringToFront() end
                                        
                                        -- Save game context instance
                                        lastSeenSyncScore = jobj.optInt("syncScoreData", 0)
                                        activeGameContext = {
                                            gameName = currentLiveGame,
                                            gameHealth = currentLiveHealth,
                                            viewport = genericGameViewport,
                                            role = myRole,
                                            username = myUsername,
                                            syncAction = applyGenericRulesAndSync,
                                            roomSnapshot = jobj,
                                            gameConfig = gameConfig
                                        }
                                        GameLogicManager.routeGameExecution(activeGameContext)
                                    else
                                        -- FIX: Continuous lifecycle state execution parser
                                        if syncScoreData > lastSeenSyncScore then
                                            lastSeenSyncScore = syncScoreData
                                            if activeGameContext and activeGameContext.onReceiveSync then
                                                activeGameContext.onReceiveSync({action = "playCard"})
                                            end
                                        end
                                    end
                                    updateTextIfChanged(txtTotal, "Global Sync Data: " .. syncScoreData)
                                end
                                scheduleNextPoll()
                            end)
                        end)
                        if not success then scheduleNextPoll() end
                    end)
                end)
            end
        })
        systemHandler.postDelayed(listenRunnable, 1000)
    end

    applyGenericRulesAndSync = function(updatedScore, actionText, forceNextTurn)
        pcall(function() local patch = JSONObject() patch.put("syncScoreData", updatedScore) patch.put("gameState", "STARTED") patch.put("turn", forceNextTurn) patchRoomState(patch) end)
    end

    mainRoot = FrameLayout(activity) mainRoot.setFocusable(true) mainRoot.setFocusableInTouchMode(true) mainRoot.requestFocus() activity.setContentView(mainRoot)
    local gv = {}
    layoutOnlineMenu, layoutGame = loadlayout(UIData.onlineMenuUI, gv), loadlayout(UIData.gameUI, gv)
    layoutGame.setVisibility(View.GONE)

    btnStartMatchSignal, txtTotal, genericGameViewport, txtChatDisplay, btnInGameSendMsg, btnInGameChatHistory = gv.btnStartMatchSignal, gv.txtTotal, gv.genericGameViewport, gv.txtChatDisplay, gv.btnInGameSendMsg, gv.btnInGameChatHistory
    btnUpdateGameRoom, btnToggleGlobalChat, txtPlayer1Row, txtPlayer2Row, txtAudienceHeading, txtWaitingListHeading = gv.btnUpdateGameRoom, gv.btnToggleGlobalChat, gv.txtPlayer1Row, gv.txtPlayer2Row, gv.txtAudienceHeading, gv.txtWaitingListHeading
    containerAudienceList, containerWaitingList, layoutInGameControls, containerAvailableRoomsList, lblHeadingCustom, btnRefreshServerRooms, btnExitRoom = gv.containerAudienceList, gv.containerWaitingList, gv.layoutInGameControls, gv.containerAvailableRoomsList, gv.lblHeadingCustom, gv.btnRefreshServerRooms, gv.btnExitRoom 

    if lblHeadingCustom then lblHeadingCustom.setTypeface(Typeface.DEFAULT_BOLD) end

    wrapClick(gv.btnBackMenu, function() stopMenuListeningEngine() stopMainMenuMusic() setVisibilityIfChanged(layoutGame, View.GONE) gameCurrentState = "MAIN_MENU" params.mainUI() end)
    wrapClick(gv.btnRefreshServerRooms, function() fetchAndRefreshActiveRooms(false) end)
    wrapClick(gv.btnCreateNewRoom, function() openRoomConfigurationSetup(false) end)
    wrapClick(gv.btnExitRoom, showSmartExitConfirmation)
    wrapClick(gv.btnInGameSendMsg, openSendMessageCustomDialog)
    wrapClick(gv.btnInGameChatHistory, openChatHistoryDialog)
    wrapClick(gv.btnUpdateGameRoom, function() openRoomConfigurationSetup(true) end)
    wrapClick(gv.btnToggleGlobalChat, toggleGlobalChatMuteState)
    
    wrapClick(btnStartMatchSignal, function()
        if player_names["player1"] == "Empty" or player_names["player1"] == "" or player_names["player2"] == "Empty" or player_names["player2"] == "" then
            showToast("This game requires a minimum of 2 players.")
            processedSpeakText("This game requires a minimum of 2 players.", false)
            return
        end
        pcall(function() 
            local sObj = JSONObject() 
            sObj.put("gameState", "STARTED") 
            sObj.put("turn", "player1")
            sObj.put("waitingList", JSONObject.NULL) 
            patchRoomState(sObj, function() safeUI(function() startListeningEngine() end) end) 
        end) 
    end)
    
    wrapClick(txtPlayer1Row, function() if player_names["player1"] ~= "Empty" then handleDynamicPlayerManagement(player_names["player1"], "player1") end end)
    wrapClick(txtPlayer2Row, function() if player_names["player2"] ~= "Empty" then handleDynamicPlayerManagement(player_names["player2"], "player2") end end)

    for _, btn in ipairs({gv.btnBackMenu, btnRefreshServerRooms, gv.btnCreateNewRoom, btnStartMatchSignal, btnInGameSendMsg, btnInGameChatHistory, btnUpdateGameRoom, btnToggleGlobalChat, gv.btnExitRoom}) do styleButton(btn) end
    mainRoot.addView(layoutOnlineMenu) mainRoot.addView(layoutGame)

    local function handleGlobalBackAction()
        if gameCurrentState == "LOBBY" or gameCurrentState == "STARTED" then showSmartExitConfirmation() return true
        elseif gameCurrentState == "MAIN_MENU" then stopMenuListeningEngine() stopMainMenuMusic() params.mainUI() return true end
        return false
    end

    mainRoot.setOnKeyListener(View.OnKeyListener({ onKey = function(view, keyCode, event) if keyCode == KeyEvent.KEYCODE_BACK then return event.getAction() == KeyEvent.ACTION_UP and handleGlobalBackAction() or event.getAction() == KeyEvent.ACTION_DOWN end return false end }))
    pcall(function()
        local originalOnBackPressed = activity.onBackPressed
        activity.onBackPressed = function() if not handleGlobalBackAction() and originalOnBackPressed then originalOnBackPressed() end end
    end)

    startMenuListeningEngine()
end

return onlineEngineModule 
