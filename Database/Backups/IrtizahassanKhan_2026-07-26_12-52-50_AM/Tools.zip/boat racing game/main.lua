require "import"
import "android.widget.*"
import "android.view.*"
import "android.content.*"
import "android.app.*"
import "android.graphics.Color"
import "android.media.MediaPlayer"
import "android.media.PlaybackParams"
import "android.os.Build"
import "android.os.Handler"
import "android.os.Looper"
import "android.speech.tts.TextToSpeech"
import "java.util.Locale"

this.setTheme(android.R.style.Theme_NoTitleBar_Fullscreen)

-- UI Nodes
local dlgMenu = nil
local dlgMapSelect = nil
local dlgBoatSelect = nil
local dlgGame = nil

-- Audio Engines
local bgPlayer = nil        
local racingPlayer = nil    
local robotPlayer = nil     
local ttsEngine = nil       
local isTtsReady = false

-- Game State Metrics
local isEngineStarted = false
local isSwipeActive = false
local isCountingDown = false
local currentCalculatedSpeed = 0.0  
local currentActiveVolume = 0.5
local selectedMapName = ""

-- Trackers & Coordinates (-1 = Left, 0 = Center, 1 = Right)
local playerTrack = 0       
local robotTrack = 0        
local playerDistance = 0.0
local robotDistance = 0.0
local lastPlayerAnnouncedDistance = 0
local lastRobotAnnouncedDistance = 0
local RACE_LIMIT = 5000 

-- Infinite Ocean Sandbox & Deep Warning Control
local playerDriftDistance = 0   
local robotDriftDistance = 0
local isDeepOceanWarned = false

-- Gesture Anchors
local xStart, yStart = 0, 0
local MIN_SWIPE_DISTANCE = 130 

-- Thread Handlers
local mainHandler = Handler(Looper.getMainLooper())
local gameLoopRunnable = nil
local decelerationRunnable = nil

-- Audio Files Path
local arcticOceanPath = "/storage/emulated/0/解说/Tools/boat racing game/mixkit-small-waves-harbor-rocks-1208_143941208.mp3"
local southernOceanPath = "/storage/emulated/0/解说/Tools/boat racing game/Southern ocean .mp3"
local oldBoatPath = "/storage/emulated/0/解说/Tools/boat racing game/personal motor board .mp3"
local advanceBoatPath = "/storage/emulated/0/解说/Tools/boat racing game/advance motor boat .mp3"

-- Boat Metrics (Speed per 150ms tick: Old = 20s for 100m, Advance = 15s for 100m)
local OLD_BOAT_SPEED = 0.75 
local ADVANCE_BOAT_SPEED = 1.00 
local playerAudioPath = ""
local robotAudioPath = ""
local playerSpeedMultiplier = 0.0
local robotSpeedMultiplier = 0.0
local playerBoatName = ""

-- Forward Functions
local openMainMenuWindow, openMapSelectionWindow, openBoatSelectionWindow, openGamePlayWindow
local stopAllAudio, startOceanBg, updateDynamicHardwareAudio, startGradualDeceleration
local speakStatus, startGameLoop, startCountdownSystem

-- ==========================================
-- 1. ACCESSIBLE TTS ENGINE
-- ==========================================
local ttsListener = luajava.createProxy("android.speech.tts.TextToSpeech$OnInitListener", {
  onInit = function(status)
    if status == TextToSpeech.SUCCESS then
      if ttsEngine then
        ttsEngine.setLanguage(Locale.US)
        ttsEngine.setPitch(1.0)
        ttsEngine.setSpeechRate(1.35) 
        isTtsReady = true
      end
    end
  end
})

pcall(function()
  ttsEngine = TextToSpeech(this, ttsListener)
end)

speakStatus = function(text)
  if ttsEngine and isTtsReady then
    if Build.VERSION.SDK_INT >= 21 then
      ttsEngine.speak(text, TextToSpeech.QUEUE_FLUSH, nil, "BoatRaceTTS")
    else
      ttsEngine.speak(text, TextToSpeech.QUEUE_FLUSH, nil)
    end
  end
end

-- ==========================================
-- 2. DYNAMIC HARDWARE AUDIO & PITCH SCALING ENGINE
-- ==========================================
startOceanBg = function(path)
  pcall(function()
    if bgPlayer == nil then
      bgPlayer = MediaPlayer()
      bgPlayer.setDataSource(path)
      bgPlayer.prepare()
      bgPlayer.setLooping(true)
    end
    if not bgPlayer.isPlaying() then
      local bgVol = currentActiveVolume * 0.35 
      bgPlayer.setVolume(bgVol, bgVol)
      bgPlayer.start()
    end
  end)
end

updateDynamicHardwareAudio = function(targetSpeed)
  pcall(function()
    if not isEngineStarted then return end

    -- Player Boat Engine Sound & Dynamic Pitch Scaling
    if racingPlayer == nil then
      racingPlayer = MediaPlayer()
      racingPlayer.setDataSource(playerAudioPath)
      racingPlayer.prepare()
      racingPlayer.setLooping(true)
    end
    
    if not racingPlayer.isPlaying() then racingPlayer.start() end

    if targetSpeed <= 0.05 then
      racingPlayer.setVolume(0.35, 0.35) 
      if Build.VERSION.SDK_INT >= 23 then
        local pParams = PlaybackParams()
        pParams.setPitch(0.7) 
        pParams.setSpeed(0.7)  
        racingPlayer.setPlaybackParams(pParams)
      end
    else
      local dynamicVolume = 0.35 + (targetSpeed * 0.65) 
      if dynamicVolume > 1.0 then dynamicVolume = 1.0 end
      racingPlayer.setVolume(dynamicVolume, dynamicVolume)
      
      if Build.VERSION.SDK_INT >= 23 then
        local pParams = PlaybackParams()
        local dynamicPitch = 0.7 + (targetSpeed * 0.8)  -- Dynamic pitch scaling based on speed
        local dynamicSpeed = 0.7 + (targetSpeed * 0.8)  -- Dynamic playback speed scaling
        pParams.setPitch(dynamicPitch)
        pParams.setSpeed(dynamicSpeed)
        racingPlayer.setPlaybackParams(pParams)
      end
    end

    -- Robot Boat Engine Sound
    if robotPlayer == nil then
      robotPlayer = MediaPlayer()
      robotPlayer.setDataSource(robotAudioPath)
      robotPlayer.prepare()
      robotPlayer.setLooping(true)
    end
    
    local yDistance = math.abs(playerDistance - robotDistance)
    local xDistance = math.abs(playerDriftDistance - robotDriftDistance)
    local totalDistanceGap = math.sqrt((yDistance * yDistance) + (xDistance * xDistance))
    
    local MAX_AUDIBLE_RANGE = 550 
    local volumeModifier = 1.0 - (totalDistanceGap / MAX_AUDIBLE_RANGE)
    if volumeModifier < 0 then volumeModifier = 0 end
    
    if volumeModifier <= 0.01 or isDeepOceanWarned then
      if robotPlayer.isPlaying() then robotPlayer.pause() end
    else
      if not robotPlayer.isPlaying() then robotPlayer.start() end
      
      local robotBaseVol = 0.65 * volumeModifier
      local leftVol = robotBaseVol
      local rightVol = robotBaseVol
      
      if robotDriftDistance < playerDriftDistance then
        rightVol = rightVol * 0.10
      elseif robotDriftDistance > playerDriftDistance then
        leftVol = leftVol * 0.10
      end
      
      robotPlayer.setVolume(leftVol, rightVol)
      
      if Build.VERSION.SDK_INT >= 23 then
        local rParams = PlaybackParams()
        rParams.setPitch(0.95) 
        rParams.setSpeed(0.85) 
        robotPlayer.setPlaybackParams(rParams)
      end
    end
  end)
end

-- ==========================================
-- 3. ACCESSIBLE DECELERATION ENGINE
-- ==========================================
startGradualDeceleration = function()
  if decelerationRunnable then mainHandler.removeCallbacks(decelerationRunnable) end
  decelerationRunnable = luajava.createProxy("java.lang.Runnable", {
    run = function()
      if not isSwipeActive and isEngineStarted then
        if currentCalculatedSpeed > 0.05 then
          currentCalculatedSpeed = currentCalculatedSpeed - 0.02 
          updateDynamicHardwareAudio(currentCalculatedSpeed)
          mainHandler.postDelayed(decelerationRunnable, 60)
        else
          currentCalculatedSpeed = 0.0
          updateDynamicHardwareAudio(currentCalculatedSpeed)
        end
      end
    end
  })
  mainHandler.post(decelerationRunnable)
end

-- ==========================================
-- 4. CONTROLLED GAME LOOP & DISTANCE ENGINE
-- ==========================================
startGameLoop = function()
  if gameLoopRunnable then mainHandler.removeCallbacks(gameLoopRunnable) end
  gameLoopRunnable = luajava.createProxy("java.lang.Runnable", {
    run = function()
      if isEngineStarted then
        
        if currentCalculatedSpeed > 0.05 then
          playerDistance = playerDistance + (currentCalculatedSpeed * playerSpeedMultiplier)
          
          if playerTrack == -1 then
            playerDriftDistance = playerDriftDistance - 12
          elseif playerTrack == 1 then
            playerDriftDistance = playerDriftDistance + 12
          end
        end

        local robotRandomThrottle = math.random(85, 100) / 100.0
        robotDistance = robotDistance + (robotRandomThrottle * robotSpeedMultiplier)
        
        if math.random(1, 100) > 95 then
          robotTrack = math.random(-1, 1)
        end
        if robotTrack == -1 then
          robotDriftDistance = robotDriftDistance - 6
        elseif robotTrack == 1 then
          robotDriftDistance = robotDriftDistance + 6
        end

        local horizontalGap = math.abs(playerDriftDistance - robotDriftDistance)
        if horizontalGap >= 200 then
          if not isDeepOceanWarned then
            isDeepOceanWarned = true
            speakStatus("Warning! You have gone far from the race track. You are in the deep ocean!")
          end
        else
          isDeepOceanWarned = false
        end

        if math.floor(playerDistance) - lastPlayerAnnouncedDistance >= 100 then
          lastPlayerAnnouncedDistance = math.floor(playerDistance / 100) * 100
          
          local relativeAheadBehind = "ahead of you"
          if robotDistance < playerDistance then
            relativeAheadBehind = "behind you"
          elseif math.abs(robotDistance - playerDistance) <= 15 then
            relativeAheadBehind = "alongside you"
          end
          
          local relativeSide = "in your center"
          if robotDriftDistance < playerDriftDistance - 40 then
            relativeSide = "on your left"
          elseif robotDriftDistance > playerDriftDistance + 40 then
            relativeSide = "on your right"
          end
          
          speakStatus("You completed " .. lastPlayerAnnouncedDistance .. " meters. Robot is " .. relativeSide .. " and " .. relativeAheadBehind .. ".")
        end

        if math.floor(robotDistance) - lastRobotAnnouncedDistance >= 100 then
          lastRobotAnnouncedDistance = math.floor(robotDistance / 100) * 100
          speakStatus("Robot completed " .. lastRobotAnnouncedDistance .. " meters.")
        end

        if playerDistance >= RACE_LIMIT or robotDistance >= RACE_LIMIT then
          isEngineStarted = false
          stopAllAudio()
          
          if playerDistance >= RACE_LIMIT and playerDistance >= robotDistance then
            speakStatus("Victory! You reached 5 kilometers and won the race!")
            AlertDialog.Builder(this).setTitle("Race Over").setMessage("You Won!").setPositiveButton("OK", nil).show()
          else
            speakStatus("Defeat! Robot reached 5 kilometers first.")
            AlertDialog.Builder(this).setTitle("Race Over").setMessage("Robot Won!").setPositiveButton("OK", nil).show()
          end
          
          if engineToggleBtn then
            engineToggleBtn.setText("Start Engine 🛥️")
            engineToggleBtn.setBackgroundColor(Color.parseColor("#388E3C"))
          end
          return
        end

        updateDynamicHardwareAudio(currentCalculatedSpeed)
        mainHandler.postDelayed(gameLoopRunnable, 150)
      end
    end
  })
  mainHandler.post(gameLoopRunnable)
end

stopAllAudio = function()
  isEngineStarted = false
  isSwipeActive = false
  isCountingDown = false
  playerTrack = 0
  robotTrack = 0
  playerDriftDistance = 0
  robotDriftDistance = 0
  isDeepOceanWarned = false
  currentCalculatedSpeed = 0.0
  if gameLoopRunnable then mainHandler.removeCallbacks(gameLoopRunnable) end
  if decelerationRunnable then mainHandler.removeCallbacks(decelerationRunnable) end
  pcall(function()
    if racingPlayer then pcall(function() racingPlayer.stop() racingPlayer.release() end) racingPlayer = nil end
    if robotPlayer then pcall(function() robotPlayer.stop() robotPlayer.release() end) robotPlayer = nil end
    if bgPlayer then pcall(function() bgPlayer.stop() bgPlayer.release() end) bgPlayer = nil end
  end)
  playerDistance = 0.0
  robotDistance = 0.0
  lastPlayerAnnouncedDistance = 0
  lastRobotAnnouncedDistance = 0
end

-- ==========================================
-- 5. TWO-FINGER SPEED & ONE-FINGER STEER ENGINE
-- ==========================================
local processControlsEngine = function(event, viewHeight)
  local pointerCount = event.getPointerCount()
  local action = event.getActionMasked()

  if not isEngineStarted or isCountingDown then return end

  if action == MotionEvent.ACTION_DOWN or action == MotionEvent.ACTION_POINTER_DOWN then 
    isSwipeActive = true
    if decelerationRunnable then mainHandler.removeCallbacks(decelerationRunnable) end
    if pointerCount == 1 then
      xStart = event.getX(0)
      yStart = event.getY(0)
    end
  
  elseif action == MotionEvent.ACTION_MOVE then 
    
    if pointerCount == 2 then
      -- 2-Finger Swipe Up/Down (Speed Control)
      local yCurrent = (event.getY(0) + event.getY(1)) / 2
      local ratio = math.min(1.0, math.max(0.0, (viewHeight - yCurrent) / viewHeight))
      currentCalculatedSpeed = ratio
      updateDynamicHardwareAudio(currentCalculatedSpeed)

    elseif pointerCount == 1 then
      -- 1-Finger Swipe Left/Right (Steering Control)
      local xCurrent = event.getX(0)
      local yCurrent = event.getY(0)
      local xDiff = xCurrent - xStart
      local yDiff = yCurrent - yStart
      
      if math.abs(xDiff) > MIN_SWIPE_DISTANCE and math.abs(xDiff) > math.abs(yDiff) then
        if xDiff > 0 then 
          if playerTrack < 1 then
            playerTrack = playerTrack + 1
            local posStr = "Center"
            if playerTrack == 1 then posStr = "Right" end
            speakStatus("You are going to " .. posStr)
          end
        else 
          if playerTrack > -1 then
            playerTrack = playerTrack - 1
            local posStr = "Center"
            if playerTrack == -1 then posStr = "Left" end
            speakStatus("You are going to " .. posStr)
          end
        end
        xStart = xCurrent 
        yStart = yCurrent
        
      elseif math.abs(yDiff) > MIN_SWIPE_DISTANCE and math.abs(yDiff) > math.abs(xDiff) then
        if yDiff < 0 and playerTrack ~= 0 then
          playerTrack = 0
          robotDriftDistance = robotDriftDistance - playerDriftDistance 
          playerDriftDistance = 0 
          speakStatus("You are going to Center")
          xStart = xCurrent
          yStart = yCurrent
        end
      end
    end
    
  elseif action == MotionEvent.ACTION_UP or action == MotionEvent.ACTION_CANCEL then 
    isSwipeActive = false
    startGradualDeceleration()
  end
end

-- ==========================================
-- 6. ACCESSIBLE COUNTDOWN MOTOR
-- ==========================================
startCountdownSystem = function()
  isCountingDown = true
  engineToggleBtn.setText("Preparing... ⏳")
  engineToggleBtn.setBackgroundColor(Color.parseColor("#757575"))
  
  speakStatus("3")
  
  mainHandler.postDelayed(luajava.createProxy("java.lang.Runnable", {
    run = function()
      if not isCountingDown then return end
      speakStatus("2")
      
      mainHandler.postDelayed(luajava.createProxy("java.lang.Runnable", {
        run = function()
          if not isCountingDown then return end
          speakStatus("1")
          
          mainHandler.postDelayed(luajava.createProxy("java.lang.Runnable", {
            run = function()
              if not isCountingDown then return end
              isCountingDown = false
              isEngineStarted = true
              
              playerTrack = 0 
              robotTrack = 0  
              playerDistance = 0.0
              robotDistance = 0.0
              playerDriftDistance = 0
              robotDriftDistance = 0
              lastPlayerAnnouncedDistance = 0
              lastRobotAnnouncedDistance = 0
              isDeepOceanWarned = false
              currentCalculatedSpeed = 0.0 
              
              engineToggleBtn.setText("Stop Engine 🛑")
              engineToggleBtn.setBackgroundColor(Color.parseColor("#D32F2F"))
              
              speakStatus("Game Started. Two fingers to speed up, one finger to steer.")
              updateDynamicHardwareAudio(0.0) 
              startGameLoop()
            end
          }), 1200)
        end
      }), 1200)
    end
  }), 1200)
end

local toggleEngineState = function()
  if isCountingDown then
    stopAllAudio()
    engineToggleBtn.setText("Start Engine 🛥️")
    engineToggleBtn.setBackgroundColor(Color.parseColor("#388E3C"))
    speakStatus("Cancelled.")
    return
  end

  if not isEngineStarted then
    startCountdownSystem()
  else
    stopAllAudio()
    engineToggleBtn.setText("Start Engine 🛥️")
    engineToggleBtn.setBackgroundColor(Color.parseColor("#388E3C"))
    speakStatus("Engine Stopped.")
  end
end

-- ==========================================
-- 7. VISUAL INTERFACE BUILDERS
-- ==========================================
local menuLayout = {
  LinearLayout, orientation = "vertical", layout_width = "fill", layout_height = "fill", gravity = "center", backgroundColor = "#121212", padding = "24dp",
  { TextView, text = "Ocean Racing 5KM", textSize = "26sp", textColor = Color.WHITE, layout_marginBottom = "8dp" },
  { TextView, text = "Advanced Gesture Accessibility Mode", textSize = "13sp", textColor = Color.GREEN, layout_marginBottom = "40dp" },
  { Button, id = "playBtn", text = "Start Racing", layout_width = "fill", layout_marginBottom = "12dp" },
  { Button, id = "exitBtn", text = "Exit", layout_width = "fill" }
}

function openMainMenuWindow()
  dlgMenu = LuaDialog(this)
  dlgMenu.View = loadlayout(menuLayout)
  dlgMenu.setCancelable(false)
  dlgMenu.show()

  playBtn.onClick = function() openMapSelectionWindow() end
  exitBtn.onClick = function()
    stopAllAudio()
    if ttsEngine then ttsEngine.shutdown() end
    dlgMenu.dismiss()
    this.finish()
  end
end

local mapSelectionLayout = {
  LinearLayout, orientation = "vertical", layout_width = "fill", layout_height = "fill", gravity = "center", backgroundColor = "#1A1A1A", padding = "24dp",
  { TextView, text = "Select Ocean Map", textSize = "24sp", textColor = Color.WHITE, layout_marginBottom = "40dp" },
  { Button, id = "arcticOceanBtn", text = "Arctic Ocean (5000M) ❄️", layout_width = "fill", layout_marginBottom = "16dp", backgroundColor = "#0288D1", textColor = Color.WHITE },
  { Button, id = "southernOceanBtn", text = "Southern Ocean (5000M) 🌊", layout_width = "fill", layout_marginBottom = "30dp", backgroundColor = "#00796B", textColor = Color.WHITE },
  { Button, id = "backToMenuBtn", text = "Back", layout_width = "fill" }
}

openMapSelectionWindow = function()
  if dlgMenu then dlgMenu.dismiss() end
  dlgMapSelect = LuaDialog(this)
  dlgMapSelect.View = loadlayout(mapSelectionLayout)
  dlgMapSelect.setCancelable(false)
  dlgMapSelect.show()

  local mapSelected = function(mapName, mapPath, vol)
    selectedMapName = mapName
    currentActiveVolume = vol
    openBoatSelectionWindow(mapPath)
  end

  arcticOceanBtn.onClick = function() mapSelected("Arctic Ocean", arcticOceanPath, 0.5) end
  southernOceanBtn.onClick = function() mapSelected("Southern Ocean", southernOceanPath, 0.15) end
  backToMenuBtn.onClick = function() 
    dlgMapSelect.dismiss()
    openMainMenuWindow() 
  end
end

local boatSelectionLayout = {
  LinearLayout, orientation = "vertical", layout_width = "fill", layout_height = "fill", gravity = "center", backgroundColor = "#1A1A1A", padding = "24dp",
  { TextView, text = "Select Your Boat", textSize = "24sp", textColor = Color.WHITE, layout_marginBottom = "40dp" },
  { Button, id = "oldBoatBtn", text = "Old Motor Boat (100M in 20s)", layout_width = "fill", layout_marginBottom = "16dp", backgroundColor = "#FF8F00", textColor = Color.WHITE },
  { Button, id = "advanceBoatBtn", text = "Advance Motor Boat (100M in 15s)", layout_width = "fill", layout_marginBottom = "30dp", backgroundColor = "#D84315", textColor = Color.WHITE },
  { Button, id = "backToMapBtn", text = "Back", layout_width = "fill" }
}

openBoatSelectionWindow = function(bgMapPath)
  if dlgMapSelect then dlgMapSelect.dismiss() end
  dlgBoatSelect = LuaDialog(this)
  dlgBoatSelect.View = loadlayout(boatSelectionLayout)
  dlgBoatSelect.setCancelable(false)
  dlgBoatSelect.show()

  local finalizeBoatSelection = function()
    if math.random(1, 2) == 1 then
      robotAudioPath = oldBoatPath
      robotSpeedMultiplier = OLD_BOAT_SPEED
    else
      robotAudioPath = advanceBoatPath
      robotSpeedMultiplier = ADVANCE_BOAT_SPEED
    end
    openGamePlayWindow(bgMapPath)
  end

  oldBoatBtn.onClick = function()
    playerAudioPath = oldBoatPath
    playerSpeedMultiplier = OLD_BOAT_SPEED
    playerBoatName = "Old Motor Boat"
    finalizeBoatSelection()
  end

  advanceBoatBtn.onClick = function()
    playerAudioPath = advanceBoatPath
    playerSpeedMultiplier = ADVANCE_BOAT_SPEED
    playerBoatName = "Advance Motor Boat"
    finalizeBoatSelection()
  end

  backToMapBtn.onClick = function()
    dlgBoatSelect.dismiss()
    openMapSelectionWindow()
  end
end

local gameLayout = {
  RelativeLayout, layout_width = "fill", layout_height = "fill", backgroundColor = "#1A1A1A",
  { LinearLayout, orientation = "vertical", layout_width = "fill", layout_height = "fill", gravity = "center", padding = "24dp",
    { TextView, id = "mapTitleTxt", text = "Race Arena", textSize = "24sp", textColor = Color.CYAN, layout_marginBottom = "5dp" },
    { TextView, id = "boatTitleTxt", text = "Boat", textSize = "16sp", textColor = Color.WHITE, layout_marginBottom = "15dp" },
    { TextView, text = "2-Fingers Swipe Up/Down to speed. 1-Finger Left/Right to Steer.", textSize = "13sp", textColor = Color.YELLOW, gravity = "center", layout_marginBottom = "30dp" },
    { Button, id = "engineToggleBtn", text = "Start Engine 🛥️", backgroundColor = "#388E3C", textColor = Color.WHITE, textSize = "20sp", layout_width = "fill", layout_marginBottom = "20dp" },
    { Button, id = "backMapBtn", text = "Quit Race", layout_width = "fill" }
  }
}

openGamePlayWindow = function(bgPath)
  if dlgBoatSelect then dlgBoatSelect.dismiss() end
  dlgGame = LuaDialog(this)
  dlgGame.View = loadlayout(gameLayout)
  dlgGame.setCancelable(false)
  dlgGame.show()

  mapTitleTxt.setText(selectedMapName)
  boatTitleTxt.setText("Your Boat: " .. playerBoatName)
  startOceanBg(bgPath)
  
  engineToggleBtn.onClick = function() toggleEngineState() end

  local decorView = dlgGame.Window.getDecorView()
  local touchListener = luajava.createProxy("android.view.View$OnTouchListener", {
    onTouch = function(v, event)
      processControlsEngine(event, decorView.getHeight())
      return true
    end
  })
  decorView.setOnTouchListener(touchListener)

  backMapBtn.onClick = function() 
    stopAllAudio()
    dlgGame.dismiss()
    openMainMenuWindow() 
  end
end

-- Initialize Program
openMainMenuWindow()