
if service.click({
{"Pause|Resume@*",
}
})
return true
end
