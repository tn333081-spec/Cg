require "import"
import "android.content.Intent"
import "android.content.IntentFilter"
import "android.os.BatteryManager"

intentFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
batteryStatus = service.registerReceiver(nil, intentFilter)

level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
temp = batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10

-- Pehle battery level set karte hain
s = "Battery " .. tostring(level) .. " percent, "

-- Agar temperature 41 ya usse upar hai, toh pehle high temperature bolega
if temp >= 41 then
    s = s .. "High"
end

-- Uske baad temperature ki details announce hogi
s = s .. "Temperature " .. tostring(temp) .. " degrees"

service.speak(s)

return true