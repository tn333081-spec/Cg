require "import"
import "android.os.Handler"
import "java.lang.Runnable"

local handler=Handler()
recording=recording or false
startTime=startTime or 0
tickRunnable=tickRunnable

tickRunnable=Runnable({
run=function()
  if recording then
    if os.time()-startTime<360 then
      service.playSoundTick()
      handler.postDelayed(tickRunnable,2000)
    else
      recording=false
    end
  end
end
})

-- اگر ریکارڈنگ چل رہی ہے اور extension دوبارہ apply ہو
if recording then
  recording=false
  service.click({
  {"Send$001"},
  })
  return true
end

-- پہلی بار apply کرنے پر voice message start
if service.click({
{"<Voice message, Button*$50",
"%Direct swipe up$700",
}
}) then
  recording=true
  startTime=os.time()
  service.playSoundTick()
  handler.postDelayed(tickRunnable,2000)
  return true
end
