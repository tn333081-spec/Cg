require "import"
import "android.view.WindowManager"
import "android.view.View"
import "android.view.KeyEvent"
import "android.graphics.Color"
import "android.widget.LinearLayout"
import "android.widget.ScrollView"
import "android.widget.TextView"
import "android.widget.Button"
import "android.widget.EditText"
import "android.os.Handler"
import "android.os.Looper"
import "java.net.URL"
import "java.net.HttpURLConnection"
import "java.io.BufferedReader"
import "java.io.InputStreamReader"
import "java.io.OutputStream"
import "java.lang.Thread"
import "java.lang.Runnable"
import "java.lang.String"
import "java.lang.StringBuilder"
import "android.util.Base64"
import "org.json.JSONArray"
import "org.json.JSONObject"
import "android.text.TextWatcher"
import "android.content.Intent"
import "android.net.Uri"

local tokenPath = service.getFilesDir().getAbsolutePath() .. "/gh_token.txt"

local function loadToken()
  local f = io.open(tokenPath, "r")
  if f then
    local t = f:read("*a")
    f:close()
    if t then
      local cleanT = (t:gsub("%s+", ""))
      return tostring(cleanT)
    end
  end
  return ""
end

local function saveToken(newToken)
  local f = io.open(tokenPath, "w")
  if f then
    f:write(tostring(newToken))
    f:close()
    return true
  end
  return false
end

local function deleteToken()
  pcall(function() os.remove(tokenPath) end)
end

local function enableBackKey(rootView, backCallback)
  rootView.setFocusable(true)
  rootView.setFocusableInTouchMode(true)
  rootView.requestFocus()
  rootView.setOnKeyListener(View.OnKeyListener({
    onKey = function(v, keyCode, event)
      if keyCode == KeyEvent.KEYCODE_BACK and event.getAction() == KeyEvent.ACTION_UP then
        if backCallback then
          backCallback()
        end
        return true
      end
      return false
    end
  }))
end

local mainHandler = Handler(Looper.getMainLooper())
local wm = service.getSystemService(service.WINDOW_SERVICE)
local layoutParams = WindowManager.LayoutParams()
layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT
layoutParams.height = WindowManager.LayoutParams.MATCH_PARENT
layoutParams.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
layoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
layoutParams.format = 1

local currentView = nil

local function setScreen(view)
  if currentView ~= nil then
    pcall(function() wm.removeViewImmediate(currentView) end)
    pcall(function() wm.removeView(currentView) end)
  end
  currentView = view
  if currentView ~= nil then
    pcall(function() wm.addView(currentView, layoutParams) end)
    pcall(function() currentView.requestFocus() end)
  end
end

local function closeExtension()
  setScreen(nil)
  pcall(function() service.finish() end)
  pcall(function() service.finishAndRemoveTask() end)
end

local function httpRequestWithToken(urlStr, method, jsonBody, customToken, callback)
  Thread(Runnable({
    run = function()
      local result = ""
      local code = 0
      local status, err = pcall(function()
        local url = URL(urlStr)
        local conn = url.openConnection()
        conn.setRequestMethod(method)
        conn.setRequestProperty("Authorization", "Bearer " .. customToken)
        conn.setRequestProperty("User-Agent", "GitHub-Manager-App")
        conn.setRequestProperty("Accept", "application/vnd.github.v3+json")
        if jsonBody and (method == "POST" or method == "PUT" or method == "PATCH" or method == "DELETE") then
          conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
          conn.setDoOutput(true)
          local os = conn.getOutputStream()
          os.write(String(jsonBody).getBytes("UTF-8"))
          os.flush()
          os.close()
        end
        code = conn.getResponseCode()
        local is
        if code >= 200 and code < 300 then
          is = conn.getInputStream()
        else
          is = conn.getErrorStream()
        end
        if is then
          local br = BufferedReader(InputStreamReader(is, "UTF-8"))
          local sb = StringBuilder()
          local line = br.readLine()
          while line ~= nil do
            sb.append(line)
            line = br.readLine()
          end
          br.close()
          result = sb.toString()
        else
          result = ""
        end
      end)
      if not status then
        result = "Error: " .. tostring(err)
      end
      mainHandler.post(Runnable({
        run = function()
          callback(code, result)
        end
      }))
    end
  })).start()
end

local function httpRequest(urlStr, method, jsonBody, callback)
  local token = loadToken()
  if token == "" then
    mainHandler.post(Runnable({
      run = function()
        callback(401, "Token missing")
      end
    }))
    return
  end
  httpRequestWithToken(urlStr, method, jsonBody, token, callback)
end

local showMainScreen
local showRepoMenu
local showFilesList
local showMyRepos
local showTokenEditScreen
local showAboutScreen

local function createHeader(titleText)
  local title = TextView(service)
  title.setText(tostring(titleText))
  title.setTextSize(20)
  title.setTextColor(Color.WHITE)
  title.setPadding(30, 40, 30, 20)
  return title
end

local function showLoading(msg)
  local root = LinearLayout(service)
  root.setOrientation(LinearLayout.VERTICAL)
  root.setBackgroundColor(Color.BLACK)
  root.setPadding(20, 20, 20, 20)
  
  local scroll = ScrollView(service)
  local layout = LinearLayout(service)
  layout.setOrientation(LinearLayout.VERTICAL)
  layout.addView(createHeader(msg))
  
  scroll.addView(layout)
  root.addView(scroll)
  setScreen(root)
end

local function showTokenMissingScreen()
  local root = LinearLayout(service)
  root.setOrientation(LinearLayout.VERTICAL)
  root.setBackgroundColor(Color.BLACK)
  root.setPadding(20, 20, 20, 20)

  local scroll = ScrollView(service)
  local layout = LinearLayout(service)
  layout.setOrientation(LinearLayout.VERTICAL)

  layout.addView(createHeader("Token Required"))

  local info = TextView(service)
  info.setText("Please set your GitHub Personal Access Token first!")
  info.setTextColor(Color.YELLOW)
  info.setTextSize(16)
  info.setPadding(20, 20, 20, 20)
  layout.addView(info)

  local btnBack = Button(service)
  btnBack.setText("Back to Main Menu")
  btnBack.setOnClickListener(View.OnClickListener({
    onClick = function() showMainScreen() end
  }))
  layout.addView(btnBack)

  scroll.addView(layout)
  root.addView(scroll)
  enableBackKey(root, function() showMainScreen() end)
  setScreen(root)
end

showAboutScreen = function()
  local root = LinearLayout(service)
  root.setOrientation(LinearLayout.VERTICAL)
  root.setBackgroundColor(Color.BLACK)
  root.setPadding(20, 20, 20, 20)

  local scroll = ScrollView(service)
  local layout = LinearLayout(service)
  layout.setOrientation(LinearLayout.VERTICAL)

  layout.addView(createHeader("About & User Guide"))

  local infoCreator = TextView(service)
  infoCreator.setText("Created with brilliance and mastery by Moosa Zaib!\nThis powerful extension brings complete GitHub repository and file management right onto your device with absolute speed and convenience.")
  infoCreator.setTextColor(Color.CYAN)
  infoCreator.setTextSize(16)
  infoCreator.setPadding(20, 10, 20, 20)
  layout.addView(infoCreator)

  local btnContact = Button(service)
  btnContact.setText("Contact Moosa Zaib")
  btnContact.setOnClickListener(View.OnClickListener({
    onClick = function()
      pcall(function()
        local intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/923123608972"))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        service.startActivity(intent)
      end)
      closeExtension()
    end
  }))
  layout.addView(btnContact)

  local guideHeader = TextView(service)
  guideHeader.setText("Step-by-Step Complete Guide:")
  guideHeader.setTextColor(Color.YELLOW)
  guideHeader.setTextSize(18)
  guideHeader.setPadding(20, 30, 20, 10)
  layout.addView(guideHeader)

  local step1 = TextView(service)
  step1.setText("Step 1: Setting Up Your Personal Access Token\nTo use this extension, you must connect it to your GitHub account using a Personal Access Token (PAT). Open 'Set / Edit Personal Access Token' from the main menu. Paste your token (starting with ghp_...) into the text box. Tap 'Save Token'. The app will instantly verify your token with GitHub, display your username and account name upon success, and securely save it for future use.")
  step1.setTextColor(Color.WHITE)
  step1.setTextSize(15)
  step1.setPadding(20, 10, 20, 15)
  layout.addView(step1)

  local step2 = TextView(service)
  step2.setText("Step 2: Viewing All Your Repositories\nOnce your token is saved and verified, go back to the main menu and tap 'My Repositories'. The extension will fetch a complete list of all your public and private repositories directly from your GitHub account.")
  step2.setTextColor(Color.WHITE)
  step2.setTextSize(15)
  step2.setPadding(20, 10, 20, 15)
  layout.addView(step2)

  local step3 = TextView(service)
  step3.setText("Step 3: Creating a New Repository (Public or Private)\nTap 'Create New Repository' from the main menu. Enter your desired repository name and tap 'Create'. You will be asked whether you want to create a Public or Private repository. Select your preference to create it instantly.")
  step3.setTextColor(Color.WHITE)
  step3.setTextSize(15)
  step3.setPadding(20, 10, 20, 15)
  layout.addView(step3)

  local step4 = TextView(service)
  step4.setText("Step 4: Browsing, Editing, and Managing Repository Files\nTap on any repository from your list. Here you can:\n- Browse & Edit Files: Open folders or view/edit files.\n- Upload New File: Type a file name and content to upload.\n- Change Visibility: View your repository's visibility status and switch between Public and Private whenever needed.")
  step4.setTextColor(Color.WHITE)
  step4.setTextSize(15)
  step4.setPadding(20, 10, 20, 15)
  layout.addView(step4)

  local step5 = TextView(service)
  step5.setText("Step 5: Renaming or Deleting a Repository\nInside the repository menu, tap 'Rename Repository' to change its name, or tap 'Delete Repository' if you wish to permanently remove it.")
  step5.setTextColor(Color.WHITE)
  step5.setTextSize(15)
  step5.setPadding(20, 10, 20, 15)
  layout.addView(step5)

  local step6 = TextView(service)
  step6.setText("Step 6: Easy Navigation & Closing Extension\nYou can press your phone's Back Button at any moment to safely return to the previous menu. To exit, tap 'Close Extension' on the main menu.")
  step6.setTextColor(Color.WHITE)
  step6.setTextSize(15)
  step6.setPadding(20, 10, 20, 20)
  layout.addView(step6)

  local btnBack = Button(service)
  btnBack.setText("Back to Main Menu")
  btnBack.setOnClickListener(View.OnClickListener({
    onClick = function() showMainScreen() end
  }))
  layout.addView(btnBack)

  scroll.addView(layout)
  root.addView(scroll)
  enableBackKey(root, function() showMainScreen() end)
  setScreen(root)
end

showTokenEditScreen = function()
  local root = LinearLayout(service)
  root.setOrientation(LinearLayout.VERTICAL)
  root.setBackgroundColor(Color.BLACK)
  root.setPadding(20, 20, 20, 20)

  local scroll = ScrollView(service)
  local layout = LinearLayout(service)
  layout.setOrientation(LinearLayout.VERTICAL)

  layout.addView(createHeader("Set / Edit Personal Access Token"))

  local currentToken = loadToken()

  local inputToken = EditText(service)
  inputToken.setHint("Paste your token here (ghp_...)")
  inputToken.setText(tostring(currentToken))
  inputToken.setTextColor(Color.WHITE)
  inputToken.setHintTextColor(Color.GRAY)
  layout.addView(inputToken)

  local btnSave = Button(service)
  btnSave.setText("Save Token")
  
  local function updateSaveState()
    local val = tostring(inputToken.getText())
    local clean = (val:gsub("%s+", ""))
    btnSave.setEnabled(clean ~= "")
  end
  updateSaveState()

  inputToken.addTextChangedListener(TextWatcher({
    onTextChanged = function() updateSaveState() end,
    beforeTextChanged = function() end,
    afterTextChanged = function() end
  }))

  btnSave.setOnClickListener(View.OnClickListener({
    onClick = function()
      local rawVal = tostring(inputToken.getText())
      local cleanVal = (rawVal:gsub("%s+", ""))
      if cleanVal == "" then
        local errRoot = LinearLayout(service)
        errRoot.setOrientation(LinearLayout.VERTICAL)
        errRoot.setBackgroundColor(Color.BLACK)
        errRoot.setPadding(20, 20, 20, 20)

        local errScroll = ScrollView(service)
        local errLayout = LinearLayout(service)
        errLayout.setOrientation(LinearLayout.VERTICAL)

        errLayout.addView(createHeader("Invalid Token"))
        local errInfo = TextView(service)
        errInfo.setText("Token cannot be empty. Please enter a valid token.")
        errInfo.setTextColor(Color.YELLOW)
        errInfo.setTextSize(16)
        errInfo.setPadding(20, 20, 20, 20)
        errLayout.addView(errInfo)

        local btnErrBack = Button(service)
        btnErrBack.setText("Try Again")
        btnErrBack.setOnClickListener(View.OnClickListener({
          onClick = function() showTokenEditScreen() end
        }))
        errLayout.addView(btnErrBack)

        errScroll.addView(errLayout)
        errRoot.addView(errScroll)
        enableBackKey(errRoot, function() showTokenEditScreen() end)
        setScreen(errRoot)
        return
      end

      showLoading("Verifying Token...")
      httpRequestWithToken("https://api.github.com/user", "GET", nil, cleanVal, function(vCode, vRes)
        if vCode == 200 then
          if saveToken(cleanVal) then
            local uName = ""
            local uLogin = ""
            pcall(function()
              local obj = JSONObject(vRes)
              uLogin = obj.getString("login")
              if obj.has("name") and not obj.isNull("name") then
                uName = obj.getString("name")
              end
            end)

            local succRoot = LinearLayout(service)
            succRoot.setOrientation(LinearLayout.VERTICAL)
            succRoot.setBackgroundColor(Color.BLACK)
            succRoot.setPadding(20, 20, 20, 20)

            local succScroll = ScrollView(service)
            local succLayout = LinearLayout(service)
            succLayout.setOrientation(LinearLayout.VERTICAL)

            succLayout.addView(createHeader("Token Verified Successfully!"))

            local txtStatus = TextView(service)
            txtStatus.setText("Logged in successfully!")
            txtStatus.setTextColor(Color.GREEN)
            txtStatus.setTextSize(18)
            txtStatus.setPadding(20, 10, 20, 10)
            succLayout.addView(txtStatus)

            local txtUser = TextView(service)
            txtUser.setText("Username: " .. uLogin)
            txtUser.setTextColor(Color.WHITE)
            txtUser.setTextSize(16)
            txtUser.setPadding(20, 10, 20, 10)
            succLayout.addView(txtUser)

            if uName ~= "" and uName ~= "null" then
              local txtName = TextView(service)
              txtName.setText("Name: " .. uName)
              txtName.setTextColor(Color.WHITE)
              txtName.setTextSize(16)
              txtName.setPadding(20, 10, 20, 10)
              succLayout.addView(txtName)
            end

            local btnContinue = Button(service)
            btnContinue.setText("Continue to Main Menu")
            btnContinue.setOnClickListener(View.OnClickListener({
              onClick = function() showMainScreen() end
            }))
            succLayout.addView(btnContinue)

            succScroll.addView(succLayout)
            succRoot.addView(succScroll)
            enableBackKey(succRoot, function() showMainScreen() end)
            setScreen(succRoot)
          end
        else
          local errRoot = LinearLayout(service)
          errRoot.setOrientation(LinearLayout.VERTICAL)
          errRoot.setBackgroundColor(Color.BLACK)
          errRoot.setPadding(20, 20, 20, 20)

          local errScroll = ScrollView(service)
          local errLayout = LinearLayout(service)
          errLayout.setOrientation(LinearLayout.VERTICAL)

          errLayout.addView(createHeader("Invalid Token"))
          local errInfo = TextView(service)
          errInfo.setText("Token verification failed (Error " .. vCode .. "). Please check your token and try again.")
          errInfo.setTextColor(Color.YELLOW)
          errInfo.setTextSize(16)
          errInfo.setPadding(20, 20, 20, 20)
          errLayout.addView(errInfo)

          local btnErrBack = Button(service)
          btnErrBack.setText("Try Again")
          btnErrBack.setOnClickListener(View.OnClickListener({
            onClick = function() showTokenEditScreen() end
          }))
          errLayout.addView(btnErrBack)

          errScroll.addView(errLayout)
          errRoot.addView(errScroll)
          enableBackKey(errRoot, function() showTokenEditScreen() end)
          setScreen(errRoot)
        end
      end)
    end
  }))
  layout.addView(btnSave)

  if currentToken ~= "" then
    local btnDeleteToken = Button(service)
    btnDeleteToken.setText("Delete Token")
    btnDeleteToken.setOnClickListener(View.OnClickListener({
      onClick = function()
        local dConfRoot = LinearLayout(service)
        dConfRoot.setOrientation(LinearLayout.VERTICAL)
        dConfRoot.setBackgroundColor(Color.BLACK)
        dConfRoot.setPadding(20, 20, 20, 20)

        local dConfScroll = ScrollView(service)
        local dConfLayout = LinearLayout(service)
        dConfLayout.setOrientation(LinearLayout.VERTICAL)

        dConfLayout.addView(createHeader("Confirm Token Deletion"))

        local dConfInfo = TextView(service)
        dConfInfo.setText("Are you sure you want to delete your saved Personal Access Token?")
        dConfInfo.setTextColor(Color.YELLOW)
        dConfInfo.setTextSize(16)
        dConfInfo.setPadding(20, 20, 20, 20)
        dConfLayout.addView(dConfInfo)

        local btnConfirmTokDel = Button(service)
        btnConfirmTokDel.setText("Yes, Delete Token")
        btnConfirmTokDel.setOnClickListener(View.OnClickListener({
          onClick = function()
            deleteToken()
            showMainScreen()
          end
        }))
        dConfLayout.addView(btnConfirmTokDel)

        local btnCancelTokDel = Button(service)
        btnCancelTokDel.setText("Cancel")
        btnCancelTokDel.setOnClickListener(View.OnClickListener({
          onClick = function()
            showTokenEditScreen()
          end
        }))
        dConfLayout.addView(btnCancelTokDel)

        dConfScroll.addView(dConfLayout)
        dConfRoot.addView(dConfScroll)
        enableBackKey(dConfRoot, function() showTokenEditScreen() end)
        setScreen(dConfRoot)
      end
    }))
    layout.addView(btnDeleteToken)
  end

  local btnBack = Button(service)
  btnBack.setText("Cancel")
  btnBack.setOnClickListener(View.OnClickListener({
    onClick = function() showMainScreen() end
  }))
  layout.addView(btnBack)

  scroll.addView(layout)
  root.addView(scroll)
  enableBackKey(root, function() showMainScreen() end)
  setScreen(root)
end

showFilesList = function(owner, repo, path)
  if loadToken() == "" then
    showTokenMissingScreen()
    return
  end

  showLoading("Loading files...")
  local url = "https://api.github.com/repos/" .. owner .. "/" .. repo .. "/contents/" .. path
  httpRequest(url, "GET", nil, function(code, res)
    if code == 404 then
      local root = LinearLayout(service)
      root.setOrientation(LinearLayout.VERTICAL)
      root.setBackgroundColor(Color.BLACK)
      root.setPadding(20, 20, 20, 20)

      local scroll = ScrollView(service)
      local layout = LinearLayout(service)
      layout.setOrientation(LinearLayout.VERTICAL)

      layout.addView(createHeader("No Files Found"))
      local info = TextView(service)
      info.setText("This repository is empty or has no files in this folder.")
      info.setTextColor(Color.YELLOW)
      info.setTextSize(16)
      info.setPadding(20, 20, 20, 20)
      layout.addView(info)

      local btnBack = Button(service)
      btnBack.setText("Back to Repo Menu")
      btnBack.setOnClickListener(View.OnClickListener({
        onClick = function() showRepoMenu(owner, repo) end
      }))
      layout.addView(btnBack)

      scroll.addView(layout)
      root.addView(scroll)
      enableBackKey(root, function() showRepoMenu(owner, repo) end)
      setScreen(root)
      return
    elseif code ~= 200 then
      local root = LinearLayout(service)
      root.setOrientation(LinearLayout.VERTICAL)
      root.setBackgroundColor(Color.BLACK)
      root.setPadding(20, 20, 20, 20)

      local scroll = ScrollView(service)
      local layout = LinearLayout(service)
      layout.setOrientation(LinearLayout.VERTICAL)

      layout.addView(createHeader("Error " .. code))
      local btnBack = Button(service)
      btnBack.setText("Back")
      btnBack.setOnClickListener(View.OnClickListener({
        onClick = function() showRepoMenu(owner, repo) end
      }))
      layout.addView(btnBack)

      scroll.addView(layout)
      root.addView(scroll)
      enableBackKey(root, function() showRepoMenu(owner, repo) end)
      setScreen(root)
      return
    end

    local root = LinearLayout(service)
    root.setOrientation(LinearLayout.VERTICAL)
    root.setBackgroundColor(Color.BLACK)
    root.setPadding(20, 20, 20, 20)

    local scroll = ScrollView(service)
    local layout = LinearLayout(service)
    layout.setOrientation(LinearLayout.VERTICAL)

    layout.addView(createHeader("Files in " .. repo))

    local hasItems = false
    pcall(function()
      local arr = JSONArray(res)
      if arr.length() > 0 then
        hasItems = true
      end
      for i = 0, arr.length() - 1 do
        local item = arr.getJSONObject(i)
        local itemName = item.getString("name")
        local itemType = item.getString("type")
        local itemPath = item.getString("path")
        local btn = Button(service)
        if itemType == "dir" then
          btn.setText("[Folder] " .. itemName)
        else
          btn.setText("[File] " .. itemName)
        end
        btn.setOnClickListener(View.OnClickListener({
          onClick = function()
            if itemType == "dir" then
              showFilesList(owner, repo, itemPath)
            else
              showLoading("Opening file...")
              httpRequest("https://api.github.com/repos/" .. owner .. "/" .. repo .. "/contents/" .. itemPath, "GET", nil, function(fCode, fRes)
                if fCode == 200 then
                  local fObj = JSONObject(fRes)
                  local rawContent = fObj.getString("content")
                  local sha = fObj.getString("sha")
                  local cleanB64 = (rawContent:gsub("%s+", ""))
                  local decodedBytes = Base64.decode(cleanB64, Base64.DEFAULT)
                  local decodedStr = String(decodedBytes, "UTF-8")

                  local editRoot = LinearLayout(service)
                  editRoot.setOrientation(LinearLayout.VERTICAL)
                  editRoot.setBackgroundColor(Color.BLACK)
                  editRoot.setPadding(20, 20, 20, 20)

                  local editScroll = ScrollView(service)
                  local editLayout = LinearLayout(service)
                  editLayout.setOrientation(LinearLayout.VERTICAL)

                  editLayout.addView(createHeader("File: " .. itemName))

                  local lblName = TextView(service)
                  lblName.setText("File Name:")
                  lblName.setTextColor(Color.WHITE)
                  lblName.setTextSize(16)
                  lblName.setPadding(10, 10, 10, 5)
                  editLayout.addView(lblName)

                  local nameBox = EditText(service)
                  nameBox.setText(tostring(itemName))
                  nameBox.setTextColor(Color.WHITE)
                  nameBox.setHintTextColor(Color.GRAY)
                  editLayout.addView(nameBox)

                  local lblContent = TextView(service)
                  lblContent.setText("File Content:")
                  lblContent.setTextColor(Color.WHITE)
                  lblContent.setTextSize(16)
                  lblContent.setPadding(10, 20, 10, 5)
                  editLayout.addView(lblContent)

                  local editBox = EditText(service)
                  editBox.setText(tostring(decodedStr))
                  editBox.setTextColor(Color.WHITE)
                  editBox.setHintTextColor(Color.GRAY)
                  editLayout.addView(editBox)

                  local btnSave = Button(service)
                  btnSave.setText("Save Changes")
                  
                  local function updateFileEditState()
                    local nVal = tostring(nameBox.getText())
                    local cVal = tostring(editBox.getText())
                    btnSave.setEnabled(nVal ~= "" and cVal ~= "")
                  end
                  updateFileEditState()

                  local textWatcherObj = TextWatcher({
                    onTextChanged = function() updateFileEditState() end,
                    beforeTextChanged = function() end,
                    afterTextChanged = function() end
                  })
                  nameBox.addTextChangedListener(textWatcherObj)
                  editBox.addTextChangedListener(textWatcherObj)

                  btnSave.setOnClickListener(View.OnClickListener({
                    onClick = function()
                      local newName = tostring(nameBox.getText())
                      local newText = tostring(editBox.getText())
                      local encoded = Base64.encodeToString(String(newText).getBytes("UTF-8"), Base64.NO_WRAP)
                      
                      if newName ~= itemName and newName ~= "" then
                        local dirPath = itemPath:match("(.*/)") or ""
                        local newPath = dirPath .. newName
                        showLoading("Renaming & Saving file...")
                        local jsonDelete = '{"message":"Renaming file","sha":"' .. sha .. '"}'
                        httpRequest("https://api.github.com/repos/" .. owner .. "/" .. repo .. "/contents/" .. itemPath, "DELETE", jsonDelete, function(dCode, dRes)
                          local jsonCreate = '{"message":"Created via GitHub Manager","content":"' .. encoded .. '"}'
                          httpRequest("https://api.github.com/repos/" .. owner .. "/" .. repo .. "/contents/" .. newPath, "PUT", jsonCreate, function(cCode, cRes)
                            showFilesList(owner, repo, path)
                          end)
                        end)
                      else
                        local json = '{"message":"Updated via GitHub Manager","content":"' .. encoded .. '","sha":"' .. sha .. '"}'
                        showLoading("Saving file...")
                        httpRequest("https://api.github.com/repos/" .. owner .. "/" .. repo .. "/contents/" .. itemPath, "PUT", json, function(sCode, sRes)
                          showFilesList(owner, repo, path)
                        end)
                      end
                    end
                  }))
                  editLayout.addView(btnSave)

                  local btnDeleteFile = Button(service)
                  btnDeleteFile.setText("Delete File")
                  btnDeleteFile.setOnClickListener(View.OnClickListener({
                    onClick = function()
                      local confRoot = LinearLayout(service)
                      confRoot.setOrientation(LinearLayout.VERTICAL)
                      confRoot.setBackgroundColor(Color.BLACK)
                      confRoot.setPadding(20, 20, 20, 20)

                      local confScroll = ScrollView(service)
                      local confLayout = LinearLayout(service)
                      confLayout.setOrientation(LinearLayout.VERTICAL)

                      confLayout.addView(createHeader("Confirm File Deletion"))

                      local confInfo = TextView(service)
                      confInfo.setText("Are you sure you want to delete '" .. itemName .. "'?")
                      confInfo.setTextColor(Color.YELLOW)
                      confInfo.setTextSize(16)
                      confInfo.setPadding(20, 20, 20, 20)
                      confLayout.addView(confInfo)

                      local btnConfirmDel = Button(service)
                      btnConfirmDel.setText("Yes, Delete File")
                      btnConfirmDel.setOnClickListener(View.OnClickListener({
                        onClick = function()
                          local jsonDelete = '{"message":"Deleted via GitHub Manager","sha":"' .. sha .. '"}'
                          showLoading("Deleting file...")
                          httpRequest("https://api.github.com/repos/" .. owner .. "/" .. repo .. "/contents/" .. itemPath, "DELETE", jsonDelete, function(dCode, dRes)
                            showFilesList(owner, repo, path)
                          end)
                        end
                      }))
                      confLayout.addView(btnConfirmDel)

                      local btnCancelDel = Button(service)
                      btnCancelDel.setText("Cancel")
                      btnCancelDel.setOnClickListener(View.OnClickListener({
                        onClick = function()
                          showFilesList(owner, repo, path)
                        end
                      }))
                      confLayout.addView(btnCancelDel)

                      confScroll.addView(confLayout)
                      confRoot.addView(confScroll)
                      enableBackKey(confRoot, function() showFilesList(owner, repo, path) end)
                      setScreen(confRoot)
                    end
                  }))
                  editLayout.addView(btnDeleteFile)

                  local btnCancel = Button(service)
                  btnCancel.setText("Cancel")
                  btnCancel.setOnClickListener(View.OnClickListener({
                    onClick = function() showFilesList(owner, repo, path) end
                  }))
                  editLayout.addView(btnCancel)

                  editScroll.addView(editLayout)
                  editRoot.addView(editScroll)
                  enableBackKey(editRoot, function() showFilesList(owner, repo, path) end)
                  setScreen(editRoot)
                end
              end)
            end
          end
        }))
        layout.addView(btn)
      end
    end)

    if not hasItems then
      local info = TextView(service)
      info.setText("No files or folders found here.")
      info.setTextColor(Color.YELLOW)
      info.setTextSize(16)
      info.setPadding(20, 20, 20, 20)
      layout.addView(info)
    end

    local btnBack = Button(service)
    btnBack.setText("Back to Repo Menu")
    btnBack.setOnClickListener(View.OnClickListener({
      onClick = function() showRepoMenu(owner, repo) end
    }))
    layout.addView(btnBack)

    scroll.addView(layout)
    root.addView(scroll)
    enableBackKey(root, function() showRepoMenu(owner, repo) end)
    setScreen(root)
  end)
end

showRepoMenu = function(owner, repo, isPrivate)
  if loadToken() == "" then
    showTokenMissingScreen()
    return
  end

  if isPrivate == nil then
    showLoading("Loading repo info...")
    httpRequest("https://api.github.com/repos/" .. owner .. "/" .. repo, "GET", nil, function(code, res)
      local fetchedPrivate = false
      if code == 200 then
        pcall(function()
          local obj = JSONObject(res)
          fetchedPrivate = obj.getBoolean("private")
        end)
      end
      showRepoMenu(owner, repo, fetchedPrivate)
    end)
    return
  end

  local root = LinearLayout(service)
  root.setOrientation(LinearLayout.VERTICAL)
  root.setBackgroundColor(Color.BLACK)
  root.setPadding(20, 20, 20, 20)

  local scroll = ScrollView(service)
  local layout = LinearLayout(service)
  layout.setOrientation(LinearLayout.VERTICAL)

  layout.addView(createHeader("Repository: " .. repo))

  local btnBrowse = Button(service)
  btnBrowse.setText("Browse & Edit Files")
  btnBrowse.setOnClickListener(View.OnClickListener({
    onClick = function() showFilesList(owner, repo, "") end
  }))
  layout.addView(btnBrowse)

  local btnUpload = Button(service)
  btnUpload.setText("Upload New File")
  btnUpload.setOnClickListener(View.OnClickListener({
    onClick = function()
      local uRoot = LinearLayout(service)
      uRoot.setOrientation(LinearLayout.VERTICAL)
      uRoot.setBackgroundColor(Color.BLACK)
      uRoot.setPadding(20, 20, 20, 20)

      local uScroll = ScrollView(service)
      local uLayout = LinearLayout(service)
      uLayout.setOrientation(LinearLayout.VERTICAL)

      uLayout.addView(createHeader("New File in " .. repo))

      local inputName = EditText(service)
      inputName.setHint("File Name e.g. test.txt")
      inputName.setTextColor(Color.WHITE)
      inputName.setHintTextColor(Color.GRAY)
      uLayout.addView(inputName)

      local inputContent = EditText(service)
      inputContent.setHint("File Content")
      inputContent.setTextColor(Color.WHITE)
      inputContent.setHintTextColor(Color.GRAY)
      uLayout.addView(inputContent)

      local btnSubmit = Button(service)
      btnSubmit.setText("Create File")
      
      local function updateUploadState()
        local nVal = tostring(inputName.getText())
        local cVal = tostring(inputContent.getText())
        btnSubmit.setEnabled(nVal ~= "" and cVal ~= "")
      end
      updateUploadState()

      local uploadWatcher = TextWatcher({
        onTextChanged = function() updateUploadState() end,
        beforeTextChanged = function() end,
        afterTextChanged = function() end
      })
      inputName.addTextChangedListener(uploadWatcher)
      inputContent.addTextChangedListener(uploadWatcher)

      btnSubmit.setOnClickListener(View.OnClickListener({
        onClick = function()
          local fileName = tostring(inputName.getText())
          local fileContent = tostring(inputContent.getText())
          if fileName ~= "" then
            showLoading("Checking file...")
            httpRequest("https://api.github.com/repos/" .. owner .. "/" .. repo .. "/contents/", "GET", nil, function(code, res)
              local found = false
              local existingFileName = ""
              local fileSha = ""
              if code == 200 then
                pcall(function()
                  local arr = JSONArray(res)
                  for i = 0, arr.length() - 1 do
                    local item = arr.getJSONObject(i)
                    local name = item.getString("name")
                    if string.lower(name) == string.lower(fileName) then
                      found = true
                      existingFileName = name
                      fileSha = item.getString("sha")
                      break
                    end
                  end
                end)
              end

              local function doSaveFile(shaToUse)
                local encoded = Base64.encodeToString(String(fileContent).getBytes("UTF-8"), Base64.NO_WRAP)
                local json = ""
                if shaToUse and shaToUse ~= "" then
                  json = '{"message":"Updated via GitHub Manager","content":"' .. encoded .. '","sha":"' .. shaToUse .. '"}'
                else
                  json = '{"message":"Created via GitHub Manager","content":"' .. encoded .. '"}'
                end
                showLoading("Saving file...")
                httpRequest("https://api.github.com/repos/" .. owner .. "/" .. repo .. "/contents/" .. (shaToUse and shaToUse ~= "" and existingFileName or fileName), "PUT", json, function(cCode, cRes)
                  if cCode == 201 or cCode == 200 then
                    local succRoot = LinearLayout(service)
                    succRoot.setOrientation(LinearLayout.VERTICAL)
                    succRoot.setBackgroundColor(Color.BLACK)
                    succRoot.setPadding(20, 20, 20, 20)

                    local succScroll = ScrollView(service)
                    local succLayout = LinearLayout(service)
                    succLayout.setOrientation(LinearLayout.VERTICAL)

                    succLayout.addView(createHeader("Success"))
                    local info = TextView(service)
                    info.setText("File saved successfully!")
                    info.setTextColor(Color.GREEN)
                    info.setTextSize(16)
                    info.setPadding(20, 20, 20, 20)
                    succLayout.addView(info)

                    local btnOk = Button(service)
                    btnOk.setText("OK")
                    btnOk.setOnClickListener(View.OnClickListener({
                      onClick = function() showRepoMenu(owner, repo, isPrivate) end
                    }))
                    succLayout.addView(btnOk)

                    succScroll.addView(succLayout)
                    succRoot.addView(succScroll)
                    enableBackKey(succRoot, function() showRepoMenu(owner, repo, isPrivate) end)
                    setScreen(succRoot)
                  else
                    showRepoMenu(owner, repo, isPrivate)
                  end
                end)
              end

              if found then
                local confRoot = LinearLayout(service)
                confRoot.setOrientation(LinearLayout.VERTICAL)
                confRoot.setBackgroundColor(Color.BLACK)
                confRoot.setPadding(20, 20, 20, 20)

                local confScroll = ScrollView(service)
                local confLayout = LinearLayout(service)
                confLayout.setOrientation(LinearLayout.VERTICAL)

                confLayout.addView(createHeader("File Exists"))
                local info = TextView(service)
                info.setText("File '" .. existingFileName .. "' already exists. Do you want to overwrite it?")
                info.setTextColor(Color.YELLOW)
                info.setTextSize(16)
                info.setPadding(20, 20, 20, 20)
                confLayout.addView(info)

                local btnYes = Button(service)
                btnYes.setText("Yes, Overwrite")
                btnYes.setOnClickListener(View.OnClickListener({
                  onClick = function()
                    doSaveFile(fileSha)
                  end
                }))
                confLayout.addView(btnYes)

                local btnNo = Button(service)
                btnNo.setText("Cancel")
                btnNo.setOnClickListener(View.OnClickListener({
                  onClick = function() showRepoMenu(owner, repo, isPrivate) end
                }))
                confLayout.addView(btnNo)

                confScroll.addView(confLayout)
                confRoot.addView(confScroll)
                enableBackKey(confRoot, function() showRepoMenu(owner, repo, isPrivate) end)
                setScreen(confRoot)
              else
                doSaveFile(nil)
              end
            end)
          end
        end
      }))
      uLayout.addView(btnSubmit)

      local btnBack = Button(service)
      btnBack.setText("Back")
      btnBack.setOnClickListener(View.OnClickListener({
        onClick = function() showRepoMenu(owner, repo, isPrivate) end
      }))
      uLayout.addView(btnBack)

      uScroll.addView(uLayout)
      uRoot.addView(uScroll)
      enableBackKey(uRoot, function() showRepoMenu(owner, repo, isPrivate) end)
      setScreen(uRoot)
    end
  }))
  layout.addView(btnUpload)

  local btnRenameRepo = Button(service)
  btnRenameRepo.setText("Rename Repository")
  btnRenameRepo.setOnClickListener(View.OnClickListener({
    onClick = function()
      local rRoot = LinearLayout(service)
      rRoot.setOrientation(LinearLayout.VERTICAL)
      rRoot.setBackgroundColor(Color.BLACK)
      rRoot.setPadding(20, 20, 20, 20)

      local rScroll = ScrollView(service)
      local rLayout = LinearLayout(service)
      rLayout.setOrientation(LinearLayout.VERTICAL)

      rLayout.addView(createHeader("Rename " .. repo))

      local inputNewRepoName = EditText(service)
      inputNewRepoName.setHint("New Repository Name")
      inputNewRepoName.setText(tostring(repo))
      inputNewRepoName.setTextColor(Color.WHITE)
      inputNewRepoName.setHintTextColor(Color.GRAY)
      rLayout.addView(inputNewRepoName)

      local btnSubmitRename = Button(service)
      btnSubmitRename.setText("Rename")
      
      local function updateRenameState()
        local val = tostring(inputNewRepoName.getText())
        btnSubmitRename.setEnabled(val ~= "")
      end
      updateRenameState()

      inputNewRepoName.addTextChangedListener(TextWatcher({
        onTextChanged = function() updateRenameState() end,
        beforeTextChanged = function() end,
        afterTextChanged = function() end
      }))

      btnSubmitRename.setOnClickListener(View.OnClickListener({
        onClick = function()
          local newRName = tostring(inputNewRepoName.getText())
          if newRName ~= "" and newRName ~= repo then
            local jsonRename = '{"name":"' .. newRName .. '"}'
            showLoading("Renaming repository...")
            httpRequest("https://api.github.com/repos/" .. owner .. "/" .. repo, "PATCH", jsonRename, function(renCode, renRes)
              if renCode == 200 then
                showRepoMenu(owner, newRName, isPrivate)
              else
                showRepoMenu(owner, repo, isPrivate)
              end
            end)
          end
        end
      }))
      rLayout.addView(btnSubmitRename)

      local btnBackRen = Button(service)
      btnBackRen.setText("Back")
      btnBackRen.setOnClickListener(View.OnClickListener({
        onClick = function() showRepoMenu(owner, repo, isPrivate) end
      }))
      rLayout.addView(btnBackRen)

      rScroll.addView(rLayout)
      rRoot.addView(rScroll)
      enableBackKey(rRoot, function() showRepoMenu(owner, repo, isPrivate) end)
      setScreen(rRoot)
    end
  }))
  layout.addView(btnRenameRepo)

  local visStatusStr = isPrivate and "Private" or "Public"
  local btnToggleVisibility = Button(service)
  btnToggleVisibility.setText("Visibility: " .. visStatusStr)
  btnToggleVisibility.setOnClickListener(View.OnClickListener({
    onClick = function()
      local vRoot = LinearLayout(service)
      vRoot.setOrientation(LinearLayout.VERTICAL)
      vRoot.setBackgroundColor(Color.BLACK)
      vRoot.setPadding(20, 20, 20, 20)

      local vScroll = ScrollView(service)
      local vLayout = LinearLayout(service)
      vLayout.setOrientation(LinearLayout.VERTICAL)

      vLayout.addView(createHeader("Visibility: " .. repo))

      local vInfo = TextView(service)
      vInfo.setText("Current Visibility: " .. visStatusStr)
      vInfo.setTextColor(Color.YELLOW)
      vInfo.setTextSize(16)
      vInfo.setPadding(20, 20, 20, 20)
      vLayout.addView(vInfo)

      if isPrivate then
        local btnMakePublic = Button(service)
        btnMakePublic.setText("Make Public")
        btnMakePublic.setOnClickListener(View.OnClickListener({
          onClick = function()
            showLoading("Changing to Public...")
            httpRequest("https://api.github.com/repos/" .. owner .. "/" .. repo, "PATCH", '{"private":false}', function(pCode, pRes)
              showRepoMenu(owner, repo, false)
            end)
          end
        }))
        vLayout.addView(btnMakePublic)
      else
        local btnMakePrivate = Button(service)
        btnMakePrivate.setText("Make Private")
        btnMakePrivate.setOnClickListener(View.OnClickListener({
          onClick = function()
            showLoading("Changing to Private...")
            httpRequest("https://api.github.com/repos/" .. owner .. "/" .. repo, "PATCH", '{"private":true}', function(pCode, pRes)
              showRepoMenu(owner, repo, true)
            end)
          end
        }))
        vLayout.addView(btnMakePrivate)
      end

      local btnBackVis = Button(service)
      btnBackVis.setText("Cancel")
      btnBackVis.setOnClickListener(View.OnClickListener({
        onClick = function() showRepoMenu(owner, repo, isPrivate) end
      }))
      vLayout.addView(btnBackVis)

      vScroll.addView(vLayout)
      vRoot.addView(vScroll)
      enableBackKey(vRoot, function() showRepoMenu(owner, repo, isPrivate) end)
      setScreen(vRoot)
    end
  }))
  layout.addView(btnToggleVisibility)

  local btnDelete = Button(service)
  btnDelete.setText("Delete Repository")
  btnDelete.setOnClickListener(View.OnClickListener({
    onClick = function()
      local rConfRoot = LinearLayout(service)
      rConfRoot.setOrientation(LinearLayout.VERTICAL)
      rConfRoot.setBackgroundColor(Color.BLACK)
      rConfRoot.setPadding(20, 20, 20, 20)

      local rConfScroll = ScrollView(service)
      local rConfLayout = LinearLayout(service)
      rConfLayout.setOrientation(LinearLayout.VERTICAL)

      rConfLayout.addView(createHeader("Confirm Repository Deletion"))

      local rConfInfo = TextView(service)
      rConfInfo.setText("Are you sure you want to delete repository '" .. repo .. "'? This action cannot be undone.")
      rConfInfo.setTextColor(Color.YELLOW)
      rConfInfo.setTextSize(16)
      rConfInfo.setPadding(20, 20, 20, 20)
      rConfLayout.addView(rConfInfo)

      local btnConfirmRepoDel = Button(service)
      btnConfirmRepoDel.setText("Yes, Delete Repository")
      btnConfirmRepoDel.setOnClickListener(View.OnClickListener({
        onClick = function()
          showLoading("Deleting repository...")
          httpRequest("https://api.github.com/repos/" .. owner .. "/" .. repo, "DELETE", nil, function(dCode, dRes)
            showMyRepos()
          end)
        end
      }))
      rConfLayout.addView(btnConfirmRepoDel)

      local btnCancelRepoDel = Button(service)
      btnCancelRepoDel.setText("Cancel")
      btnCancelRepoDel.setOnClickListener(View.OnClickListener({
        onClick = function()
          showRepoMenu(owner, repo, isPrivate)
        end
      }))
      rConfLayout.addView(btnCancelRepoDel)

      rConfScroll.addView(rConfLayout)
      rConfRoot.addView(rConfScroll)
      enableBackKey(rConfRoot, function() showRepoMenu(owner, repo, isPrivate) end)
      setScreen(rConfRoot)
    end
  }))
  layout.addView(btnDelete)

  local btnBackMain = Button(service)
  btnBackMain.setText("Back to All Repositories")
  btnBackMain.setOnClickListener(View.OnClickListener({
    onClick = function() showMyRepos() end
  }))
  layout.addView(btnBackMain)

  scroll.addView(layout)
  root.addView(scroll)
  enableBackKey(root, function() showMyRepos() end)
  setScreen(root)
end

showMyRepos = function()
  if loadToken() == "" then
    showTokenMissingScreen()
    return
  end

  showLoading("Fetching Repositories...")
  httpRequest("https://api.github.com/user/repos?per_page=100", "GET", nil, function(code, res)
    if code ~= 200 then
      local errRoot = LinearLayout(service)
      errRoot.setOrientation(LinearLayout.VERTICAL)
      errRoot.setBackgroundColor(Color.BLACK)
      errRoot.setPadding(20, 20, 20, 20)

      local errScroll = ScrollView(service)
      local errLayout = LinearLayout(service)
      errLayout.setOrientation(LinearLayout.VERTICAL)

      errLayout.addView(createHeader("Error " .. code .. ": Check Token"))
      local btnBack = Button(service)
      btnBack.setText("Back")
      btnBack.setOnClickListener(View.OnClickListener({
        onClick = function() showMainScreen() end
      }))
      errLayout.addView(btnBack)

      errScroll.addView(errLayout)
      errRoot.addView(errScroll)
      enableBackKey(errRoot, function() showMainScreen() end)
      setScreen(errRoot)
      return
    end

    local rRoot = LinearLayout(service)
    rRoot.setOrientation(LinearLayout.VERTICAL)
    rRoot.setBackgroundColor(Color.BLACK)
    rRoot.setPadding(20, 20, 20, 20)

    local rScroll = ScrollView(service)
    local rLayout = LinearLayout(service)
    rLayout.setOrientation(LinearLayout.VERTICAL)

    rLayout.addView(createHeader("Select Repository"))

    pcall(function()
      local arr = JSONArray(res)
      if arr.length() == 0 then
        local info = TextView(service)
        info.setText("No repositories found in your account.")
        info.setTextColor(Color.YELLOW)
        info.setTextSize(16)
        info.setPadding(20, 20, 20, 20)
        rLayout.addView(info)
      else
        for i = 0, arr.length() - 1 do
          local obj = arr.getJSONObject(i)
          local rName = obj.getString("name")
          local ownerObj = obj.getJSONObject("owner")
          local ownerName = ownerObj.getString("login")
          local isPriv = obj.getBoolean("private")
          local btn = Button(service)
          btn.setText(rName)
          btn.setOnClickListener(View.OnClickListener({
            onClick = function()
              showRepoMenu(ownerName, rName, isPriv)
            end
          }))
          rLayout.addView(btn)
        end
      end
    end)

    local btnBack = Button(service)
    btnBack.setText("Back")
    btnBack.setOnClickListener(View.OnClickListener({
      onClick = function() showMainScreen() end
    }))
    rLayout.addView(btnBack)

    rScroll.addView(rLayout)
    rRoot.addView(rScroll)
    enableBackKey(rRoot, function() showMainScreen() end)
    setScreen(rRoot)
  end)
end

showMainScreen = function()
  local root = LinearLayout(service)
  root.setOrientation(LinearLayout.VERTICAL)
  root.setBackgroundColor(Color.BLACK)
  root.setPadding(20, 20, 20, 20)

  local scroll = ScrollView(service)
  local layout = LinearLayout(service)
  layout.setOrientation(LinearLayout.VERTICAL)

  layout.addView(createHeader("GitHub Manager"))

  local btnSetToken = Button(service)
  btnSetToken.setText("Set / Edit Personal Access Token")
  btnSetToken.setOnClickListener(View.OnClickListener({
    onClick = function()
      showTokenEditScreen()
    end
  }))
  layout.addView(btnSetToken)

  local btnMyRepos = Button(service)
  btnMyRepos.setText("My Repositories")
  btnMyRepos.setOnClickListener(View.OnClickListener({
    onClick = function()
      showMyRepos()
    end
  }))
  layout.addView(btnMyRepos)

  local btnCreateRepo = Button(service)
  btnCreateRepo.setText("Create New Repository")
  btnCreateRepo.setOnClickListener(View.OnClickListener({
    onClick = function()
      if loadToken() == "" then
        showTokenMissingScreen()
        return
      end

      local cRoot = LinearLayout(service)
      cRoot.setOrientation(LinearLayout.VERTICAL)
      cRoot.setBackgroundColor(Color.BLACK)
      cRoot.setPadding(20, 20, 20, 20)

      local cScroll = ScrollView(service)
      local cLayout = LinearLayout(service)
      cLayout.setOrientation(LinearLayout.VERTICAL)

      cLayout.addView(createHeader("Create Repository"))

      local input = EditText(service)
      input.setHint("Repository Name")
      input.setTextColor(Color.WHITE)
      input.setHintTextColor(Color.GRAY)
      cLayout.addView(input)

      local btnSub = Button(service)
      btnSub.setText("Create")
      
      local function updateCreateRepoState()
        local val = tostring(input.getText())
        btnSub.setEnabled(val ~= "")
      end
      updateCreateRepoState()

      input.addTextChangedListener(TextWatcher({
        onTextChanged = function() updateCreateRepoState() end,
        beforeTextChanged = function() end,
        afterTextChanged = function() end
      }))

      btnSub.setOnClickListener(View.OnClickListener({
        onClick = function()
          local rName = tostring(input.getText())
          if rName ~= "" then
            showLoading("Checking repository...")
            httpRequest("https://api.github.com/user/repos?per_page=100", "GET", nil, function(code, res)
              if code == 200 then
                local found = false
                local existingName = ""
                local ownerName = ""
                pcall(function()
                  local arr = JSONArray(res)
                  for i = 0, arr.length() - 1 do
                    local obj = arr.getJSONObject(i)
                    local name = obj.getString("name")
                    if string.lower(name) == string.lower(rName) then
                      found = true
                      existingName = name
                      ownerName = obj.getJSONObject("owner").getString("login")
                      break
                    end
                  end
                end)

                local function doCreateRepo(isPrivate)
                  showLoading("Creating repository...")
                  local json = '{"name":"' .. rName .. '","private":' .. tostring(isPrivate) .. '}'
                  httpRequest("https://api.github.com/user/repos", "POST", json, function(cCode, cRes)
                    if cCode == 201 or cCode == 200 then
                      local succRoot = LinearLayout(service)
                      succRoot.setOrientation(LinearLayout.VERTICAL)
                      succRoot.setBackgroundColor(Color.BLACK)
                      succRoot.setPadding(20, 20, 20, 20)

                      local succScroll = ScrollView(service)
                      local succLayout = LinearLayout(service)
                      succLayout.setOrientation(LinearLayout.VERTICAL)

                      succLayout.addView(createHeader("Success"))
                      local info = TextView(service)
                      info.setText("Repository '" .. rName .. "' created successfully!")
                      info.setTextColor(Color.GREEN)
                      info.setTextSize(16)
                      info.setPadding(20, 20, 20, 20)
                      succLayout.addView(info)

                      local btnOk = Button(service)
                      btnOk.setText("OK")
                      btnOk.setOnClickListener(View.OnClickListener({
                        onClick = function() showMainScreen() end
                      }))
                      succLayout.addView(btnOk)

                      succScroll.addView(succLayout)
                      succRoot.addView(succScroll)
                      enableBackKey(succRoot, function() showMainScreen() end)
                      setScreen(succRoot)
                    else
                      showMainScreen()
                    end
                  end)
                end

                local function showVisibilityOption(onSelected)
                  local visRoot = LinearLayout(service)
                  visRoot.setOrientation(LinearLayout.VERTICAL)
                  visRoot.setBackgroundColor(Color.BLACK)
                  visRoot.setPadding(20, 20, 20, 20)

                  local visScroll = ScrollView(service)
                  local visLayout = LinearLayout(service)
                  visLayout.setOrientation(LinearLayout.VERTICAL)

                  visLayout.addView(createHeader("Select Repository Type"))

                  local txtAsk = TextView(service)
                  txtAsk.setText("Choose repository visibility for '" .. rName .. "':")
                  txtAsk.setTextColor(Color.YELLOW)
                  txtAsk.setTextSize(16)
                  txtAsk.setPadding(20, 20, 20, 20)
                  visLayout.addView(txtAsk)

                  local btnPub = Button(service)
                  btnPub.setText("Public Repository")
                  btnPub.setOnClickListener(View.OnClickListener({
                    onClick = function() onSelected(false) end
                  }))
                  visLayout.addView(btnPub)

                  local btnPriv = Button(service)
                  btnPriv.setText("Private Repository")
                  btnPriv.setOnClickListener(View.OnClickListener({
                    onClick = function() onSelected(true) end
                  }))
                  visLayout.addView(btnPriv)

                  local btnCancelVis = Button(service)
                  btnCancelVis.setText("Cancel")
                  btnCancelVis.setOnClickListener(View.OnClickListener({
                    onClick = function() showMainScreen() end
                  }))
                  visLayout.addView(btnCancelVis)

                  visScroll.addView(visLayout)
                  visRoot.addView(visScroll)
                  enableBackKey(visRoot, function() showMainScreen() end)
                  setScreen(visRoot)
                end

                if found then
                  local confRoot = LinearLayout(service)
                  confRoot.setOrientation(LinearLayout.VERTICAL)
                  confRoot.setBackgroundColor(Color.BLACK)
                  confRoot.setPadding(20, 20, 20, 20)

                  local confScroll = ScrollView(service)
                  local confLayout = LinearLayout(service)
                  confLayout.setOrientation(LinearLayout.VERTICAL)

                  confLayout.addView(createHeader("Repository Exists"))
                  local info = TextView(service)
                  info.setText("Repository '" .. existingName .. "' already exists. Do you want to overwrite it?")
                  info.setTextColor(Color.YELLOW)
                  info.setTextSize(16)
                  info.setPadding(20, 20, 20, 20)
                  confLayout.addView(info)

                  local btnYes = Button(service)
                  btnYes.setText("Yes, Overwrite")
                  btnYes.setOnClickListener(View.OnClickListener({
                    onClick = function()
                      showVisibilityOption(function(isPrivate)
                        showLoading("Overwriting repository...")
                        httpRequest("https://api.github.com/repos/" .. ownerName .. "/" .. existingName, "DELETE", nil, function(dCode, dRes)
                          doCreateRepo(isPrivate)
                        end)
                      end)
                    end
                  }))
                  confLayout.addView(btnYes)

                  local btnNo = Button(service)
                  btnNo.setText("Cancel")
                  btnNo.setOnClickListener(View.OnClickListener({
                    onClick = function() showMainScreen() end
                  }))
                  confLayout.addView(btnNo)

                  confScroll.addView(confLayout)
                  confRoot.addView(confScroll)
                  enableBackKey(confRoot, function() showMainScreen() end)
                  setScreen(confRoot)
                else
                  showVisibilityOption(function(isPrivate)
                    doCreateRepo(isPrivate)
                  end)
                end
              else
                showMainScreen()
              end
            end)
          end
        end
      }))
      cLayout.addView(btnSub)

      local btnBack = Button(service)
      btnBack.setText("Back")
      btnBack.setOnClickListener(View.OnClickListener({
        onClick = function() showMainScreen() end
      }))
      cLayout.addView(btnBack)

      cScroll.addView(cLayout)
      cRoot.addView(cScroll)
      enableBackKey(cRoot, function() showMainScreen() end)
      setScreen(cRoot)
    end
  }))
  layout.addView(btnCreateRepo)

  local btnAbout = Button(service)
  btnAbout.setText("About & User Guide")
  btnAbout.setOnClickListener(View.OnClickListener({
    onClick = function()
      showAboutScreen()
    end
  }))
  layout.addView(btnAbout)

  local btnClose = Button(service)
  btnClose.setText("Close Extension")
  btnClose.setOnClickListener(View.OnClickListener({
    onClick = function() closeExtension() end
  }))
  layout.addView(btnClose)

  scroll.addView(layout)
  root.addView(scroll)
  enableBackKey(root, function() closeExtension() end)
  setScreen(root)
end

showMainScreen()