local e = ...
local r = {}
local x = {0x4E00, 0x1F300, 0xAC00, 0x1F600, 0xA000, 0x1200}
local i = 1
local k = 0
local len = #e
while i <= len do
    local b = string.byte(e, i)
    local c = 0
    local n = 1
    if b < 128 then c = b
    elseif b < 224 then c = (b - 192) * 64 + (string.byte(e, i+1) - 128); n = 2
    elseif b < 240 then c = (b - 224) * 4096 + (string.byte(e, i+1) - 128) * 64 + (string.byte(e, i+2) - 128); n = 3
    else c = (b - 240) * 262144 + (string.byte(e, i+1) - 128) * 4096 + (string.byte(e, i+2) - 128) * 64 + (string.byte(e, i+3) - 128); n = 4 end
    
    local v = c - x[(k % 6) + 1]
    if v < 0 then v = 0 end
    r[#r+1] = string.char(v)
    i = i + n
    k = k + 1
end
local L = loadstring or load
L(table.concat(r))()
