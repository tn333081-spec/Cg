require "import";
import "android.content.Context"
import "android.media.AudioManager"
import "com.androlua.*"
local audioManager=service.getSystemService(this.AUDIO_SERVICE)
local audioMode = audioManager.getRingerMode()
if audioMode == 1 then
audioManager.setRingerMode(audioManager.RINGER_MODE_NORMAL)
service.playSoundTick()
service.speak ("your phone is switched to normal mode")
elseif audioMode == 2 then
audioManager.setRingerMode(audioManager.RINGER_MODE_VIBRATE)
this.speak("your phone is switched to silent mode ")
end
return true
