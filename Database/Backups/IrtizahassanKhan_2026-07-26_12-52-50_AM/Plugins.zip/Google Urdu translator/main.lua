require "import"
import "com.androlua.*"
import "java.util.Locale"
import "android.net.Uri"

-- Function to split text by lines
function splitLines(s)
    local lines = {}
    for line in s:gmatch("[^\r\n]+") do
        table.insert(lines, line)
    end
    return lines
end

local url = "https://translate.google.com/m?sl=auto&tl=ur&q="..Uri.encode(this.getText(node))
Http.get(url, function(status, result)
    if status == 200 then
        local translatedText = result:match('<div class="result%-container">([^<]+)</div>')
        if translatedText then
            local lines = splitLines(translatedText)
            for _, line in ipairs(lines) do
                print(line)
            end
        else
            print("Translation not found")
        end
    else
        print("Error :-(")
    end
end)