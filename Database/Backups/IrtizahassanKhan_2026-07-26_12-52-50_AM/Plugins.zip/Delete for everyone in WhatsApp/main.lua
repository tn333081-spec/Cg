
if service.click({
{"%Long press$100",
"%Go back$100",
"Delete$100",
"Delete for everyone$100",
"Delete for everyone$100",
}
})
return true
end
