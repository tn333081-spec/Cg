require "import"
import "android.app.AlertDialog"
import "android.content.DialogInterface"
import "android.view.WindowManager"
import "android.content.Intent"
import "android.content.IntentFilter"
import "android.os.BatteryManager"

-- 1. Real-time Accurate Battery Data Fetch Karna
local filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
local batteryStatus = service.registerReceiver(nil, filter)

-- Percentage Calculation
local level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
local scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
local pct_value = math.floor((level / scale) * 100)
local battery_pct = pct_value .. "%"

-- Temperature Logic (Ab Limit 41 °C set kar di hai)
local temp = batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
local temp_celsius = temp / 10
local battery_temp_line = ""

if temp_celsius >= 41 then
    -- Agar temperature 41 ya usse zyada hai tabhi High show hoga
    battery_temp_line = "High Temperature: " .. temp_celsius .. " °C"
else
    -- 41 se niche standard label show hoga
    battery_temp_line = "Battery Temperature: " .. temp_celsius .. " °C"
end

-- Health Status
local health = batteryStatus.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
local battery_health = "Unknown"

if health == BatteryManager.BATTERY_HEALTH_GOOD then
    battery_health = "Good"
elseif health == BatteryManager.BATTERY_HEALTH_DEAD then
    battery_health = "Dead (Kharab)"
elseif health == BatteryManager.BATTERY_HEALTH_OVERHEAT then
    battery_health = "Overheat (Bohat Garam)"
elseif health == BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE then
    battery_health = "Over Voltage (Kharab)"
elseif health == BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE then
    battery_health = "Failure (Kharab/Khata)"
elseif health == BatteryManager.BATTERY_HEALTH_COLD then
    battery_health = "Cold"
end

-- Remaining Backup Time
local status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
local isCharging = (status == BatteryManager.BATTERY_STATUS_CHARGING or status == BatteryManager.BATTERY_STATUS_FULL)

local remaining_time = "Calculating..."
if isCharging then
    if pct_value >= 100 then
        remaining_time = "Full"
    else
        remaining_time = math.floor((100 - pct_value) * 2) .. " minutes (To Full)"
    end
else
    remaining_time = math.floor(pct_value * 5) .. " minutes"
end

-- 2. Dialog Formatting
local title = "Battery information"
local message = string.format(
    "Battery Percentage: %s\n\n%s\n\nEstimated Remaining Time: %s\n\nBattery Health: %s",
    battery_pct, battery_temp_line, remaining_time, battery_health
)

-- 3. Dialog UI Creation
local builder = AlertDialog.Builder(service)
builder.setTitle(title)
builder.setMessage(message)

builder.setPositiveButton("Exit", DialogInterface.OnClickListener{
    onClick = function(dialog, which)
        dialog.dismiss()
    end
})

local dialog = builder.create()

-- Overlay Window Setup
local window = dialog.getWindow()
if window then
    window.setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
end

dialog.show()