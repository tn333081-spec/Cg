require "import"
import "java.io.File"
import "java.io.FileInputStream"
import "java.io.FileOutputStream"
import "android.widget.*"
import "android.os.Environment"
import "android.content.Intent"
import "android.net.Uri"
import "android.view.View"
import "java.util.zip.ZipFile"
import "java.util.ArrayList"
import "android.media.MediaPlayer"
import "android.media.ToneGenerator"
import "android.media.AudioManager"
import "android.view.Menu"
import "android.graphics.Color"
local app=node.getPackageName()
if app then
local function extractAudioFiles(packageName)
local pm=this.getPackageManager()
local appInfo=pm.getApplicationInfo(packageName,0)
local sourceApkPath=appInfo.sourceDir
local function sanitizeFileName(name)
return name:gsub("[/\\:*?<>|]","_")
end
local exportFolder=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString().."/Extract audio files"
local exportDir=File(exportFolder)
if not exportDir.exists() then
exportDir.mkdirs()
end
local audioEntries=ArrayList()
local audioNames=ArrayList()
local audioNamesOriginal=ArrayList()
local selectedItems={}
local success,err=pcall(function()
local zipFile=ZipFile(sourceApkPath)
local entries=zipFile.entries()
while entries.hasMoreElements() do
local entry=entries.nextElement()
local entryName=entry.getName()
if not entry.isDirectory() and (entryName:match("%.mp3$") or entryName:match("%.ogg$") or entryName:match("%.wav$") or entryName:match("%.m4a$") or entryName:match("%.aac$") or entryName:match("%.flac$")) then
local fileName=entryName:match("([^/]+)$")
audioEntries.add(entry)
audioNamesOriginal.add(fileName)
audioNames.add(fileName)
end
end
return zipFile
end)
if not success then
service.speak("Error extracting audio files: "..err)
return
end
local zipFile=err
if audioNames.size()==0 then
service.speak("No audio files found in this application")
zipFile.close()
return
end
service.speak("Found "..audioNames.size().." audio files. Tap to preview, long press to select for download.")
local mediaPlayer=MediaPlayer()
local tempFile=File(this.getCacheDir(),"temp_audio")
local currentPlayingPosition=-1
local toneGenerator=ToneGenerator(AudioManager.STREAM_NOTIFICATION,50)
local function playAudioFile(entry,position)
if mediaPlayer.isPlaying() then
if currentPlayingPosition==position then
mediaPlayer.pause()
return
else
mediaPlayer.stop()
end
elseif currentPlayingPosition==position and not mediaPlayer.isPlaying() then
mediaPlayer.start()
return
end
mediaPlayer.reset()
currentPlayingPosition=position
local successPlay,errPlay=pcall(function()
local inputStream=zipFile.getInputStream(entry)
local outputStream=FileOutputStream(tempFile)
local buffer=byte[4096]
local length
while true do
length=inputStream.read(buffer)
if length<=0 then break end
outputStream.write(buffer,0,length)
end
inputStream.close()
outputStream.close()
mediaPlayer.setDataSource(tempFile.getAbsolutePath())
mediaPlayer.prepare()
mediaPlayer.start()
end)
if not successPlay then
service.speak("Error playing audio file: "..errPlay)
end
end
local adapter
local function resetAudioNames()
for i=0,audioNames.size()-1 do
audioNames.set(i,audioNamesOriginal.get(i))
end
end
local function updateButtonVisibility()
local count=0
local hasSelection=false
for k,v in pairs(selectedItems) do
if v then
hasSelection=true
count=count+1
end
end
if hasSelection then
downloadButton.setVisibility(View.VISIBLE)
deselectAllButton.setVisibility(View.VISIBLE)
else
downloadButton.setVisibility(View.GONE)
deselectAllButton.setVisibility(View.GONE)
end
if count==audioNames.size() and count>0 then
selectAllButton.setText("Unselect All")
else
selectAllButton.setText("Select All")
end
end
local function saveSelectedFiles()
local savedCount=0
for pos,isSelected in pairs(selectedItems) do
if isSelected then
local entry=audioEntries.get(pos)
local fileName=audioNamesOriginal.get(pos)
local outputPath=exportFolder.."/"..sanitizeFileName(fileName)
local successSave,errSave=pcall(function()
local inputStream=zipFile.getInputStream(entry)
local outputStream=FileOutputStream(outputPath)
local buffer=byte[4096]
local length
while true do
length=inputStream.read(buffer)
if length<=0 then break end
outputStream.write(buffer,0,length)
end
inputStream.close()
outputStream.close()
end)
if successSave then
savedCount=savedCount+1
else
service.speak("Error saving file "..fileName..": "..errSave)
end
end
end
if savedCount>0 then
service.speak("Successfully saved "..savedCount.." audio files to "..exportFolder)
selectedItems={}
resetAudioNames()
adapter.notifyDataSetChanged()
updateButtonVisibility()
else
service.speak("No files selected for download")
end
end
local function selectAllAudios()
for i=0,audioNames.size()-1 do
selectedItems[i]=true
local originalName=audioNamesOriginal.get(i)
audioNames.set(i,"Selected, "..originalName)
end
adapter.notifyDataSetChanged()
updateButtonVisibility()
end
local function showExportDialog()
local dialogLayout={
LinearLayout,
orientation=1,
layout_width="fill",
layout_height="fill",
{
RelativeLayout,
layout_width="fill",
layout_height="wrap_content",
{
TextView,
id="titleText",
text="Found "..audioNames.size().." audio files",
textSize="18sp",
textColor="#000000",
layout_width="wrap_content",
layout_height="wrap_content",
layout_margin="10dp"
},
{
Button,
id="downloadButton",
text="Download Selected",
layout_width="wrap_content",
layout_height="wrap_content",
layout_alignParentRight=true,
layout_centerVertical=true,
layout_margin="10dp",
visibility=View.GONE,
onClick=function()
saveSelectedFiles()
end
}
},
{
ListView,
id="audioListView",
layout_width="fill",
layout_height="wrap_content",
layout_weight=1
},
{
LinearLayout,
orientation=0,
layout_width="fill",
layout_height="wrap_content",
{
Button,
id="selectAllButton",
text="Select All",
layout_width="wrap_content",
layout_height="wrap_content",
layout_weight=1,
onClick=function()
if selectAllButton.getText()=="Unselect All" then
selectedItems={}
resetAudioNames()
adapter.notifyDataSetChanged()
updateButtonVisibility()
else
selectAllAudios()
end
end
},
{
Button,
text="Exit",
layout_width="wrap_content",
layout_height="wrap_content",
layout_weight=1,
onClick=function()
if mediaPlayer.isPlaying() then
mediaPlayer.stop()
end
mediaPlayer.release()
toneGenerator.release()
zipFile.close()
if tempFile.exists() then
tempFile.delete()
end
exportDialog.dismiss()
end
}
},
{
Button,
id="deselectAllButton",
text="Deselect All",
layout_width="fill",
layout_height="wrap_content",
visibility=View.GONE,
onClick=function()
selectedItems={}
resetAudioNames()
adapter.notifyDataSetChanged()
updateButtonVisibility()
end
}
}
exportDialog=LuaDialog(this)
exportDialog.setView(loadlayout(dialogLayout))
exportDialog.setTitle("Extract audio internall application")
adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,audioNames)
audioListView.setAdapter(adapter)
audioListView.onItemClick=function(parent,view,position,id)
local entry=audioEntries.get(position)
playAudioFile(entry,position)
end
audioListView.onItemLongClick=function(parent,view,position,id)
if selectedItems[position] then
selectedItems[position]=nil
audioNames.set(position,audioNamesOriginal.get(position))
toneGenerator.startTone(ToneGenerator.TONE_PROP_BEEP,150)
else
selectedItems[position]=true
local originalName=audioNamesOriginal.get(position)
audioNames.set(position,"Selected, "..originalName)
toneGenerator.startTone(ToneGenerator.TONE_PROP_ACK,150)
end
adapter.notifyDataSetChanged()
updateButtonVisibility()
return true
end
exportDialog.show()
end
showExportDialog()
end
extractAudioFiles(app)
else
service.speak("Sorry! Could not find the current application package name :(")
end