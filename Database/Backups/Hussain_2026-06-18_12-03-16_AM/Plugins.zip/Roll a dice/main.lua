require "import"
import "com.androlua.Ticker"

-- Global state management
if not _G.scriptState then
  _G.scriptState = {
    isRunning = false,
    ticker = nil
  }
end

-- Enhanced cleanup function with proper state management
local function cleanup()
  if _G.scriptState.ticker then
    _G.scriptState.ticker.stop()
    _G.scriptState.ticker = nil
    _G.scriptState.isRunning = false
    service.speak("disabled")
    collectgarbage("collect")
    return true
  end
  return false
end

-- Configuration
local config = {
  clickCooldown = 100,
  checkInterval = 2000,
  maxRetries = 2,
  gcInterval = 30
}

-- Local state for click handling
local state = {
  lastClickTime = 0,
  retryCount = 0,
  lastGC = os.time()
}

-- Optimized click function
local function tryClick()
  if not _G.scriptState.isRunning then
    cleanup()
    return
  end

  local currentTime = os.time() * 1500
  
  if (currentTime - state.lastClickTime) < config.clickCooldown then
    return
  end
  
  local success, found = pcall(function()
    return service.click({{"Roll a dice", "Roll*"}})
  end)
  
  if success and found then
    state.lastClickTime = currentTime
    state.retryCount = 0
  else
    state.retryCount = state.retryCount + 1
  end
  
  if state.retryCount >= config.maxRetries then
    state.retryCount = 0
    if os.time() - state.lastGC > config.gcInterval then
      collectgarbage("collect")
      state.lastGC = os.time()
    end
  end
end

-- Main toggle function
local function toggleClicker()
  -- If running, stop it
  if _G.scriptState.isRunning then
    cleanup()
    return true
  end
  
  -- If not running, start it
  cleanup() -- Clean up any existing ticker just in case
  
  -- Create new ticker
  _G.scriptState.ticker = Ticker()
  _G.scriptState.ticker.Period = config.checkInterval
  _G.scriptState.ticker.onTick = tryClick
  
  -- Start with error handling
  local success = pcall(function()
    _G.scriptState.ticker.start()
    _G.scriptState.isRunning = true
    service.speak("enabled")
  end)
  
  if not success then
    cleanup()
    return false
  end
  
  return true
end

-- Execute toggle when script runs
toggleClicker()