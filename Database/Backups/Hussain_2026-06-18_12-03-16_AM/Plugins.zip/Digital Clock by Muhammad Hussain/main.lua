require "import"
import "android.app.*"
import "android.content.*"

fst = true
UTC = os.time()
 time = os.date("today is: %A, %b %d, %Y, The time is:  %I:%M %p ", utc):gsub("is:  0", "is: ") 

service.playSoundClock ()
service.speak(time)
