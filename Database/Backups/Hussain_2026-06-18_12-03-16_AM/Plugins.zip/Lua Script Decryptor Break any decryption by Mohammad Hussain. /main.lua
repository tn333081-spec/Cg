-- Save existing loaders
local _old_loadfile = loadfile
local _old_load = load

-- Clipboard function (Jieshuo compatible)
local function copyToClipboard(text)
    if type(text) == "string" and #text > 50 then
        pcall(function() 
            if service and service.copy then service.copy(text) 
            else 
                import "android.content.Context"
                local clipboard = service.getSystemService(Context.CLIPBOARD_SERVICE)
                clipboard.setPrimaryClip(import "android.content.ClipData".newPlainText("Decrypted", text))
            end
        end)
        print("✅ SUCCESS: Code Clipboard mein copy ho gaya hai!")
    end
end

-- Hooking loadfile (Jieshuo plugins mostly isi se run hoti hain)
loadfile = function(filename, mode, env)
    print("Hooking file: " .. tostring(filename))
    
    -- File content read karein
    local f = io.open(filename, "r")
    if f then
        local content = f:read("*a")
        f:close()
        
        -- Agar file mein Jieshuo+ hai, toh uske baad ka hissa capture karein
        if content:find("Jieshuo%+") then
            print("⚠️ Encrypted file pakri gayi! Decrypting...")
            -- Agar ye decryption format mein hai, toh yahan logic lagayein
            -- Filhal content ko debug ke liye print kar rahe hain
            copyToClipboard(content)
        end
    end
    
    return _old_loadfile(filename, mode, env)
end

-- Hooking load (Standard load)
load = function(chunk, chunkname, mode, env)
    if type(chunk) == "string" and chunk:find("Jieshuo%+") then
        print("⚠️ Encrypted chunk pakra gaya!")
        copyToClipboard(chunk)
    end
    return _old_load(chunk, chunkname, mode, env)
end

print("🚀 RAM Hook Active! Ab koi bhi plugin run karein, main usay intercept karunga.")
