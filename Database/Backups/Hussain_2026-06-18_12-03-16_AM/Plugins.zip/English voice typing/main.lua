--con la actualización de los emojis
require "import"
import "android.content.Context"
import "android.content.Intent"
import "java.util.Locale"

import "android.speech.SpeechRecognizer"
import "android.speech.RecognitionListener"
import "android.speech.RecognizerIntent"
import "java.util.Locale"
import "android.content.Intent"

local substitutionTable = {
    ["chino"] = "Jieshuo"
}

function capitalizeFirstWord(text)
    local firstChar = text:sub(1, 1)
    local restOfString = text:sub(2)
    return firstChar:upper() .. restOfString
end

function substituteWords(text)
    for word, substitution in pairs(substitutionTable) do
        text = text:gsub("%f[%a]" .. word .. "%f[%A]", substitution)
    end
    return text
end

function capitalizeAfterPeriod(text)
    return text:gsub("(%.[%s]*%a)", function(match)
        local char = match:sub(-1)
        local capitalizedChar = char:upper()
        return match:sub(1, -2) .. capitalizedChar
    end)
end

function lowercaseAfterComma(text)
    return text:gsub("(%,[%s]*%a)", function(match)
        local char = match:sub(-1)
        local lowercaseChar = char:lower()
        return match:sub(1, -2) .. lowercaseChar
    end)
end

function addPunctuation(text)
    local lastChar = text:sub(-1)
    local punctuation = { ".", "!", "?" }
    local hasPunctuation = false

    for _, p in ipairs(punctuation) do
        if lastChar == p then
            hasPunctuation = true
            break
        end
    end

    if not hasPunctuation then
        text = text .. "."
    end

    return text
end

function hasInternetConnection()
    local connectivityManager = this.getSystemService(Context.CONNECTIVITY_SERVICE)
    local networkInfo = connectivityManager.getActiveNetworkInfo()
    return networkInfo ~= nil and networkInfo.isConnected()
end

function kill()
    speechRecognizer.destroy()
    speechRecognizer = nil
    return true
end

function startListening()
    if not hasInternetConnection() then
        -- No hay conexión a Internet, no se puede realizar el reconocimiento de voz
        service.asyncSpeak("No hay conexión a Internet. El reconocimiento de voz no está disponible.")
        return false
    end
    
    local verbalizationDetected = false
    
    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
    speechListener = RecognitionListener{
        onResults = function(results)
            data = results.getParcelableArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if data ~= nil and data.size() > 0 then
                -- Se ha detectado alguna verbalización
                verbalizationDetected = true
                local recognizedText = data.get(0)
                recognizedText = capitalizeFirstWord(recognizedText)
                recognizedText = substituteWords(recognizedText)
                recognizedText = capitalizeAfterPeriod(recognizedText)
                recognizedText = lowercaseAfterComma(recognizedText)
                recognizedText = addPunctuation(recognizedText)
--marcador signos de puntuación
                recognizedText = string.gsub(recognizedText, "(%s?)coma(%s?)([%p]*)$", "%2,%3")
                recognizedText = string.gsub(recognizedText, "(%s?)punto(%s?)([%p]*)$", "%2.%3")
                recognizedText = string.gsub(recognizedText, "(%s?)interrogación(%s?)([%p]*)$", "%2?")
                recognizedText = string.gsub(recognizedText, "(%s?)dos puntos(%s?)([%p]*)$", "%2:")
                recognizedText = string.gsub(recognizedText, "(%s?)comillas(%s?)([%p]*)$", "%2\"")
                recognizedText = string.gsub(recognizedText, "(%s?)Comillas(%s?)([%p]*)$", "%2\"")
-- marcador emojis
--versión con minúsculas en el primer carácter de la palabra clave
recognizedText = string.gsub(recognizedText, "(%s?)cara guiñando el ojo(%s?)", "%1\u{1F609}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara sonriendo con ojos grandes(%s?)", "%1\u{1F603}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara llorando(%s?)", "%1\u{1F622}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara gritando de miedo(%s?)", "%1\u{1F631}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara cabreada(%s?)", "%1\u{1F621}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara sonriendo con superioridad(%s?)", "%1\u{1F60F}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara decepcionada(%s?)", "%1\u{1F61E}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara sonriendo con sudor frío(%s?)", "%1\u{1F605}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara besando con los ojos cerrados(%s?)", "%1\u{1F61A}%2")
recognizedText = string.gsub(recognizedText, "(%s?)mono con la boca tapada(%s?)", "%1\u{1F64A}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara de alivio(%s?)", "%1\u{1F60C}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara sonriendo(%s?)", "%1\u{1F600}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara saboreando comida(%s?)", "%1\u{1F60B}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara sonriendo con los ojos cerrados(%s?)", "%1\u{1F606}%2")
recognizedText = string.gsub(recognizedText, "(%s?)señal de aprobación con la mano(%s?)", "%1\u{1F44C}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara neutral(%s?)", "%1\u{1F610}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara de confusión(%s?)", "%1\u{1F615}%2")
recognizedText = string.gsub(recognizedText, "(%s?)manos aplaudiendo(%s?)", "%1\u{1F44F}%2")
recognizedText = string.gsub(recognizedText, "(%s?)revolviéndose de la risa(%s?)", "%1\u{1F923}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara con ojos sonrientes(%s?)", "%1\u{1F60A}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara feliz con ojos sonrientes(%s?)", "%1\u{1F60A}%2")
recognizedText = string.gsub(recognizedText, "(%s?)emoji de fuego(%s?)", "%1\u{1F525}%2")
recognizedText = string.gsub(recognizedText, "(%s?)caca con ojos(%s?)", "%1\u{1F4A9}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara sonriendo con corazones(%s?)", "%1\u{1F60D}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara con lengua afuera(%s?)", "%1\u{1F61C}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara sacando la lengua(%s?)", "%1\u{1F61C}%2")
recognizedText = string.gsub(recognizedText, "(%s?)corazón rojo(%s?)", "%1\u{2764}%2")
recognizedText = string.gsub(recognizedText, "(%s?)corazón azul(%s?)", "%1\u{1F499}%2")
recognizedText = string.gsub(recognizedText, "(%s?)corazón verde(%s?)", "%1\u{1F49A}%2")
recognizedText = string.gsub(recognizedText, "(%s?)corazón negro(%s?)", "%1\u{1F5A4}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara con ojos en blanco(%s?)", "%1\u{1F644}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara llorando de risa(%s?)", "%1\u{1F602}%2")
recognizedText = string.gsub(recognizedText, "(%s?)pulgar hacia arriba(%s?)", "%1\u{1F44D}%2")
recognizedText = string.gsub(recognizedText, "(%s?)pulgar hacia abajo(%s?)", "%1\u{1F44E}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara con la boca abierta(%s?)", "%1\u{1F62E}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara enfadada(%s?)", "%1\u{1F620}%2")
recognizedText = string.gsub(recognizedText, "(%s?)manos en oración(%s?)", "%1\u{1F64F}%2")
recognizedText = string.gsub(recognizedText, "(%s?)cara con gafas de sol(%s?)", "%1\u{1F60E}%2")
-- marcador emojis con palabras clave en mayúsculas al principio
--versión con el primer carácter de la palabra clave en mayúscula
recognizedText = string.gsub(recognizedText, "(%s?)Cara guiñando el ojo(%s?)", "%1\u{1F609}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara sonriendo con ojos grandes(%s?)", "%1\u{1F603}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara llorando(%s?)", "%1\u{1F622}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara gritando de miedo(%s?)", "%1\u{1F631}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara cabreada(%s?)", "%1\u{1F621}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara sonriendo con superioridad(%s?)", "%1\u{1F60F}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara decepcionada(%s?)", "%1\u{1F61E}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara sonriendo con sudor frío(%s?)", "%1\u{1F605}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara besando con los ojos cerrados(%s?)", "%1\u{1F61A}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Mono con la boca tapada(%s?)", "%1\u{1F64A}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara de alivio(%s?)", "%1\u{1F60C}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara sonriendo(%s?)", "%1\u{1F600}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara saboreando comida(%s?)", "%1\u{1F60B}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara sonriendo con los ojos cerrados(%s?)", "%1\u{1F606}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Señal de aprobación con la mano(%s?)", "%1\u{1F44C}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara neutral(%s?)", "%1\u{1F610}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara de confusión(%s?)", "%1\u{1F615}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Manos aplaudiendo(%s?)", "%1\u{1F44F}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Revolviéndose de la risa(%s?)", "%1\u{1F923}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara con ojos sonrientes(%s?)", "%1\u{1F60A}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara feliz con ojos sonrientes(%s?)", "%1\u{1F60A}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Emoji de fuego(%s?)", "%1\u{1F525}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Caca con ojos(%s?)", "%1\u{1F4A9}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara sonriendo con corazones(%s?)", "%1\u{1F60D}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara con lengua afuera(%s?)", "%1\u{1F61C}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara sacando la lengua(%s?)", "%1\u{1F61C}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Corazón rojo(%s?)", "%1\u{2764}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Corazón azul(%s?)", "%1\u{1F499}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Corazón verde(%s?)", "%1\u{1F49A}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Corazón negro(%s?)", "%1\u{1F5A4}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara con ojos en blanco(%s?)", "%1\u{1F644}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara llorando de risa(%s?)", "%1\u{1F602}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Pulgar hacia arriba(%s?)", "%1\u{1F44D}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Pulgar hacia abajo(%s?)", "%1\u{1F44E}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara con la boca abierta(%s?)", "%1\u{1F62E}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara enfadada(%s?)", "%1\u{1F620}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Manos en oración(%s?)", "%1\u{1F64F}%2")
recognizedText = string.gsub(recognizedText, "(%s?)Cara con gafas de sol(%s?)", "%1\u{1F60E}%2")
service.getEditText()
local node = service.getEditText() -- Obtener el nodo de edición actual
service.insertText(node, recognizedText .. "\n")
                service.speak(recognizedText)
            end
            -- Si no se detectó ninguna verbalización en el primer intento, detener reconocimiento de voz
            if not verbalizationDetected then
                kill()
                return false
            end
        end,
        onError = function()
            -- Ocurrió un error, detener reconocimiento de voz
            kill()
            return false
        end
    }
    
    recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
    recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
    recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
    recognizerIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, this.getPackageName())
    speechRecognizer.startListening(recognizerIntent)
    speechRecognizer.setRecognitionListener(speechListener)
    
    return true
end

startListening()
return true