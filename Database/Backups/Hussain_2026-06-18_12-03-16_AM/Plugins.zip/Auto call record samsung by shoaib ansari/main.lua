
if service.click({
{">Phone",
"*More options*",
"*Settings*",
"*Record calls*",
"*Auto record calls*|*Auto record calls*",
"%Go back<3",
}
})
return true
end
