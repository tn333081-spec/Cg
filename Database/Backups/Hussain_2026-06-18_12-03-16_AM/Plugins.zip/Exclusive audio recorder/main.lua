require "import"
import "android.media.*"
import "java.io.File"
import "android.os.*"
import "android.content.*"
import "android.net.*"
import "android.widget.Button"
import "android.widget.LinearLayout"
import "android.view.View"
import "com.androlua.*"

local vibrator = this.getSystemService(this.VIBRATOR_SERVICE)
if vibrator then vibrator.vibrate(100) end

local folderPath = Environment.getExternalStorageDirectory().getAbsolutePath().."/Exclusive audio recorder/"
local file = File(folderPath)
if not file.exists() then success = file.mkdirs() end

function playMusic(player)
    if mp then
        mp.stop()
        mp = nil
    else
        mp = MediaPlayer()
        mp.setAudioStreamType(AudioManager.STREAM_MUSIC)
        mp.reset()
        mp.setDataSource(player)
        mp.prepare()
        mp.start()
        mp.setOnCompletionListener {
            onCompletion = function()
                mp.release()
                mp = nil
            end
        }
    end
    return true
end

local bitRateNames, bitRateValues = {"320 kbps", "256 kbps", "192 kbps", "160 kbps", "128 kbps", "96 kbps", "64 kbps", "32 kbps"}, {320000, 256000, 192000, 160000, 128000, 96000, 64000, 32000}
if not service.getSharedData("defaultAudioBitrate") then
    service.setSharedData("defaultAudioBitrate", bitRateValues[1])
end

local dlg = LuaDialog()
dlg.setCancelable(false)
dlg.setTitle("Bit rate")
dlg.setSingleChoiceItems(bitRateNames, table.find(bitRateValues, service.getSharedData("defaultAudioBitrate")) - 1)
dlg.setButton2("Save")
dlg.onItemClick = function(l, v, p, i)
    service.setSharedData("defaultAudioBitrate", bitRateValues[i])
    return
end

local focus = service.getText(node)
if focus == "Other options" or focus == "More options" then
    dlg.show()
    return
end

if mr then
    mr.pause()
    focus2 = this.getText(node)
    appName = this.getAppName(node)
    local dlg = LuaDialog()
    dlg.setTitle("Recording Paused")
    dlg.setButton("Resume Recording", function()
        mr.resume()
    end)
    dlg.setButton2("Stop Recording", function()
        mr.stop()
        mr.release()
        mr = nil
        if vibrator then vibrator.vibrate(100) end
        local layout = {
            LinearLayout,
            orientation = "vertical",
            {
                Button,
                text = "Play",
                onClick = function()
                    playMusic(outputFile)
                end
            },
            {
                Button,
                text = "Share",
                onClick = function()
                    this.click({{"<"..focus2.."@"..appName..">9000000$10", function()
                        dlg2.show()
                    end}})
                    service.shareFile(outputFile)
                    dlg2.hide()
                end
            },
            {
                Button,
                text = "Delete",
                onClick = function()
                    os.remove(outputFile)
                    service.postSpeak(1200, "Recording deleted")
                    dlg2.dismiss()
                end
            },
            {
                Button,
                text = "Open in File Manager",
                onClick = function()
                    this.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(folderPath), "resource/folder"))
                    dlg2.dismiss()
                end
            }
        }
        dlg2 = LuaDialog(this)
        dlg2.View = loadlayout(layout)
        dlg2.setCancelable(false)
        dlg2.setTitle("Result "..fileName)
        dlg2.setButton2("Close")
        dlg2.onDismiss = function()
            appName = nil
            focus2 = nil
            fileName = nil
            layout = nil
            dlg2 = nil
            this.playSoundGestureEnd()
        end
        dlg2.show()
    end)
    dlg.setButton3("Hide Dialog")
    dlg.show()
    this.postClick(500, {{"<Stop Recording"}})
else
    if fileName == nil then
        fileName = os.date("Recording_%Y_%m_%d_%H_%M_%S.mp3")
        this.playSoundGestureBegin()
    end
    outputFile = folderPath..fileName
    mr = MediaRecorder()
    mr.setAudioSource(MediaRecorder.AudioSource.MIC)
    mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
    mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
    mr.setAudioEncodingBitRate(service.getSharedData("defaultAudioBitrate"))
    mr.setAudioChannels(2)  -- Set recording to stereo
    mr.setAudioSamplingRate(48000)  -- Set sample rate to 48kHz
    mr.setOutputFile(outputFile)
    mr.prepare()
    mr.start()
end