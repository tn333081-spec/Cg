require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "android.util.Base64"
import "java.lang.String"

-- Layout Design
local layout = {
  LinearLayout,
  orientation="vertical",
  padding="16dp",
  {
    EditText,
    id="code_input",
    hint="Original Lua 5.3 Code yahan paste karein",
    layout_width="match_parent",
    layout_height="200dp",
    gravity="top",
  },
  {
    EditText,
    id="signature_input",
    hint="Custom Key/Format (e.g., AuthKey_2026)",
    layout_width="match_parent",
  },
  {
    Button,
    text="Multi-Layer Encrypt & Sign",
    id="btn_encrypt",
    layout_width="match_parent",
  },
  {
    EditText,
    id="code_output",
    hint="Encrypted & Secured Code yahan aayega",
    layout_width="match_parent",
    layout_height="250dp",
    gravity="top",
    textIsSelectable=true,
  }
}

-- IDs table taake service environment mein buttons aur textboxes ko access kiya ja sakay
local ids = {}
local view = loadlayout(layout, ids)

-- Jieshuo Lite mein 'activity' nahi hota, 'service' use hota hai Dialog banane ke liye
local dlg = AlertDialog.Builder(service)
dlg.setTitle("Secure Code Encryptor")
dlg.setView(view)
dlg.setPositiveButton("Band Karein", nil)
dlg.show()

-- Positional Checksum (Anti-Tamper Logic)
local function generateChecksum(text)
  local sum = 0
  for i = 1, #text do
    sum = sum + (string.byte(text, i) * i)
  end
  return tostring(sum)
end

local function encodeBase64(data)
  return tostring(Base64.encodeToString(String(data).getBytes(), Base64.NO_WRAP))
end

-- Encryption Engine
local function multiLayerEncrypt(code, customKey)
  -- Layer 1: Integrity Signature
  local checksum = generateChecksum(code)
  local signature = encodeBase64(customKey .. "_VALID_" .. checksum)

  -- Layer 2: Hexadecimal Conversion
  local hexStr = (code:gsub('.', function (c)
      return string.format('%02X', string.byte(c))
  end))

  -- Layer 3: String Reversal
  local reversedHex = string.reverse(hexStr)

  -- Layer 4: Noise Injection
  local noisyString = ""
  local noiseChars = {"!", "@", "#", "$", "%", "^", "&", "*", "G", "H", "I", "J", "K", "Z"}
  
  for i = 1, #reversedHex do
    noisyString = noisyString .. string.sub(reversedHex, i, i)
    if i % 3 == 0 then 
       noisyString = noisyString .. noiseChars[math.random(1, #noiseChars)]
    end
  end

  -- Layer 5: Final Base64 Wrap
  local finalPayload = encodeBase64(noisyString)

  local finalOutput = string.format("SIGNATURE=[[%s]]\nPAYLOAD=[[%s]]", signature, finalPayload)
  return finalOutput
end

-- Button Click Event (ids table ka use karke)
ids.btn_encrypt.onClick = function()
  local code = ids.code_input.Text
  local key = ids.signature_input.Text
  if code == "" or key == "" then
    print("Code aur Custom Key dono zaroori hain!")
    return
  end
  local result = multiLayerEncrypt(code, key)
  ids.code_output.Text = result
  print("Encryption aur Tamper-Proofing mukammal ho gayi!")
end
