local prefFile = "snake_ladder_stats"
require "import"
import "android.app.AlertDialog"
import "android.view.WindowManager"
import "android.widget.*"
import "android.view.*"
import "android.os.Handler"
import "java.lang.Runnable"
import "java.util.Random"
import "android.graphics.Color"
import "android.media.MediaPlayer"
import "android.media.AudioManager"
import "android.content.Context"
import "android.content.ClipboardManager"
import "android.content.ClipData"
import "com.androlua.Http"
import "android.speech.tts.TextToSpeech"
import "android.net.ConnectivityManager"
import "java.io.File"

_G.playerPos = 0
_G.compPos = 0
_G.isGameOver = false
_G.tempSnakes = 0
_G.tempLadders = 0
_G.gameHandler = Handler()
_G.random = Random()
_G.bgPlayer = _G.bgPlayer or nil
_G.isOnlineMode = false
_G.myTurn = false
_G.opponentName = ""
_G.isHeartbeatActive = false
_G.isLobbyActive = false
_G.matchId = ""
_G.lastProcessedMove = -1
_G.mainMenuDlg = nil
_G.lobbyDlg = nil
_G.matchDlg = nil
_G.challengeDlg = nil
_G.isTransitioning = false
_G.isInMatch = false
_G.hasLeftAnnounced = false
_G.ttsEngine = nil
_G.requestTimeoutActive = false
_G.matchTimerValue = 60
_G.chatHistory = {}
_G.lastProcessedChat = ""
_G.lastProcessedChatId = ""

local function saveStat(key, value)
  local pref = service.getSharedPreferences(prefFile, Context.MODE_PRIVATE)
  pref.edit().putString(key, tostring(value)).apply()
end

local function getStat(key, defVal)
  local pref = service.getSharedPreferences(prefFile, Context.MODE_PRIVATE)
  return pref.getString(key, defVal)
end

local customSoundPaths = {
  dice = getStat("custom_sound_dice", "default"),
  win = getStat("custom_sound_win", "default"),
  snake = getStat("custom_sound_snake", "default"),
  move = getStat("custom_sound_move", "default"),
  start = getStat("custom_sound_start", "default"),
  ladder = getStat("custom_sound_ladder", "default"),
  done = getStat("custom_sound_done", "default")
}

local FB_URL = "https://snake-and-ladders-2c6be-default-rtdb.firebaseio.com"
local FB_KEY = "RpT4JpkL6HZDvQbzxIWwU26oeW4ETbqLKhDcI4yt"

local function isNetworkAvailable()
  local cm = service.getSystemService(Context.CONNECTIVITY_SERVICE)
  local info = cm.getActiveNetworkInfo()
  return (info ~= nil and info.isConnected())
end

local function initTTS()
  local savedEngine = getStat("selected_tts_engine", nil)
  local savedRate = tonumber(getStat("speech_rate", "1.0"))
  if _G.ttsEngine then pcall(function() _G.ttsEngine.shutdown() end) end
  _G.ttsEngine = TextToSpeech(service, TextToSpeech.OnInitListener{
    onInit = function(status)
      if status == TextToSpeech.SUCCESS then
        _G.ttsEngine.setSpeechRate(savedRate)
      end
    end
  }, (savedEngine == "" and nil or savedEngine))
end

local function speakText(text)
  if _G.ttsEngine then
    _G.ttsEngine.speak(text, TextToSpeech.QUEUE_FLUSH, nil)
  else
    service.speak(text)
  end
end

initTTS()

local function closeAllDialogs()
  _G.chatHistory = {}
  _G.lastProcessedChat = ""
  _G.lastProcessedChatId = ""
  _G.isHeartbeatActive = false
  _G.isLobbyActive = false
  _G.isInMatch = false
  _G.isGameOver = true
  _G.opponentName = ""
  _G.matchId = ""
  _G.requestTimeoutActive = false
  _G.gameHandler.removeCallbacksAndMessages(nil)
  if _G.challengeDlg then pcall(function() _G.challengeDlg.dismiss() end) _G.challengeDlg = nil end
  if _G.mainMenuDlg then pcall(function() _G.mainMenuDlg.dismiss() end) _G.mainMenuDlg = nil end
  if _G.lobbyDlg then pcall(function() _G.lobbyDlg.dismiss() end) _G.lobbyDlg = nil end
  if _G.matchDlg then pcall(function() _G.matchDlg.dismiss() end) _G.matchDlg = nil end
  if _G.notifDlg then pcall(function() _G.notifDlg.dismiss() end) _G.notifDlg = nil end
  if _G.chatHistDlg then pcall(function() _G.chatHistDlg.dismiss() end) _G.chatHistDlg = nil end
  if _G.mainChatDlg then pcall(function() _G.mainChatDlg.dismiss() end) _G.mainChatDlg = nil end
  if _G.phraseDlg then pcall(function() _G.phraseDlg.dismiss() end) _G.phraseDlg = nil end
  if _G.typeChatDlg then pcall(function() _G.typeChatDlg.dismiss() end) _G.typeChatDlg = nil end
  if _G.newNotifDlg then pcall(function() _G.newNotifDlg.dismiss() end) _G.newNotifDlg = nil end
  if _G.soundMgrDlg then pcall(function() _G.soundMgrDlg.dismiss() end) _G.soundMgrDlg = nil end
  if _G.soundOptDlg then pcall(function() _G.soundOptDlg.dismiss() end) _G.soundOptDlg = nil end
  if _G.fileSelectDlg then pcall(function() _G.fileSelectDlg.dismiss() end) _G.fileSelectDlg = nil end
end

local function addStat(key, amount)
  local current = tonumber(getStat(key, "0"))
  saveStat(key, current + (amount or 1))
end

_G.myId = getStat("player_name", "")

local downloadFolder = "/sdcard/snake_and_ladders_sounds/"
local zipFile = "/sdcard/snake_sounds.zip"
local downloadUrl = "https://drive.google.com/uc?export=download&id=1DL9LvJPEO26NZ0-eHCNOBRryq4kbfoYr"

local soundDice = downloadFolder .. "dice_roll.mp3"
local soundWin = downloadFolder .. "100.mp3"
local soundSnake = downloadFolder .. "snake.mp3"
local soundMove = downloadFolder .. "move sound.mp3"
local soundStart = downloadFolder .. "Start.mp3"
local soundLadder = downloadFolder .. "ladder.mp3"
local soundBG = downloadFolder .. "background.mp3"
local soundDone = downloadFolder .. "Done.mp3"

local function getGameVol() return tonumber(getStat("game_vol_level", "80")) / 100 end
local function getBGVol() return tonumber(getStat("bg_vol_level", "5")) / 100 end
local function isGameSndEnabled() return getStat("game_snd_enabled", "true") == "true" end
local function isBGSndEnabled() return getStat("bg_snd_enabled", "true") == "true" end

local function playSnd(defaultPath)
  if not isGameSndEnabled() then return end
  
  local soundKey = ""
  if defaultPath == soundDice then soundKey = "dice"
  elseif defaultPath == soundWin then soundKey = "win"
  elseif defaultPath == soundSnake then soundKey = "snake"
  elseif defaultPath == soundMove then soundKey = "move"
  elseif defaultPath == soundStart then soundKey = "start"
  elseif defaultPath == soundLadder then soundKey = "ladder"
  elseif defaultPath == soundDone then soundKey = "done"
  end

  local finalPath = defaultPath
  local custom = customSoundPaths[soundKey]
  
  if custom and custom ~= "default" then
    if File(custom).exists() then
      finalPath = custom
    end
  end

  pcall(function()
    local mp = MediaPlayer()
    mp.setAudioStreamType(AudioManager.STREAM_MUSIC)
    mp.setDataSource(finalPath)
    local v = getGameVol()
    mp.setVolume(v, v)
    mp.prepare()
    mp.start()
    mp.setOnCompletionListener(function(p) p.release() end)
  end)
end

local function stopBG()
  if _G.bgPlayer then
    pcall(function()
      if _G.bgPlayer.isPlaying() then _G.bgPlayer.stop() end
      _G.bgPlayer.release()
    end)
    _G.bgPlayer = nil
  end
end

local function startBG()
  if not isBGSndEnabled() then return end
  if _G.bgPlayer and _G.bgPlayer.isPlaying() then 
    local v = getBGVol()
    pcall(function() _G.bgPlayer.setVolume(v, v) end)
    return 
  end
  local finalPath = soundBG
  local custom = getStat("custom_sound_bg", "default")
  if custom ~= "default" and File(custom).exists() then
    finalPath = custom
  end
  pcall(function()
    _G.bgPlayer = MediaPlayer()
    _G.bgPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC)
    _G.bgPlayer.setDataSource(finalPath)
    _G.bgPlayer.setLooping(true)
    local v = getBGVol()
    _G.bgPlayer.setVolume(v, v)
    _G.bgPlayer.prepare()
    _G.bgPlayer.start()
  end)
end

local function playMoveSteps(steps)
  local count = 0
  local function playNext()
    if count < steps and not _G.isGameOver then
      playSnd(soundMove)
      count = count + 1
      _G.gameHandler.postDelayed(Runnable{run=playNext}, 200)
    end
  end
  playNext()
end

local snakes = {[17]=7, [54]=34, [62]=19, [64]=60, [87]=24, [93]=73, [95]=75, [99]=78}
local ladders = {[4]=14, [9]=31, [20]=38, [28]=84, [40]=59, [51]=67, [63]=81, [71]=91}

function checkBoard(pos, isPlayer)
  if snakes[pos] then
    if isPlayer then _G.tempSnakes = _G.tempSnakes + 1 end
    return snakes[pos], "Landed on snake at " .. pos .. "! Down to "
  elseif ladders[pos] then
    if isPlayer then _G.tempLadders = _G.tempLadders + 1 end
    return ladders[pos], "Landed on ladder at " .. pos .. "! Up to "
  end
  return pos, nil
end

function sendHeartbeat()
  if not _G.isHeartbeatActive or _G.myId == "" then return end
  local status = _G.isInMatch and "playing" or "online"
  local url = FB_URL .. "/lobby/" .. _G.myId .. ".json?auth=" .. FB_KEY
  local data = string.format('{"time":%d,"status":"%s"}', os.time(), status)
  Http.put(url, data, function(c, b) end)
  _G.gameHandler.postDelayed(Runnable{run=sendHeartbeat}, 10000)
end

function listenForChallenges()
  if not _G.isHeartbeatActive or _G.isLobbyActive then return end
  local url = FB_URL .. "/challenges/" .. _G.myId .. ".json?auth=" .. FB_KEY
  Http.get(url, function(code, body)
    if code == 200 and body ~= "null" then
      local challenger = body:match('"(.-)"')
      if challenger then
        Http.delete(url, function() end)
        showChallengeDialog(challenger)
      end
    end
  end)
  _G.gameHandler.postDelayed(Runnable{run=listenForChallenges}, 3000)
end

function showChallengeDialog(from)
  if _G.challengeDlg then _G.challengeDlg.dismiss() end
  local d = AlertDialog.Builder(service)
  local isRematch = (from == _G.opponentName and _G.opponentName ~= "")
  d.setTitle(isRematch and "Rematch Request!" or "New Challenge!")
  local layout = LinearLayout(service)
  layout.setOrientation(LinearLayout.VERTICAL)
  layout.setPadding(40, 40, 40, 40)
  local tvMsg = TextView(service)
  tvMsg.setText(from .. " wants to play with you.")
  tvMsg.setTextSize(16)
  tvMsg.setFocusable(true)
  layout.addView(tvMsg)
  local tvTimer = TextView(service)
  local timeLeft = 10
  tvTimer.setText("\nTime remaining: " .. timeLeft .. "s")
  tvTimer.setTextSize(16)
  tvTimer.setFocusable(true)
  layout.addView(tvTimer)
  d.setView(layout)
  d.setPositiveButton("Accept", function()
    _G.challengeDlg.dismiss()
    _G.challengeDlg = nil
    _G.matchId = from .. "_" .. _G.myId
    _G.opponentName = from
    _G.isOnlineMode = true
    _G.isGameOver = false
    _G.myTurn = false
    _G.lastProcessedMove = -1
    local url = FB_URL .. "/matches/" .. _G.matchId .. ".json?auth=" .. FB_KEY
    Http.put(url, '{"status":"accepted","turn":"'..from..'","pos_'..from..'":0,"pos_'.._G.myId..'":0,"move_id":0,"last_move_time":'..os.time()..'}', function() 
      startMatch()
    end)
  end)
  d.setNegativeButton("Reject", function()
    _G.challengeDlg.dismiss()
    _G.challengeDlg = nil
    Http.put(FB_URL.."/challenges/"..from.."_status.json?auth="..FB_KEY, '"rejected"', function() end)
    _G.requestTimeoutActive = false
  end)
  _G.challengeDlg = d.create()
  _G.challengeDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
  _G.challengeDlg.show()
  local function updateChallengeTimer()
    if _G.challengeDlg and _G.challengeDlg.isShowing() then
      timeLeft = timeLeft - 1
      if timeLeft <= 0 then
        _G.challengeDlg.dismiss()
        _G.challengeDlg = nil
        Http.delete(FB_URL .. "/challenges/" .. _G.myId .. ".json?auth=" .. FB_KEY, function() end)
        _G.requestTimeoutActive = false
      else
        tvTimer.setText("\nTime remaining: " .. timeLeft .. "s")
        _G.gameHandler.postDelayed(Runnable{run=updateChallengeTimer}, 1000)
      end
    end
  end
  updateChallengeTimer()
end

function showSettings()
  local context = service
  local layout = LinearLayout(context)
  layout.setOrientation(LinearLayout.VERTICAL)
  layout.setPadding(40, 40, 40, 40)
  local scroll = ScrollView(context)
  local innerLayout = LinearLayout(context)
  innerLayout.setOrientation(LinearLayout.VERTICAL)
  local cbGame = CheckBox(context)
  cbGame.setText("Enable Game Sounds (Dice, Move, etc.)")
  cbGame.setChecked(isGameSndEnabled())
  innerLayout.addView(cbGame)
  innerLayout.addView(TextView(context).setText("Game Sounds Volume:"))
  local seekGame = SeekBar(context)
  seekGame.setMax(100)
  seekGame.setProgress(tonumber(getStat("game_vol_level", "80")))
  innerLayout.addView(seekGame)
  innerLayout.addView(TextView(context).setText("\n"))
  local cbBG = CheckBox(context)
  cbBG.setText("Enable Background Music")
  cbBG.setChecked(isBGSndEnabled())
  innerLayout.addView(cbBG)
  innerLayout.addView(TextView(context).setText("Background Music Volume:"))
  local seekBG = SeekBar(context)
  seekBG.setMax(100)
  seekBG.setProgress(tonumber(getStat("bg_vol_level", "5")))
  innerLayout.addView(seekBG)
  innerLayout.addView(TextView(context).setText("\nSelect TTS engine for game speech:"))
  local spinner = Spinner(context)
  local engines = {}
  local engineNames = {}
  table.insert(engineNames, "System Default")
  table.insert(engines, "default")
  if _G.ttsEngine then
    local availableEngines = _G.ttsEngine.getEngines()
    for i=0, availableEngines.size()-1 do
      local eng = availableEngines.get(i)
      table.insert(engineNames, eng.label)
      table.insert(engines, eng.name)
    end
  end
  local adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, engineNames)
  adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
  spinner.setAdapter(adapter)
  local currentEng = getStat("selected_tts_engine", "default")
  for i,v in ipairs(engines) do
    if v == currentEng then spinner.setSelection(i-1) break end
  end
  innerLayout.addView(spinner)
  local btnTest = Button(context)
  btnTest.setText("TEST SPEECH")
  innerLayout.addView(btnTest)
  btnTest.setOnClickListener(function()
    speakText("This is a test of the selected text to speech engine.")
  end)
  innerLayout.addView(TextView(context).setText("\nSpeech Rate:"))
  local seekRate = SeekBar(context)
  seekRate.setMax(20)
  local currentRate = tonumber(getStat("speech_rate", "1.0"))
  seekRate.setProgress(math.floor(currentRate * 10))
  innerLayout.addView(seekRate)
  local customSoundPaths = {
    dice = getStat("custom_sound_dice", "default"),
    win = getStat("custom_sound_win", "default"),
    snake = getStat("custom_sound_snake", "default"),
    move = getStat("custom_sound_move", "default"),
    start = getStat("custom_sound_start", "default"),
    ladder = getStat("custom_sound_ladder", "default"),
    done = getStat("custom_sound_done", "default"),
    bg = getStat("custom_sound_bg", "default")
  }

  local btnSoundMgr = Button(context)
  
  local function pickSoundFile(key)
    local function listFiles(currentPath)
      local f = File(currentPath)
      local fileList = f.listFiles()
      local items, paths = {}, {}
      table.insert(items, "CANCEL (Back to Sound Manager)")
      table.insert(paths, "CANCEL_ACTION")
      if currentPath ~= "/storage/emulated/0" then
        table.insert(items, ".. (Back)")
        table.insert(paths, f.getParent())
      end
      if fileList then
        for i = 0, #fileList - 1 do
          local file = fileList[i]
          local name = file.getName()
          if file.isDirectory() then
            table.insert(items, "[Folder] " .. name)
            table.insert(paths, file.getAbsolutePath())
          elseif name:lower():match("%.mp3$") or name:lower():match("%.wav$") then
            table.insert(items, "?? " .. name)
            table.insert(paths, file.getAbsolutePath())
          end
        end
      end
      _G.fileSelectDlg = AlertDialog.Builder(service).setTitle("Select Sound").setItems(items, function(l, p)
        local selectedPath = paths[p + 1]
        if selectedPath == "CANCEL_ACTION" then
          btnSoundMgr.performClick()
          return
        end
        if File(selectedPath).isDirectory() then
          listFiles(selectedPath)
        else
          customSoundPaths[key] = selectedPath
          saveStat("custom_sound_" .. key, selectedPath)
          speakText("Sound updated")
          if key == "bg" then stopBG() startBG() end
          btnSoundMgr.performClick()
        end
      end).create()
      _G.fileSelectDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
      _G.fileSelectDlg.show()
    end
    listFiles("/storage/emulated/0")
  end

  btnSoundMgr.setText("MANAGE CUSTOM SOUNDS")
  innerLayout.addView(btnSoundMgr)
  btnSoundMgr.setOnClickListener(function()
    local keys = {"dice", "win", "snake", "move", "start", "ladder", "done", "bg"}
    local labels = {"Dice Roll", "Winning", "Snake Bite", "Move Step", "Game Start", "Ladder Climb", "Action Done", "Background Music"}
    local items = {}
    for i, k in ipairs(keys) do
      local status = " (Default)"
      if customSoundPaths[k] ~= "default" then
        status = " (" .. File(customSoundPaths[k]).getName() .. ")"
      end
      table.insert(items, labels[i] .. status)
      if k ~= "bg" then
        table.insert(items, "PLAY: " .. labels[i])
      end
    end
    _G.soundMgrDlg = AlertDialog.Builder(service).setTitle("Sound Manager").setItems(items, function(l, p)
      local selectedText = items[p + 1]
      if selectedText:find("PLAY: ") then
        local labelToPlay = selectedText:gsub("PLAY: ", "")
        local keyToPlay = ""
        for idx, lbl in ipairs(labels) do
          if lbl == labelToPlay then keyToPlay = keys[idx] break end
        end
        if keyToPlay ~= "" then
          local path = customSoundPaths[keyToPlay]
          if path == "default" or not File(path).exists() then
            local defaultPaths = {
              dice = soundDice,
              win = soundWin,
              snake = soundSnake,
              move = soundMove,
              start = soundStart,
              ladder = soundLadder,
              done = soundDone,
              bg = soundBG
            }
            path = defaultPaths[keyToPlay]
          end
          if path then
            pcall(function()
              local mp = MediaPlayer()
              mp.setDataSource(path)
              local v = getGameVol()
              mp.setVolume(v, v)
              mp.prepare()
              mp.start()
              mp.setOnCompletionListener(function(p) p.release() end)
            end)
          end
        end
        btnSoundMgr.performClick()
        return
      end
      local keyIndex = 0
      local currentCount = 0
      for i, k in ipairs(keys) do
        currentCount = currentCount + 1
        if currentCount == p + 1 then keyIndex = i break end
        if k ~= "bg" then currentCount = currentCount + 1 end
        if currentCount == p + 1 then keyIndex = i break end
      end
      local key = keys[keyIndex]
      if customSoundPaths[key] == "default" then
        pickSoundFile(key)
      else
        local options = {"Change Custom Sound", "Reset to Default"}
        local optDlg = AlertDialog.Builder(service).setTitle("Options").setItems(options, function(l2, p2)
          if p2 == 0 then pickSoundFile(key)
          else
            customSoundPaths[key] = "default"
            saveStat("custom_sound_" .. key, "default")
            if key == "bg" then stopBG() startBG() end
            speakText("Reset to default")
            btnSoundMgr.performClick()
          end
        end).create()
        optDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
        optDlg.show()
      end
    end).setNegativeButton("Close", nil).create()
    _G.soundMgrDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
    _G.soundMgrDlg.show()
  end)

  local btnSave = Button(context)
  btnSave.setText("SAVE SETTINGS")
  innerLayout.addView(btnSave)
  scroll.addView(innerLayout)
  layout.addView(scroll)
  local settDlg = AlertDialog.Builder(context).setTitle("Settings").setView(layout).setNegativeButton("Close", nil).create()
  settDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
  btnSave.setOnClickListener(function()
    playSnd(soundDone)
    saveStat("game_snd_enabled", tostring(cbGame.isChecked()))
    saveStat("game_vol_level", tostring(seekGame.getProgress()))
    saveStat("bg_snd_enabled", tostring(cbBG.isChecked()))
    saveStat("bg_vol_level", tostring(seekBG.getProgress()))
    local rateVal = seekRate.getProgress() / 10
    if rateVal < 0.5 then rateVal = 0.5 end
    saveStat("speech_rate", tostring(rateVal))
    local selectedEng = engines[spinner.getSelectedItemPosition()+1]
    saveStat("selected_tts_engine", (selectedEng == "default" and "" or selectedEng))
    initTTS()
    stopBG()
    if cbBG.isChecked() then startBG() end
    speakText("Settings saved successfully")
    Toast.makeText(service, "Settings Saved", Toast.LENGTH_SHORT).show()
  end)
  settDlg.show()
end

function showProfile()
  local context = service
  local layout = LinearLayout(context)
  layout.setOrientation(LinearLayout.VERTICAL)
  layout.setPadding(40, 40, 40, 40)
  local tvName = TextView(context)
  tvName.setText("Player Name: " .. getStat("player_name", "Unknown"))
  tvName.setTextSize(18)
  tvName.setFocusable(true)
  layout.addView(tvName)
  local statsHeader = TextView(context)
  statsHeader.setText("\n--- Your Statistics ---")
  statsHeader.setTextColor(Color.parseColor("#2196F3"))
  statsHeader.setFocusable(true)
  layout.addView(statsHeader)
  local statsList = {
    "Matches Played: " .. getStat("total_matches", "0"),
    "Wins: " .. getStat("wins", "0"),
    "Losses: " .. getStat("losses", "0"),
    "Snakes Bitten: " .. getStat("snakes_bitten", "0"),
    "Ladders Climbed: " .. getStat("ladders_climbed", "0")
  }
  for _, s in ipairs(statsList) do
    local tv = TextView(context)
    tv.setText(s)
    tv.setPadding(0, 10, 0, 10)
    tv.setFocusable(true)
    layout.addView(tv)
  end
  local btnCopy = Button(context)
  btnCopy.setText("COPY STATS")
  layout.addView(btnCopy)
  btnCopy.setOnClickListener(function()
    local fullStats = table.concat(statsList, "\n")
    local cm = context.getSystemService(Context.CLIPBOARD_SERVICE)
    local cd = ClipData.newPlainText("Stats", fullStats)
    cm.setPrimaryClip(cd)
    speakText("Statistics copied to clipboard")
  end)
  local dlg = AlertDialog.Builder(context).setTitle("Profile & Stats").setView(layout).setNegativeButton("Close", nil).create()
  dlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
  dlg.show()
end

function showNotifications()
  Http.get(FB_URL .. "/update_info.json?auth=" .. FB_KEY, function(code, body)
    local context = service
    local scroll = ScrollView(context)
    local layout = LinearLayout(context)
    layout.setOrientation(LinearLayout.VERTICAL)
    layout.setPadding(40, 40, 40, 40)
    scroll.addView(layout)
    
    local title = TextView(context)
    title.setText("Notifications")
    title.setTextSize(20)
    title.setPadding(0, 0, 0, 20)
    title.setFocusable(true)
    layout.addView(title)

    if code == 200 and body and body ~= "null" then
      for id, content in body:gmatch('"([^"]+)":%{(.-)%}') do
        local msg = content:match('"code":"(.-)"') or "No text"
        local itemLayout = LinearLayout(context)
        itemLayout.setOrientation(LinearLayout.VERTICAL)
        itemLayout.setPadding(0, 10, 0, 10)
        
        local contentTxt = TextView(context)
        contentTxt.setText("• " .. msg:gsub("\\n", "\n"):gsub("\\\\", "\\"))
        contentTxt.setFocusable(true)
        itemLayout.addView(contentTxt)
        layout.addView(itemLayout)
      end
    else
      local empty = TextView(context)
      empty.setText("\nNo new notifications.")
      empty.setFocusable(true)
      layout.addView(empty)
    end

    _G.notifDlg = AlertDialog.Builder(context).setView(scroll).setNegativeButton("Close", nil).create()
    _G.notifDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
    _G.notifDlg.show()
  end)
end

function showInfo()
  local context = service
  local layout = LinearLayout(context)
  layout.setOrientation(LinearLayout.VERTICAL)
  local scroll = ScrollView(context)
  local inner = LinearLayout(context)
  inner.setOrientation(LinearLayout.VERTICAL)
  inner.setPadding(40, 40, 40, 40)
  local function addText(txt, isBold)
    local tv = TextView(context)
    tv.setText(tostring(txt))
    tv.setFocusable(true)
    tv.setPadding(0, 10, 0, 10)
    if isBold then tv.setTextColor(Color.parseColor("#2196F3")) end
    inner.addView(tv)
  end
  addText("Developer: Moosa Zaib", true)
  addText("About the Game:", true)
  addText("Snake and Ladders is a classic board game. The goal is to reach the 100th square first. You move based on your dice rolls.")
  addText("Snakes and Ladders:", true)
  addText("If you land at the base of a ladder, you immediately climb to the top. If you land on the head of a snake, you slide down to its tail.")
  addText("Online Play:", true)
  addText("You can challenge other players in the lobby. If a player does not move for a certain time, they will time out and you will win.")
  addText("Ladders Positions:", true)
  local lk = {} for k in pairs(ladders) do table.insert(lk, k) end table.sort(lk)
  for _, k in ipairs(lk) do addText("From " .. k .. " to " .. ladders[k], false) end
  addText("Snakes Positions:", true)
  local sk = {} for k in pairs(snakes) do table.insert(sk, k) end table.sort(sk)
  for _, k in ipairs(sk) do addText("From " .. k .. " to " .. snakes[k], false) end
  local btnContact = Button(context)
  btnContact.setText("CONTACT US")
  inner.addView(btnContact)
  btnContact.setOnClickListener(function()
    import "android.content.Intent"
    import "android.net.Uri"
    local url = "https://wa.me/923123608972"
    local intent = Intent(Intent.ACTION_VIEW)
    intent.setData(Uri.parse(url))
    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    service.startActivity(intent)
    stopBG()
    if _G.infoDlg then _G.infoDlg.dismiss() end
    closeAllDialogs()
    service.stopSelf()
  end)
  scroll.addView(inner)
  layout.addView(scroll)
  _G.infoDlg = AlertDialog.Builder(context).setTitle("Game Information").setView(layout).setPositiveButton("Close", nil).create()
  _G.infoDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
  _G.infoDlg.show()
end




function showChatHistory()
  local context = service
  local layout = LinearLayout(context)
  layout.setOrientation(LinearLayout.VERTICAL)
  layout.setPadding(30,30,30,30)
  local scroll = ScrollView(context)
  local listContainer = LinearLayout(context)
  listContainer.setOrientation(LinearLayout.VERTICAL)
  
  if #_G.chatHistory == 0 then
    local tv = TextView(context)
    tv.setText("No messages yet.")
    tv.setFocusable(true)
    listContainer.addView(tv)
  else
    for i = #_G.chatHistory, 1, -1 do
      local fullTxt = tostring(_G.chatHistory[i])
      local cleanMsg = fullTxt:gsub(" ##ID:.*", "")
      local tv = TextView(context)
      tv.setText(cleanMsg)
      tv.setPadding(10, 20, 10, 20)
      tv.setTextSize(16)
      tv.setFocusable(true)
      -- بارڈر کی طرح نیچے لائن
      local line = View(context)
      line.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 2))
      line.setBackgroundColor(Color.LTGRAY)
      listContainer.addView(tv)
      listContainer.addView(line)
    end
  end
  scroll.addView(listContainer)
  layout.addView(scroll)
  _G.chatHistDlg = AlertDialog.Builder(context).setTitle("Chat History").setView(layout).setNegativeButton("Close", nil).create()
  _G.chatHistDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
  _G.chatHistDlg.show()
end

function sendChatMessage(m)
  if not _G.isOnlineMode or _G.matchId == "" then return end
  local url = FB_URL .. "/matches/" .. _G.matchId .. "/chats.json?auth=" .. FB_KEY
  local safeMsg = m:gsub('\\', '\\\\'):gsub('"', '\\"'):gsub('\n', ' ')
  local chatId = "ID" .. os.time() .. _G.random.nextInt(1000)
  local data = string.format('{"sender":"%s","msg":"%s","time":%d,"chatId":"%s"}', _G.myId, safeMsg, os.time(), chatId)
  Http.post(url, data, function(c, b)
    if c == 200 then
      table.insert(_G.chatHistory, _G.myId .. ": " .. m .. " ##ID:" .. chatId)
      speakText("Sent")
    end
  end)
end

function showChatMenu()
  local context = service
  local phrases = {"Are you sleeping? Your turn!", "Wake up, play your move!", "Oops, snake bite!", "Going down! Haha.", "Lucky you! Nice ladder!", "Wow, great climb!", "Good game!", "I am winning!", "Hurry up!", "So slow!"}
  
  local layout = LinearLayout(context)
  layout.setOrientation(LinearLayout.VERTICAL)
  layout.setPadding(50, 40, 50, 40)

  local btnPhrases = Button(context)
  btnPhrases.setText("SELECT READY-MADE PHRASES")
  layout.addView(btnPhrases)

  local btnType = Button(context)
  btnType.setText("TYPE NEW MESSAGE")
  layout.addView(btnType)

  local dm = AlertDialog.Builder(context)
  dm.setTitle("Chat Options")
  dm.setView(layout)
  dm.setNegativeButton("CANCEL", nil)
  
  _G.mainChatDlg = dm.create()
  _G.mainChatDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)

  btnPhrases.setOnClickListener(function()
    mainChatDlg.dismiss()
    local phraseLayout = LinearLayout(context)
    phraseLayout.setOrientation(LinearLayout.VERTICAL)
    local scroll = ScrollView(context)
    local innerPhrase = LinearLayout(context)
    innerPhrase.setOrientation(LinearLayout.VERTICAL)
    innerPhrase.setPadding(40, 40, 40, 40)
    
    for i, phrase in ipairs(phrases) do
      local b = Button(context)
      b.setText(phrase)
      b.setOnClickListener(function()
        sendChatMessage(phrase)
        if _G.phraseDlg then pcall(function() _G.phraseDlg.dismiss() end) _G.phraseDlg = nil end
      end)
      innerPhrase.addView(b)
    end
    
    scroll.addView(innerPhrase)
    phraseLayout.addView(scroll)
    
    _G.phraseDlg = AlertDialog.Builder(context).setTitle("Select Phrase").setView(phraseLayout).setNegativeButton("BACK", nil).create()
    _G.phraseDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
    _G.phraseDlg.show()
  end)

  btnType.setOnClickListener(function()
    mainChatDlg.dismiss()
    local typeLayout = LinearLayout(context)
    typeLayout.setOrientation(LinearLayout.VERTICAL)
    typeLayout.setPadding(50, 40, 50, 40)
    
    local ed = EditText(context)
    ed.setHint("Write message here...")
    ed.setFocusable(true)
    typeLayout.addView(ed)
    
    local dType = AlertDialog.Builder(context).setTitle("Type Message").setView(typeLayout)
    dType.setPositiveButton("Send", function()
      local m = tostring(ed.getText())
      if m ~= "" then sendChatMessage(m) end
    end)
    dType.setNegativeButton("Cancel", nil)
    
    _G.typeChatDlg = dType.create()
    _G.typeChatDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
    _G.typeChatDlg.show()
  end)

  mainChatDlg.show()
end

function startMatch()
  if _G.mainMenuDlg then pcall(function() _G.mainMenuDlg.dismiss() end) _G.mainMenuDlg = nil end
  if _G.lobbyDlg then pcall(function() _G.lobbyDlg.dismiss() end) _G.lobbyDlg = nil end
  if _G.matchDlg then pcall(function() _G.matchDlg.dismiss() end) _G.matchDlg = nil end
  _G.isInMatch = true
  _G.isHeartbeatActive = true
  _G.isLobbyActive = false
  _G.lastProcessedMove = 0
  _G.hasLeftAnnounced = false
  _G.matchTimerValue = 60
  stopBG()
  local context = service
  playSnd(soundStart)
  local layout = LinearLayout(context)
  layout.setOrientation(LinearLayout.VERTICAL)
  layout.setPadding(50, 40, 50, 40)
  _G.playerPos = 0
  _G.compPos = 0
  _G.isGameOver = false
  _G.tempSnakes = 0
  _G.tempLadders = 0
  local pName = getStat("player_name", "Player")
  local oppName = _G.isOnlineMode and _G.opponentName or "Computer"

  if _G.isOnlineMode then
    local btnSend = Button(context)
    btnSend.setText("SEND MESSAGE")
    layout.addView(btnSend)
    btnSend.setOnClickListener(function()
      showChatMenu()
    end)

    local btnHistory = Button(context)
    btnHistory.setText("CHAT HISTORY")
    layout.addView(btnHistory)
    btnHistory.setOnClickListener(function()
      showChatHistory()
    end)
  end

  local statusTxt = TextView(context)
  statusTxt.setPadding(0, 10, 0, 10)
  statusTxt.setGravity(Gravity.CENTER)
  layout.addView(statusTxt)

  local timerTxt = TextView(context)
  timerTxt.setPadding(0, 10, 0, 10)
  timerTxt.setGravity(Gravity.CENTER)
  timerTxt.setFocusable(true)
  if _G.isOnlineMode then
    timerTxt.setText("Time: 60s")
    layout.addView(timerTxt)
  end

  local pScore = TextView(context)
  pScore.setText(pName .. ": 0 | " .. oppName .. ": 0")
  pScore.setGravity(Gravity.CENTER)
  pScore.setFocusable(true)
  layout.addView(pScore)

  local btnRoll = Button(context)
  btnRoll.setText("ROLL DICE")
  layout.addView(btnRoll)

  local btnAction = Button(context)
  btnAction.setText("QUIT GAME")
  layout.addView(btnAction)
  _G.matchDlg = AlertDialog.Builder(context).setView(layout).setCancelable(false).create()
  _G.matchDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
  _G.matchDlg.setOnKeyListener({onKey=function(d,k,e)
    if k == KeyEvent.KEYCODE_BACK then return true end
    return false
  end})
  if _G.isOnlineMode then
    local creator = _G.matchId:match("(.-)_")
    local firstTurn = (creator == _G.myId)
    _G.myTurn = firstTurn
    btnRoll.setEnabled(firstTurn)
    statusTxt.setText(firstTurn and "Your Turn!" or "Waiting for " .. oppName .. "...")
    if firstTurn then speakText("Your Turn! Roll Dice") end
  else
    _G.myTurn = true
    btnRoll.setEnabled(true)
    statusTxt.setText("Your Turn!")
  end
  local function finalizeStats(won)
    addStat("total_matches")
    addStat("snakes_bitten", _G.tempSnakes)
    addStat("ladders_climbed", _G.tempLadders)
    if won then addStat("wins") else addStat("losses") end
    if _G.isOnlineMode then
      Http.delete(FB_URL .. "/matches/" .. _G.matchId .. ".json?auth=" .. FB_KEY, function() end)
      Http.delete(FB_URL .. "/matches/" .. _G.matchId .. "/chats.json?auth=" .. FB_KEY, function() end)
    end
    _G.chatHistory = {}
    _G.lastProcessedChat = ""
  end
  local function updateDisplay() pScore.setText(pName .. ": " .. _G.playerPos .. " | " .. oppName .. ": " .. _G.compPos) end
  
  local function startLiveTimer()
    if _G.isGameOver or not _G.isInMatch or not _G.isOnlineMode then return end
    _G.matchTimerValue = _G.matchTimerValue - 1
    if _G.matchTimerValue <= 0 then
        _G.matchTimerValue = 0
        timerTxt.setText("Time: 0s")
        _G.isGameOver = true
        if _G.myTurn then
            speakText("Time out! You lost the game.")
            statusTxt.setText("You Timed Out!")
            finalizeStats(false)
        else
            speakText(oppName .. " timed out. You won!")
            statusTxt.setText(oppName .. " Timed Out!")
            playSnd(soundWin)
            finalizeStats(true)
        end
        _G.gameHandler.postDelayed(Runnable{run=function() showMainMenu() end}, 3000)
        return
    end
    timerTxt.setText("Time: " .. _G.matchTimerValue .. "s")
    _G.gameHandler.postDelayed(Runnable{run=startLiveTimer}, 1000)
  end
  if _G.isOnlineMode then startLiveTimer() end

  local function syncOnline()
    if not _G.isOnlineMode or not _G.isInMatch then return end
    if not isNetworkAvailable() then
       _G.isGameOver = true
       speakText("Lost Connection.")
       finalizeStats(false)
       _G.gameHandler.postDelayed(Runnable{run=function() showMainMenu() end}, 2000)
       return
    end
    local url = FB_URL .. "/matches/" .. _G.matchId .. ".json?auth=" .. FB_KEY
    Http.get(url, function(code, body)
      if not _G.isInMatch then return end
      local chatUrl = FB_URL .. "/matches/" .. _G.matchId .. "/chats.json?auth=" .. FB_KEY
      Http.get(chatUrl, function(cc, cb)
        if cc == 200 and cb ~= "null" then
          for firebaseId, content in cb:gmatch('"([^"]+)":%s*{(.-)}') do
            local sender = content:match('"sender":"(.-)"')
            local msg = content:match('"msg":"(.-)"')
            local uniqueId = content:match('"chatId":"(.-)"') or firebaseId
            
            local isAlreadyRead = false
            for i=1, #_G.chatHistory do
              if _G.chatHistory[i]:find("##ID:" .. uniqueId) then
                isAlreadyRead = true
                break
              end
            end
            
            if not isAlreadyRead then
              table.insert(_G.chatHistory, sender .. ": " .. msg .. " ##ID:" .. uniqueId)
              if sender ~= _G.myId then
                speakText(sender .. " says " .. msg)
              end
            end
          end
        end
      end)
      if code == 200 and body ~= "null" then
        local turn = body:match('"turn":"(.-)"')
        local quitter = body:match('"quit":"(.-)"')
        if quitter and quitter ~= "" then
            if quitter ~= _G.myId and not _G.isGameOver then
                _G.isGameOver = true
                _G.myTurn = false
                speakText(oppName .. " has quit the game. You won!")
                finalizeStats(true)
                _G.gameHandler.postDelayed(Runnable{run=function() showMainMenu() end}, 3000)
            end
            return
        end
        local leftInfo = body:match('"left":"(.-)"')
        if leftInfo and leftInfo ~= _G.myId and not _G.hasLeftAnnounced then
           _G.hasLeftAnnounced = true
           speakText(oppName .. " has left the room.")
        end
        if _G.isGameOver then return end
        local moveId = tonumber(body:match('"move_id":(%d+)')) or 0
        local lastRoll = tonumber(body:match('"last_roll":(%d+)'))
        if moveId > _G.lastProcessedMove then
          _G.lastProcessedMove = moveId
          _G.matchTimerValue = 60
          if turn == _G.myId and lastRoll then
            playSnd(soundDice)
            _G.gameHandler.postDelayed(Runnable{run=function()
              if _G.isGameOver then return end
              local target = _G.compPos + lastRoll
              if target > 100 then
                speakText(oppName .. " rolled " .. lastRoll .. ". Move skipped.")
              elseif target == 100 then
                _G.compPos = 100
                _G.isGameOver = true
                _G.myTurn = false
                updateDisplay()
                finalizeStats(false)
                speakText(oppName .. " rolled " .. lastRoll .. " and reached 100.")
                playMoveSteps(lastRoll)
                _G.gameHandler.postDelayed(Runnable{run=function() playSnd(soundWin) speakText(oppName .. " Won!") statusTxt.setText(oppName .. " Won!") btnRoll.setText("BACK TO MENU") btnRoll.setEnabled(true) btnAction.setText("REMATCH") end}, 1000)
              else
                local newPos, msg = checkBoard(target, false)
                _G.compPos = newPos
                updateDisplay()
                local fMsg = oppName .. " rolled " .. lastRoll .. ". Position: " .. _G.compPos
                if msg then fMsg = oppName .. " rolled " .. lastRoll .. ". " .. msg .. _G.compPos end
                speakText(fMsg)
                if msg then 
                  if msg:find("snake") then playSnd(soundSnake) elseif msg:find("ladder") then playSnd(soundLadder) end 
                else 
                  playMoveSteps(lastRoll) 
                end
              end
            end}, 1000)
          end
        end
        if turn == _G.myId and not _G.isGameOver then
          if not _G.myTurn then
            _G.myTurn = true
            _G.gameHandler.postDelayed(Runnable{run=function()
               if not _G.isGameOver and _G.myTurn then
                 btnRoll.setEnabled(true)
                 statusTxt.setText("Your Turn!")
                 speakText("Your Turn! Roll Dice")
               end
            end}, 4000)
          end
        else
          if _G.myTurn then
            _G.myTurn = false
            btnRoll.setEnabled(false)
            statusTxt.setText(oppName .. "'s Turn...")
          end
        end
      end
    end)
    if _G.isInMatch then _G.gameHandler.postDelayed(Runnable{run=syncOnline}, 2000) end
  end

  local function computerTurn()
    if _G.isGameOver then return end
    btnRoll.setEnabled(false)
    statusTxt.setText("Computer's Turn...")
    speakText("It's Computer's turn")
    _G.gameHandler.postDelayed(Runnable{run=function()
      if _G.isGameOver then return end
      playSnd(soundDice)
      local roll = _G.random.nextInt(6) + 1
      _G.gameHandler.postDelayed(Runnable{run=function()
        if _G.isGameOver then return end
        local target = _G.compPos + roll
        if target > 100 then
          speakText("Computer rolled " .. roll .. ". Move skipped.")
          _G.gameHandler.postDelayed(Runnable{run=function() if not _G.isGameOver then btnRoll.setEnabled(true) statusTxt.setText("Your Turn!") speakText("Your Turn! Roll Dice") end end}, 4000)
        elseif target == 100 then
          _G.compPos = 100
          _G.isGameOver = true
          updateDisplay()
          finalizeStats(false)
          speakText("Computer rolled " .. roll .. " and reached 100.")
          playMoveSteps(roll)
          _G.gameHandler.postDelayed(Runnable{run=function() playSnd(soundWin) speakText("Computer Won!") statusTxt.setText("Computer Won!") btnRoll.setText("BACK TO MENU") btnRoll.setEnabled(true) btnAction.setText("REMATCH") end}, 1000)
        else
          local newPos, msg = checkBoard(target, false)
          _G.compPos = newPos
          updateDisplay()
          local fMsg = "Computer rolled " .. roll .. ". Position: " .. _G.compPos
          if msg then fMsg = "Computer rolled " .. roll .. ". " .. msg .. _G.compPos end
          speakText(fMsg)
          if msg then 
            if msg:find("snake") then playSnd(soundSnake) elseif msg:find("ladder") then playSnd(soundLadder) end 
          else 
            playMoveSteps(roll) 
          end
          _G.gameHandler.postDelayed(Runnable{run=function() if not _G.isGameOver then btnRoll.setEnabled(true) statusTxt.setText("Your Turn!") speakText("Your Turn! Roll Dice") end end}, 4000)
        end
      end}, 1500)
    end}, 1000)
  end

  btnRoll.setOnClickListener(function()
    if _G.isGameOver then 
      if _G.isOnlineMode then
        Http.put(FB_URL .. "/matches/" .. _G.matchId .. "/left.json?auth=" .. FB_KEY, '"'.._G.myId..'"', function() end)
      end
      showMainMenu() 
      return 
    end
    btnRoll.setEnabled(false)
    _G.myTurn = false
    _G.matchTimerValue = 60
    playSnd(soundDice)
    statusTxt.setText("Rolling...")
    _G.gameHandler.postDelayed(Runnable{run=function()
      if _G.isGameOver then return end
      local roll = _G.random.nextInt(6) + 1
      local target = _G.playerPos + roll
      if target == 100 then
        _G.playerPos = 100
        _G.isGameOver = true
        updateDisplay()
        finalizeStats(true)
        speakText("You rolled " .. roll .. " and reached 100.")
        playMoveSteps(roll)
        _G.gameHandler.postDelayed(Runnable{run=function() playSnd(soundWin) speakText("You Won!") statusTxt.setText("You Won!") btnRoll.setText("BACK TO MENU") btnRoll.setEnabled(true) btnAction.setText("REMATCH") end}, 1000)
      else
        local newPos, msg = checkBoard(target > 100 and _G.playerPos or target, true)
        local finalPos = (target > 100) and _G.playerPos or newPos
        _G.playerPos = finalPos
        updateDisplay()
        if target > 100 then
          speakText("You rolled " .. roll .. ". Move skipped.")
        else
          local fMsg = pName .. " rolled " .. roll .. ". Position: " .. _G.playerPos
          if msg then fMsg = pName .. " rolled " .. roll .. ". " .. msg .. _G.playerPos end
          speakText(fMsg)
          if msg then 
            if msg:find("snake") then playSnd(soundSnake) elseif msg:find("ladder") then playSnd(soundLadder) end 
          else 
            playMoveSteps(roll) 
          end
        end
      end
      if _G.isOnlineMode then
        local url = FB_URL .. "/matches/" .. _G.matchId .. ".json?auth=" .. FB_KEY
        local data = string.format('{"pos_%s":%d,"last_roll":%d,"move_id":%d,"turn":"%s","status":"accepted"}', _G.myId, _G.playerPos, roll, _G.lastProcessedMove + 1, oppName)
        Http.put(url, data, function() end)
        _G.gameHandler.postDelayed(Runnable{run=function() if not _G.isGameOver then speakText("Waiting for " .. oppName) end end}, 4000)
      elseif not _G.isGameOver then
        _G.gameHandler.postDelayed(Runnable{run=function() computerTurn() end}, 4000)
      end
    end}, 1500)
  end)

  btnAction.setOnClickListener(function()
    if not _G.isGameOver then
      local quitMsg = "If you quit now, the current game data will not be saved.\n\nDo you want to quit?"
      local qDlg = AlertDialog.Builder(context).setTitle("Quit Match?").setMessage(quitMsg).setPositiveButton("Quit", function()
        _G.isGameOver = true
        if _G.isOnlineMode then
          Http.put(FB_URL .. "/matches/" .. _G.matchId .. "/quit.json?auth=" .. FB_KEY, '"'.._G.myId..'"', function() end)
        end
        showMainMenu()
      end).setNegativeButton("Cancel", nil).create()
      qDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
      qDlg.show()
    else
      if _G.isOnlineMode then
        performSecretCheck(oppName, function(ok)
           if ok then
             speakText("Request sent, please wait for 20 seconds.")
             _G.requestTimeoutActive = true
             Http.delete(FB_URL .. "/challenges/" .. _G.myId .. "_status.json?auth=" .. FB_KEY, function()
                local checkId1 = _G.myId .. "_" .. oppName
                local checkId2 = oppName .. "_" .. _G.myId
                Http.delete(FB_URL .. "/matches/" .. checkId1 .. ".json?auth=" .. FB_KEY, function()
                   Http.delete(FB_URL .. "/matches/" .. checkId2 .. ".json?auth=" .. FB_KEY, function()
                      Http.put(FB_URL.."/challenges/"..oppName..".json?auth="..FB_KEY, '"'.._G.myId..'"', function()
                         waitForRematchAcceptance(oppName)
                      end)
                   end)
                end)
             end)
             _G.gameHandler.postDelayed(Runnable{run=function()
                if _G.requestTimeoutActive then
                   _G.requestTimeoutActive = false
                   speakText("The player is online but not responding.")
                   Http.delete(FB_URL .. "/challenges/" .. oppName .. ".json?auth=" .. FB_KEY, function() end)
                end
             end}, 20000)
           end
        end, true)
      else
        startMatch()
      end
    end
  end)
  _G.matchDlg.show()
  if _G.isOnlineMode then syncOnline() end
  listenForRematchInGame()
end

function listenForRematchInGame()
   if not _G.isGameOver or not _G.isInMatch or not _G.isOnlineMode then
      if _G.isInMatch then _G.gameHandler.postDelayed(Runnable{run=listenForRematchInGame}, 3000) end
      return
   end
   local url = FB_URL .. "/challenges/" .. _G.myId .. ".json?auth=" .. FB_KEY
   Http.get(url, function(code, body)
      if code == 200 and body ~= "null" then
         local challenger = body:match('"(.-)"')
         if challenger == _G.opponentName then
            Http.delete(url, function() end)
            showChallengeDialog(challenger)
         end
      end
   end)
   if _G.isInMatch then _G.gameHandler.postDelayed(Runnable{run=listenForRematchInGame}, 3000) end
end

function performSecretCheck(target, callback, isRematch)
  local url = FB_URL .. "/lobby/" .. target .. ".json?auth=" .. FB_KEY
  Http.get(url, function(code, body)
    if code == 200 and body ~= "null" then
      local lastSeen = tonumber(body:match('"time":(%d+)')) or 0
      local status = body:match('"status":"(.-)"')
      local now = os.time()
      if (now - lastSeen) > 12 then
        speakText("This player is offline, please refresh lobby.")
        callback(false)
        return
      end
      if not isRematch and status == "playing" then
        speakText("This player is currently in another match.")
        callback(false)
        return
      end
      callback(true)
    else
      speakText("Player data not found.")
      callback(false)
    end
  end)
end

function waitForRematchAcceptance(target)
  if not _G.isInMatch or _G.isGameOver == false or not _G.requestTimeoutActive then return end
  Http.get(FB_URL .. "/challenges/" .. _G.myId .. "_status.json?auth=" .. FB_KEY, function(code, body)
    if code == 200 and body == '"rejected"' then
      _G.requestTimeoutActive = false
      Http.delete(FB_URL .. "/challenges/" .. _G.myId .. "_status.json?auth=" .. FB_KEY, function() end)
      speakText(target .. " rejected rematch.")
      return
    end
    local checkId1 = _G.myId .. "_" .. target
    local checkId2 = target .. "_" .. _G.myId
    Http.get(FB_URL .. "/matches/" .. checkId1 .. ".json?auth=" .. FB_KEY, function(c1, b1)
      if c1 == 200 and b1 ~= "null" and b1:find('"status"%s*:%s*"accepted"') then
          _G.requestTimeoutActive = false
          Http.delete(FB_URL .. "/challenges/" .. target .. ".json?auth=" .. FB_KEY, function() end)
          _G.matchId = checkId1
          _G.opponentName = target
          _G.isOnlineMode = true
          _G.isGameOver = false
          _G.lastProcessedMove = -1
          startMatch()
          return
      end
      Http.get(FB_URL .. "/matches/" .. checkId2 .. ".json?auth=" .. FB_KEY, function(c2, b2)
        if c2 == 200 and b2 ~= "null" and b2:find('"status"%s*:%s*"accepted"') then
            _G.requestTimeoutActive = false
            Http.delete(FB_URL .. "/challenges/" .. target .. ".json?auth=" .. FB_KEY, function() end)
            _G.matchId = checkId2
            _G.opponentName = target
            _G.isOnlineMode = true
            _G.isGameOver = false
            _G.lastProcessedMove = -1
            startMatch()
        else
            if _G.isInMatch and _G.requestTimeoutActive then _G.gameHandler.postDelayed(Runnable{run=function() waitForRematchAcceptance(target) end}, 3000) end
        end
      end)
    end)
  end)
end

function refreshLobby(container, btnRef)
  if not _G.isLobbyActive then return end
  Http.get(FB_URL .. "/lobby.json?auth=" .. FB_KEY, function(code, body)
    if not _G.isLobbyActive then return end
    if code == 200 and body ~= "null" then
      local now = os.time()
      local players = {}
      for name, data in body:gmatch('"(.-)":({.-})') do
        local time = tonumber(data:match('"time":(%d+)'))
        local status = data:match('"status":"(.-)"')
        if name ~= _G.myId and (now - time) < 12 then
          table.insert(players, {name=name, status=status})
        end
      end
      container.removeAllViews()
      if #players == 0 then
        local tv = TextView(service) tv.setText("No players online. Try refreshing.") tv.setFocusable(true) container.addView(tv)
      else
        for i, p in ipairs(players) do
          local btn = Button(service)
          local displayStatus = (p.status == "playing") and "(In Game)" or "(Online)"
          btn.setText(p.name .. " " .. displayStatus)
          btn.setFocusable(true)
          if p.status == "playing" then
             btn.setEnabled(false)
             btn.setAlpha(0.5)
          end
          btn.setOnClickListener(function()
            if _G.requestTimeoutActive then return end
            performSecretCheck(p.name, function(ok)
              if ok then
                speakText("Request sent, please wait for 20 seconds.")
                _G.requestTimeoutActive = true
                btnRef.setEnabled(false)
                for j=0, container.getChildCount()-1 do container.getChildAt(j).setEnabled(false) end
                _G.opponentName = p.name
                _G.matchId = _G.myId .. "_" .. p.name
                Http.delete(FB_URL .. "/challenges/" .. p.name .. ".json?auth=" .. FB_KEY, function()
                  Http.delete(FB_URL .. "/challenges/" .. _G.myId .. "_status.json?auth=" .. FB_KEY, function()
                    Http.delete(FB_URL .. "/matches/" .. _G.matchId .. ".json?auth=" .. FB_KEY, function()
                      Http.put(FB_URL.."/challenges/"..p.name..".json?auth="..FB_KEY, '"'.._G.myId..'"', function()
                        waitForAcceptance(p.name, container, btnRef)
                      end)
                    end)
                  end)
                end)
                local currentRequestTime = os.time()
                _G.lastRequestTime = currentRequestTime
                _G.gameHandler.postDelayed(Runnable{run=function()
                   if _G.requestTimeoutActive and _G.lastRequestTime == currentRequestTime then
                      _G.requestTimeoutActive = false
                      btnRef.setEnabled(true)
                      for j=0, container.getChildCount()-1 do container.getChildAt(j).setEnabled(true) end
                      speakText("The player is online but not responding.")
                      Http.delete(FB_URL .. "/challenges/" .. p.name .. ".json?auth=" .. FB_KEY, function() end)
                   end
                end}, 20000)
              end
            end, false)
          end)
          container.addView(btn)
        end
      end
    end
  end)
end

function waitForAcceptance(target, container, btnRef)
  if not _G.isLobbyActive or not _G.requestTimeoutActive then return end
  Http.get(FB_URL .. "/challenges/" .. _G.myId .. "_status.json?auth=" .. FB_KEY, function(code, body)
    if not _G.requestTimeoutActive then return end
    if code == 200 and body == '"rejected"' then
      _G.requestTimeoutActive = false
      btnRef.setEnabled(true)
      for j=0, container.getChildCount()-1 do container.getChildAt(j).setEnabled(true) end
      Http.delete(FB_URL .. "/challenges/" .. _G.myId .. "_status.json?auth=" .. FB_KEY, function() end)
      speakText(target .. " rejected challenge.")
      return
    end
    local checkId = _G.myId .. "_" .. target
    Http.get(FB_URL .. "/matches/" .. checkId .. ".json?auth=" .. FB_KEY, function(c, b)
      if c == 200 and b ~= "null" and b:find('"status"%s*:%s*"accepted"') then
          _G.requestTimeoutActive = false
          Http.delete(FB_URL .. "/challenges/" .. target .. ".json?auth=" .. FB_KEY, function() end)
          _G.matchId = checkId
          _G.opponentName = target
          _G.isOnlineMode = true
          _G.isGameOver = false
          _G.lastProcessedMove = -1
          startMatch()
      else
          if _G.isLobbyActive and _G.requestTimeoutActive then _G.gameHandler.postDelayed(Runnable{run=function() waitForAcceptance(target, container, btnRef) end}, 3000) end
      end
    end)
  end)
end

function showLobby()
  if _G.mainMenuDlg then pcall(function() _G.mainMenuDlg.dismiss() end) _G.mainMenuDlg = nil end
  _G.isLobbyActive = true
  _G.isHeartbeatActive = true
  _G.isInMatch = false
  _G.requestTimeoutActive = false
  sendHeartbeat()
  local context = service
  local layout = LinearLayout(context)
  layout.setOrientation(LinearLayout.VERTICAL)
  layout.setPadding(40,40,40,40)
  local title = TextView(context)
  title.setText("Online Lobby")
  title.setTextSize(20)
  title.setFocusable(true)
  layout.addView(title)
  local btnRefresh = Button(context)
  btnRefresh.setText("REFRESH LOBBY")
  layout.addView(btnRefresh)
  local scroll = ScrollView(context)
  local container = LinearLayout(context)
  container.setOrientation(LinearLayout.VERTICAL)
  scroll.addView(container)
  layout.addView(scroll)
  _G.lobbyDlg = AlertDialog.Builder(context).setView(layout).setCancelable(false).setNegativeButton("Back", function() 
    _G.isLobbyActive = false
    _G.requestTimeoutActive = false
    showMainMenu()
  end).create()
  _G.lobbyDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
  _G.lobbyDlg.setOnKeyListener({onKey=function(d,k,e)
    if k == KeyEvent.KEYCODE_BACK then return true end
    return false
  end})
  btnRefresh.setOnClickListener(function() refreshLobby(container, btnRefresh) end)
  _G.lobbyDlg.show()
  refreshLobby(container, btnRefresh)
end

function showMainMenu()
  closeAllDialogs()
  _G.isTransitioning = false
  _G.isHeartbeatActive = true
  _G.isLobbyActive = false
  _G.isOnlineMode = false
  _G.isInMatch = false
  _G.isGameOver = false
  _G.opponentName = ""
  _G.matchId = ""
  _G.hasLeftAnnounced = false
  _G.requestTimeoutActive = false
  sendHeartbeat()
  listenForChallenges()
  local context = service
  startBG()
  local layout = LinearLayout(context)
  layout.setOrientation(LinearLayout.VERTICAL)
  layout.setPadding(50, 40, 50, 40)
  local title = TextView(context)
  title.setText("Snake and Ladders")
  title.setTextSize(24)
  title.setFocusable(true)
  title.setTextColor(Color.parseColor("#2196F3"))
  layout.addView(title)
  local bS = Button(context) bS.setText("PLAY VS COMPUTER") layout.addView(bS)
  local bO = Button(context) bO.setText("PLAY ONLINE") layout.addView(bO)
  local bN = Button(context) bN.setText("NOTIFICATIONS") layout.addView(bN)
  local bSet = Button(context) bSet.setText("SETTINGS") layout.addView(bSet)
  local bP = Button(context) bP.setText("PROFILE") layout.addView(bP)
  local bI = Button(context) bI.setText("GAME INFORMATION") layout.addView(bI)
  local bExit = Button(context) bExit.setText("EXIT EXTENSION") layout.addView(bExit)
  _G.mainMenuDlg = AlertDialog.Builder(context).create()
  _G.mainMenuDlg.setView(layout)
  _G.mainMenuDlg.setCancelable(false)
  _G.mainMenuDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
  _G.mainMenuDlg.setOnKeyListener({onKey=function(d,k,e)
    if k == KeyEvent.KEYCODE_BACK then return true end
    return false
  end})
  bS.setOnClickListener(function() startMatch() end)
  bO.setOnClickListener(function() showLobby() end)
  bN.setOnClickListener(function() showNotifications() end)
  bSet.setOnClickListener(function() showSettings() end)
  bP.setOnClickListener(function() showProfile() end)
  bI.setOnClickListener(function() showInfo() end)
  bExit.setOnClickListener(function() 
     Http.delete(FB_URL .. "/lobby/" .. _G.myId .. ".json?auth=" .. FB_KEY, function() end)
     stopBG() 
     closeAllDialogs()
     service.stopSelf()
  end)
  _G.mainMenuDlg.show()
end

local function checkNewNotifications(callback)
  Http.get(FB_URL .. "/update_info.json?auth=" .. FB_KEY, function(code, body)
    if code == 200 and body and body ~= "null" then
      local latestMsg = ""
      for id, content in body:gmatch('"([^"]+)":%{(.-)%}') do
        latestMsg = content:match('"code":"(.-)"') or ""
        break
      end
      local savedMsg = getStat("last_notif_text", "")
      if latestMsg ~= "" and latestMsg ~= savedMsg then
        saveStat("last_notif_text", latestMsg)
        local context = service
        local dlg = AlertDialog.Builder(context)
        dlg.setTitle("New Notification!")
        local scroll = ScrollView(context)
        local layout = LinearLayout(context)
        layout.setOrientation(LinearLayout.VERTICAL)
        layout.setPadding(40, 40, 40, 40)
        local cleanLines = latestMsg:gsub("\\n", "\n"):gsub("\\\\", "\\")
        for line in cleanLines:gmatch("[^\r\n]+") do
          local tv = TextView(context)
          tv.setText(line)
          tv.setPadding(0, 10, 0, 10)
          tv.setFocusable(true)
          tv.setTextSize(16)
          layout.addView(tv)
        end
        scroll.addView(layout)
        dlg.setView(scroll)
        dlg.setPositiveButton("OK", function() callback() end)
        dlg.setOnCancelListener({onCancel=function() callback() end})
        _G.newNotifDlg = dlg.create()
        _G.newNotifDlg.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
        _G.newNotifDlg.show()
      else
        callback()
      end
    else
      callback()
    end
  end)
end

function checkAndStart()
  _G.isHeartbeatActive = true
  listenForChallenges()
  checkNewNotifications(function()
    if not File(downloadFolder).exists() then
      File(downloadFolder).mkdirs()
      service.speak("Downloading game sounds, please wait")
      Http.download(downloadUrl, zipFile, function(code)
        if code == 200 then
          import "java.util.zip.*"
          import "java.io.*"
          local zip = ZipFile(zipFile)
          local entries = zip.entries()
          while entries.hasMoreElements() do
            local entry = entries.nextElement()
            local out = File(downloadFolder .. entry.getName())
            if entry.isDirectory() then
              out.mkdirs()
            else
              local input = zip.getInputStream(entry)
              local output = FileOutputStream(out)
              local buffer = luajava.newArray(luajava.bindClass("byte"), 4096)
              local len = input.read(buffer)
              while len ~= -1 do
                output.write(buffer, 0, len)
                len = input.read(buffer)
              end
              output.close()
              input.close()
            end
          end
          zip.close()
          File(zipFile).delete()
          service.speak("Sounds ready")
          checkAndStart()
        else
          service.speak("Download failed")
        end
      end)
      return
    end
    local n = getStat("player_name", "")
    if n == "" then
      local context = service
      local l = LinearLayout(context)
      l.setOrientation(LinearLayout.VERTICAL)
      l.setPadding(40,40,40,40)
      local ed = EditText(context)
      ed.setHint("Enter Name")
      l.addView(ed)
      local b = Button(context)
      b.setText("SAVE")
      l.addView(b)
      local d = AlertDialog.Builder(context).setTitle("Set Name").setView(l).setCancelable(false).create()
      d.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
      b.setOnClickListener(function()
        local name = tostring(ed.getText()):gsub("%s+", "")
        if name ~= "" then
          saveStat("player_name", name)
          _G.myId = name
          d.dismiss()
          showMainMenu()
        end
      end)
      d.show()
    else
      _G.myId = n
      showMainMenu()
    end
  end)
end

checkAndStart()