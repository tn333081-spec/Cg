if service.click({
{"Send",
}
})
return true
end

if service.click({
{"%Direct swipe right",
"%Go back",
"Voice message, Button. Double tap and hold to record, slide left to cancel recording, slide up to lock recording on. Release to send.$01",
"%Direct swipe up",
}
})
return true
end