
if service.click({
{"MORE OPTIONS,",
"WATCH ADS & EARN COINS",
"CLOSE AD",
}
})
return true
end
