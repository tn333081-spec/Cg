require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "android.content.*"
import "android.speech.*"
import "android.provider.Settings"
import "android.graphics.PixelFormat"
import "android.graphics.Color"
import "android.graphics.Typeface"
import "android.view.accessibility.AccessibilityNodeInfo"
import "android.content.ClipData"
import "java.util.ArrayList"
import "java.net.URLEncoder"

-- =========================================================
--  SMART DICTATION - V1.7.0 (2.5 Default & Retain English)
-- =========================================================

-- 1. CONFIGURATION (GLOBALS)
APP_VERSION = "1.7.0"
PREFS_NAME = "VISmartDictation_Public_V2"
FIREBASE_DB_URL = "https://mmsg-e099a-default-rtdb.asia-southeast1.firebasedatabase.app"

-- 2. SYSTEM HELPERS
local ctx = service
local wm = ctx.getSystemService(Context.WINDOW_SERVICE)
local prefs = ctx.getSharedPreferences(PREFS_NAME, 0)

function saveConfig(key, value) prefs.edit().putString(key, tostring(value)).apply() end
function loadConfig(key, defaultVal) return prefs.getString(key, tostring(defaultVal)) end
function saveBool(key, value) prefs.edit().putBoolean(key, value).apply() end
function loadBool(key, defaultVal) return prefs.getBoolean(key, defaultVal) end
function saveInt(key, value) prefs.edit().putInt(key, value).apply() end
function loadInt(key, defaultVal) return prefs.getInt(key, defaultVal) end

function showToast(msg)
  local t = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT)
  t.show()
end

-- 3. WINDOW MANAGER
local WindowManagerHelper = { currentView = nil, isAdded = false }

function WindowManagerHelper.close()
  if WindowManagerHelper.currentView and WindowManagerHelper.isAdded then
    local v = WindowManagerHelper.currentView
    WindowManagerHelper.currentView = nil
    WindowManagerHelper.isAdded = false
    pcall(function() wm.removeView(v) end)
  end
end

function WindowManagerHelper.show(view, params)
  WindowManagerHelper.close() 
  pcall(function()
    wm.addView(view, params)
    WindowManagerHelper.currentView = view
    WindowManagerHelper.isAdded = true
  end)
end

function getOverlayParams()
  local params = WindowManager.LayoutParams()
  if Build.VERSION.SDK_INT >= 26 then params.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
  else params.type = WindowManager.LayoutParams.TYPE_PHONE end
  params.format = PixelFormat.TRANSLUCENT
  params.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND
  params.dimAmount = 0.85
  params.gravity = Gravity.CENTER
  params.width = WindowManager.LayoutParams.MATCH_PARENT
  params.height = WindowManager.LayoutParams.MATCH_PARENT
  params.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
  return params
end

-- =========================================================
--  4. CLOUD NOTIFICATIONS
-- =========================================================
function checkFirebaseMessages()
  local url = FIREBASE_DB_URL .. "/broadcast.json"
  Http.get(url, nil, "UTF-8", {["Content-Type"]="application/json"}, function(code, body)
    if code == 200 and body and body ~= "null" then
      local id = tonumber(body:match('"id":%s*(%d+)'))
      local title = body:match('"title":%s*"(.-)"')
      local msg = body:match('"message":%s*"(.-)"')
      
      if id and title and msg then
        local lastId = loadInt("last_msg_id", 0)
        if id > lastId then
          showFirebaseDialog(id, title, msg)
        end
      end
    end
  end)
end

function showFirebaseDialog(id, title, msg)
  local layout = {
    LinearLayout, orientation="vertical", layout_width="85%w", backgroundColor="#1E1E1E", padding="25dp", gravity="center",
    { TextView, text="🔔 Notification", textSize="14sp", textColor="#03DAC6", paddingBottom="8dp" },
    { TextView, id="tv_msg_title", text=title, textSize="22sp", textColor="#BB86FC", paddingBottom="15dp", gravity="center" },
    { TextView, text=msg, textSize="16sp", textColor="#EEEEEE", paddingBottom="25dp", gravity="center", lineHeight="24sp" },
    { 
      CardView, radius="25dp", CardBackgroundColor="#6200EE", elevation="5dp",
      {
        TextView, id="btn_msg_ok", text="Okay, Read", gravity="center", textColor="#FFFFFF", padding="12dp", textSize="16sp",
        layout_width="match_parent",
        onClick=function() 
          saveInt("last_msg_id", id)
          WindowManagerHelper.close()
          showDashboard() 
        end 
      }
    }
  }
  
  local wrapper = {
    CardView, radius="20dp", CardBackgroundColor="#1E1E1E", elevation="10dp",
    { LinearLayout, layout_width="fill", layout_height="wrap", layout }
  }
  
  local screen = {
    LinearLayout, gravity="center", layout_width="fill", layout_height="fill", backgroundColor="#90000000",
    wrapper
  }
  
  local view = loadlayout(screen)
  tv_msg_title.setTypeface(Typeface.DEFAULT_BOLD)
  btn_msg_ok.setTypeface(Typeface.DEFAULT_BOLD)
  WindowManagerHelper.show(view, getOverlayParams())
end

-- =========================================================
--  5. CORE LOGIC
-- =========================================================

function getApiKeys()
  local raw = loadConfig("api_keys", "")
  local keys = {}
  for line in raw:gmatch("[^\r\n]+") do
    local cleanLine = line:match("^%s*(.-)%s*$")
    if #cleanLine > 10 then table.insert(keys, cleanLine) end
  end
  return keys
end

function pasteToNode(node, text)
  if not node then return end
  local handler = Handler(Looper.getMainLooper())
  handler.post(Runnable({
    run = function()
    
      local appendType = loadConfig("append_ending", "Space")
      if appendType == "Space" then text = text .. " "
      elseif appendType == "Dot (.)" then text = text .. "."
      elseif appendType == "New Line" then text = text .. "\n"
      end

      local useAutoCopy = loadConfig("use_autocopy", "true") == "true"
      
      if useAutoCopy then
          local clipboard = ctx.getSystemService(Context.CLIPBOARD_SERVICE)
          local clip = ClipData.newPlainText("voice_input", text)
          clipboard.setPrimaryClip(clip)
          local pasted = node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
          
          if not pasted then
            local args = Bundle()
            local currentText = node.getText()
            if currentText == nil then currentText = "" end
            local newText = tostring(currentText) .. " " .. text
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, newText)
            node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
          end
      else
          local args = Bundle()
          local currentText = node.getText()
          local currentStr = tostring(currentText)
          
          if currentText == nil or currentStr == "" then 
              currentStr = ""
          end
          
          local prefixSpace = ""
          if currentStr ~= "" and currentStr:sub(-1) ~= " " and currentStr:sub(-1) ~= "\n" then
              prefixSpace = " " 
          end
          
          local newText = currentStr .. prefixSpace .. text
          args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, newText)
          node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
      end
    end
  }))
end

function escapeJson(str)
  if not str then return "" end
  return str:gsub('\\', '\\\\'):gsub('"', '\\"'):gsub('\n', '\\n'):gsub('\r', '')
end

function getStyleInstruction(styleName)
  if styleName == "Grammar Fix" then return "grammatically correct text with proper punctuation"
  elseif styleName == "Professional" then return "professional, formal, and concise business text"
  elseif styleName == "Casual" then return "casual, friendly, and conversational text"
  elseif styleName == "Academic" then return "academic, formal text suitable for research"
  elseif styleName == "Creative" then return "creative, descriptive, and engaging text"
  elseif styleName == "Email Format" then return "well-structured professional email"
  elseif styleName == "Summarize" then return "concise summary in bullet points"
  elseif styleName == "Poetic" then return "poetic, rhyming text"
  elseif styleName == "Prompt: General" then return "highly detailed, structured, and effective AI prompt"
  elseif styleName == "Prompt: Chain of Thought" then return "prompt that explicitly asks the model to use step-by-step reasoning"
  elseif styleName == "Prompt: Expert Persona" then return "prompt that assigns a specific expert persona to the AI"
  elseif styleName == "Prompt: Image Gen" then return "highly detailed text-to-image prompt suitable for Midjourney/Stable Diffusion"
  elseif styleName == "Prompt: Code Gen" then return "specific technical prompt for generating clean code"
  elseif styleName == "Prompt: Socratic" then return "prompt that guides the AI to ask questions (Socratic method)"
  elseif styleName == "Prompt: Debate" then return "prompt that asks for arguments for and against the topic"
  elseif styleName == "Prompt: Brainstorming" then return "prompt that asks the AI to generate a diverse and creative list of ideas or solutions"
  elseif styleName == "Prompt: Explain Like I'm 5" then return "prompt that instructs the AI to explain a complex topic simply, as if to a 5-year-old"
  elseif styleName == "Prompt: Roleplay" then return "prompt that sets up a detailed roleplay scenario and character background for the AI"
  elseif styleName == "Prompt: SEO Content" then return "prompt designed to generate highly engaging, SEO-optimized content with target keywords"
  elseif styleName == "Prompt: Data Extraction" then return "prompt that asks the AI to extract specific information from text and output it in a structured format like JSON"
  elseif styleName == "Prompt: Storytelling" then return "prompt that guides the AI to write a compelling, narrative-driven story"
  elseif styleName == "Prompt: Instructional" then return "highly structured prompt with clear, step-by-step instructions and strict constraints"
  elseif styleName == "Prompt: Reverse Engineer" then return "prompt that asks the AI to deduce the exact prompt or instructions that would have generated the given text"
  else return "grammatically correct text" end
end

function processWithGemini(rawText, targetNode, keyIndex)
  local keys = getApiKeys()
  if #keys == 0 or keyIndex > #keys then
    if #keys == 0 then showToast("AI Error: Please add API Keys in Settings.") 
    else showToast("AI Error: All API Keys quota exceeded.") end
    pasteToNode(targetNode, rawText)
    return
  end

  local currentKey = keys[keyIndex]
  -- Default model is now gemini-2.5-flash
  local model = loadConfig("ai_model", "gemini-2.5-flash")
  
  if model == "nil" or model == "" then
      model = "gemini-2.5-flash"
  elseif model == "gemini-2.5-flash-preview-09-2025" then
      model = "gemini-2.5-flash"
  end

  local url = "https://generativelanguage.googleapis.com/v1beta/models/" .. model .. ":generateContent?key=" .. currentKey
  
  local useAI = loadConfig("use_ai", "false") == "true"
  local useTrans = loadConfig("use_trans", "false") == "true"
  local useEmoji = loadConfig("use_emoji", "false") == "true" 
  local preserveEng = loadConfig("preserve_eng", "false") == "true"
  local styleName = loadConfig("writing_style", "Automatic (Smart Detect)")
  local targetLang = loadConfig("trans_lang", "English")
  
  local promptText = ""
  local statusMsg = ""
  
  local emojiInstr = ""
  if useEmoji then
      emojiInstr = ". Also, insert contextually appropriate emojis throughout the text based on the mood"
  end

  -- STRICT TRANSLATION RULES WITH PRESERVE ENGLISH CAPABILITY
  local transStrictInstr = ""
  if useTrans then
      if preserveEng then
          transStrictInstr = " STRICT INSTRUCTION: Translate the result into " .. targetLang .. ". HOWEVER, any English words, technical terms, or names present in the original input MUST be kept in English (Latin alphabet) in the final output. Do NOT transliterate or translate English words."
      else
          transStrictInstr = " STRICT INSTRUCTION: You MUST completely translate the final result into " .. targetLang .. ". Do NOT output any text in English (unless the target is English)."
      end
  end

  if styleName == "Automatic (Smart Detect)" then
      statusMsg = "🤖 Auto-Detecting Intent..."
      if useTrans then
          promptText = "Task: Analyze the input intent and rewrite it optimally" .. emojiInstr .. "." .. transStrictInstr .. " Output ONLY the final text. Input: " .. rawText
          statusMsg = "🤖 Auto + Translate ("..targetLang..")..."
      else
          promptText = "Task: Analyze the input text intent (is it a request for code? an email? simple grammar?) and rewrite it optimally" .. emojiInstr .. ". Output ONLY the result. Input: " .. rawText
          statusMsg = "🤖 Auto-Enhancing..."
      end
  else
      if useTrans and useAI then
        local styleInstr = getStyleInstruction(styleName)
        promptText = "Task: Rewrite the input to be " .. styleInstr .. emojiInstr .. "." .. transStrictInstr .. " Output ONLY the final text without conversational filler. Input: " .. rawText
        statusMsg = "🤖 " .. styleName .. " + Trans..."
      elseif useTrans then
        promptText = "Translate the following text into " .. targetLang .. "." .. transStrictInstr .. " Output ONLY the translation without any extra notes. Text: " .. rawText
        statusMsg = "🤖 Translating ("..targetLang..")..."
      elseif useAI then
        local styleInstr = getStyleInstruction(styleName)
        promptText = "Rewrite the following input to be " .. styleInstr .. emojiInstr .. ". Output ONLY the final result. Input: " .. rawText
        statusMsg = "🤖 AI: " .. styleName .. "..."
      else
        pasteToNode(targetNode, rawText)
        return
      end
  end

  local safeText = escapeJson(promptText)
  local jsonBody = '{"contents":[{"parts":[{"text":"'..safeText..'"}]}]}'

  showToast(statusMsg)

  Http.post(url, jsonBody, nil, "UTF-8", {["Content-Type"]="application/json"}, function(code, body)
    if code == 200 then
      local match = body:match('"text":%s*"(.-)"')
      if match then
        local fixedText = match:gsub("\\n", "\n"):gsub('\\"', '"'):gsub("\\\\", "\\")
        pasteToNode(targetNode, fixedText)
      else
        pasteToNode(targetNode, rawText)
      end
    elseif code == 429 then
      showToast("⚠️ Quota Limit. Switching API Key...")
      processWithGemini(rawText, targetNode, keyIndex + 1)
    elseif code == 404 then
      showToast("AI Error 404: Model deprecated. Please select a different AI Model in Settings.")
      pasteToNode(targetNode, rawText)
    else
      showToast("AI Error Code: " .. code)
      pasteToNode(targetNode, rawText)
    end
  end)
end

function startDictation(targetNode)
  local lang = loadConfig("language", "en-US")
  local useAI = loadConfig("use_ai", "false") == "true"
  local useTrans = loadConfig("use_trans", "false") == "true"
  
  showToast("🎙️ Listening (" .. lang .. ")...")
  
  local speechBot = SpeechRecognizer.createSpeechRecognizer(ctx)
  local speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
  speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
  speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
  speechIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true) 
  
  local listener = {
    onReadyForSpeech = function() end,
    onEndOfSpeech = function() end,
    onError = function(error) end,
    onResults = function(results)
      local matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
      if matches and matches.size() > 0 then
        local text = matches.get(0)
        if useAI or useTrans then processWithGemini(text, targetNode, 1)
        else pasteToNode(targetNode, text) end
      end
    end
  }
  speechBot.setRecognitionListener(luajava.createProxy("android.speech.RecognitionListener", listener))
  local handler = Handler(Looper.getMainLooper())
  handler.post(Runnable({ run = function() speechBot.startListening(speechIntent) end }))
end

-- =========================================================
--  6. UI SCREENS
-- =========================================================

function getGreeting()
  local user = loadConfig("username", "User")
  local h = tonumber(os.date("%H"))
  if h < 12 then return "Good Morning, " .. user
  elseif h < 17 then return "Good Afternoon, " .. user
  else return "Good Evening, " .. user end
end

function showLogin()
  local layout = {
    LinearLayout, orientation="vertical", layout_width="fill", layout_height="fill", gravity="center", backgroundColor="#90000000",
    {
      CardView, radius="20dp", CardBackgroundColor="#1E1E1E", layout_width="85%w", elevation="10dp",
      {
        LinearLayout, orientation="vertical", padding="30dp", gravity="center",
        { TextView, id="tv_login_title", text="Welcome", textSize="28sp", textColor="#BB86FC", paddingBottom="10dp" },
        { TextView, text="Let's set up your profile.", textSize="14sp", textColor="#B0B0B0", paddingBottom="25dp" },
        { EditText, id="et_name", hint="Enter Your Name", textColor="#FFFFFF", hintTextColor="#666", layout_width="fill", padding="12dp", background="#2D2D2D" },
        {
          Button, text="Get Started", id="btn_login", backgroundColor="#6200EE", textColor="#FFF", layout_width="fill", layout_marginTop="25dp",
          onClick=function()
            local name = et_name.getText().toString()
            if #name > 0 then
              saveConfig("username", name)
              saveBool("is_logged_in", true)
              WindowManagerHelper.close()
              showIntro() 
            else
              showToast("Please enter your name.")
            end
          end
        }
      }
    }
  }
  local view = loadlayout(layout)
  tv_login_title.setTypeface(Typeface.DEFAULT_BOLD)
  WindowManagerHelper.show(view, getOverlayParams())
end

function showIntro()
  local currentSlide = 1
  local slidesData = {
    { title="Connected", desc="Linked with V I Information Media Cloud. Receive updates instantly.", icon="🔗" },
    { title="AI Powered", desc="Dictate, Translate, and use Prompt Engineering with Gemini AI.", icon="🤖" },
    { title="Emoji Mode", desc="Enable 'Emoji Mode' in settings to automatically add flavor to your texts!", icon="😁" }
  }
  local layout = {
    LinearLayout, orientation="vertical", layout_width="fill", layout_height="fill", gravity="center", backgroundColor="#90000000",
    {
      CardView, layout_width="85%w", CardBackgroundColor="#1E1E1E", radius="20dp", elevation="10dp",
      {
        LinearLayout, orientation="vertical", padding="30dp", gravity="center",
        { TextView, id="tv_icon", text=slidesData[1].icon, textSize="50sp", paddingBottom="20dp" },
        { TextView, id="tv_intro_title", text=slidesData[1].title, textSize="24sp", textColor="#BB86FC", gravity="center", paddingBottom="15dp" },
        { TextView, id="tv_intro_desc", text=slidesData[1].desc, textSize="16sp", textColor="#EEEEEE", gravity="center", paddingBottom="30dp", lineHeight="22sp" },
        {
          LinearLayout, orientation="horizontal", layout_width="fill", gravity="center",
          { TextView, text="Skip", id="btn_skip", gravity="center", textColor="#B0B0B0", layout_weight=1, padding="10dp", textSize="16sp" },
          { CardView, layout_weight=1, radius="25dp", CardBackgroundColor="#6200EE",
            { TextView, id="btn_next", text="Next", gravity="center", textColor="#FFF", layout_width="fill", padding="12dp", textSize="16sp" }
          }
        },
        { TextView, id="tv_steps", text="1 / 3", textSize="12sp", textColor="#777", paddingTop="20dp" }
      }
    }
  }
  local view = loadlayout(layout)
  tv_intro_title.setTypeface(Typeface.DEFAULT_BOLD)
  btn_next.setTypeface(Typeface.DEFAULT_BOLD)
  
  local function updateSlide()
    local data = slidesData[currentSlide]
    tv_icon.setText(data.icon)
    tv_intro_title.setText(data.title)
    tv_intro_desc.setText(data.desc)
    tv_steps.setText(currentSlide .. " / 3")
    if currentSlide == #slidesData then btn_next.setText("Finish") else btn_next.setText("Next") end
  end
  
  _G.finishIntro = function() saveBool("is_first_run", false); WindowManagerHelper.close(); showDashboard() end
  btn_next.onClick = function() if currentSlide < #slidesData then currentSlide = currentSlide + 1; updateSlide() else finishIntro() end end
  btn_skip.onClick = function() finishIntro() end
  WindowManagerHelper.show(view, getOverlayParams())
end

-- ==========================================
-- SCREEN 3: MENU-BASED SETTINGS
-- ==========================================
function showSettings()
  local layout = {
    FrameLayout, layout_width="fill", layout_height="fill", id="settings_root", Focusable=true, FocusableInTouchMode=true,
    
    -- LAYER 1: MAIN MENU (LIST OF BUTTONS)
    {
      LinearLayout, id="menu_main", orientation="vertical", layout_width="fill", layout_height="fill", gravity="center", backgroundColor="#90000000",
      {
        CardView, layout_width="90%w", layout_height="wrap", CardBackgroundColor="#1E1E1E", radius="15dp",
        {
          LinearLayout, orientation="vertical", layout_width="fill", padding="20dp",
          { RelativeLayout, layout_width="fill", paddingBottom="20dp",
            { TextView, id="btn_main_back", text="⬅️", textSize="22sp", layout_alignParentLeft="true", onClick="handleSettingsBack", paddingRight="20dp" },
            { TextView, id="tv_main_title", text="Settings", textSize="24sp", textColor="#BB86FC", layout_centerInParent="true" },
          },
          
          { CardView, radius="10dp", CardBackgroundColor="#2D2D2D", layout_width="fill", layout_marginBottom="12dp",
            { LinearLayout, orientation="horizontal", layout_width="fill", padding="18dp", gravity="center_vertical", onClick="openGen",
              { TextView, text="⚙️ General Settings", textColor="#FFFFFF", textSize="16sp", layout_weight=1 },
              { TextView, id="arrow_1", text=">", textColor="#888888", textSize="16sp" }
            }
          },
          { CardView, radius="10dp", CardBackgroundColor="#2D2D2D", layout_width="fill", layout_marginBottom="12dp",
            { LinearLayout, orientation="horizontal", layout_width="fill", padding="18dp", gravity="center_vertical", onClick="openAI",
              { TextView, text="✨ AI & Writing Style", textColor="#FFFFFF", textSize="16sp", layout_weight=1 },
              { TextView, id="arrow_2", text=">", textColor="#888888", textSize="16sp" }
            }
          },
          { CardView, radius="10dp", CardBackgroundColor="#2D2D2D", layout_width="fill", layout_marginBottom="12dp",
            { LinearLayout, orientation="horizontal", layout_width="fill", padding="18dp", gravity="center_vertical", onClick="openTrans",
              { TextView, text="🌍 Translation", textColor="#FFFFFF", textSize="16sp", layout_weight=1 },
              { TextView, id="arrow_3", text=">", textColor="#888888", textSize="16sp" }
            }
          },
          { CardView, radius="10dp", CardBackgroundColor="#2D2D2D", layout_width="fill", layout_marginBottom="20dp",
            { LinearLayout, orientation="horizontal", layout_width="fill", padding="18dp", gravity="center_vertical", onClick="openApi",
              { TextView, text="🔑 API Configuration", textColor="#FFFFFF", textSize="16sp", layout_weight=1 },
              { TextView, id="arrow_4", text=">", textColor="#888888", textSize="16sp" }
            }
          },
          { Button, id="btn_save", text="Save & Close All", layout_width="fill", backgroundColor="#03DAC6", textColor="#000", layout_marginTop="5dp", onClick="saveSettingsLogic" }
        }
      }
    },

    -- LAYER 2: GENERAL SETTINGS
    {
      LinearLayout, id="menu_gen", visibility=View.GONE, orientation="vertical", layout_width="fill", layout_height="fill", gravity="center", backgroundColor="#90000000", clickable=true,
      {
        CardView, layout_width="90%w", layout_height="wrap", CardBackgroundColor="#1E1E1E", radius="15dp",
        {
          LinearLayout, orientation="vertical", layout_width="fill", padding="20dp",
          { RelativeLayout, layout_width="fill", paddingBottom="20dp",
            { TextView, text="⬅️", textSize="22sp", layout_alignParentLeft="true", onClick="closeGen", paddingRight="20dp" },
            { TextView, id="tv_gen_title", text="General", textSize="22sp", textColor="#BB86FC", layout_centerInParent="true" },
          },
          { TextView, text="Dictation Language:", textColor="#B0B0B0", textSize="14sp" },
          { Spinner, id="sp_lang", layout_width="fill", layout_marginBottom="20dp" },
          { TextView, text="Append at End:", textColor="#B0B0B0", textSize="14sp" },
          { Spinner, id="sp_append", layout_width="fill", layout_marginBottom="20dp" },
          { LinearLayout, orientation="horizontal", layout_width="fill", gravity="center_vertical", layout_marginBottom="10dp",
            { TextView, text="Auto-Copy Dictation", textColor="#EEE", textSize="16sp", layout_weight=1 }, { Switch, id="sw_autocopy" }
          }
        }
      }
    },

    -- LAYER 3: AI SETTINGS
    {
      LinearLayout, id="menu_ai", visibility=View.GONE, orientation="vertical", layout_width="fill", layout_height="fill", gravity="center", backgroundColor="#90000000", clickable=true,
      {
        CardView, layout_width="90%w", layout_height="wrap", CardBackgroundColor="#1E1E1E", radius="15dp",
        {
          LinearLayout, orientation="vertical", layout_width="fill", padding="20dp",
          { RelativeLayout, layout_width="fill", paddingBottom="20dp",
            { TextView, text="⬅️", textSize="22sp", layout_alignParentLeft="true", onClick="closeAI", paddingRight="20dp" },
            { TextView, id="tv_ai_title", text="AI & Style", textSize="22sp", textColor="#BB86FC", layout_centerInParent="true" },
          },
          { LinearLayout, orientation="horizontal", layout_width="fill", gravity="center_vertical", layout_marginBottom="15dp",
            { TextView, text="Enable AI Mode", textColor="#EEE", textSize="16sp", layout_weight=1 }, { Switch, id="sw_ai" }
          },
          { TextView, text="AI Model:", textColor="#B0B0B0", textSize="14sp" },
          { Spinner, id="sp_model", layout_width="fill", layout_marginBottom="20dp" },
          { TextView, text="Writing Style:", textColor="#B0B0B0", textSize="14sp" },
          { Spinner, id="sp_style", layout_width="fill", layout_marginBottom="20dp" },
          { LinearLayout, orientation="horizontal", layout_width="fill", gravity="center_vertical", layout_marginBottom="10dp",
            { TextView, text="Enable Emoji Mode", textColor="#EEE", textSize="16sp", layout_weight=1 }, { Switch, id="sw_emoji" }
          }
        }
      }
    },

    -- LAYER 4: TRANSLATION SETTINGS
    {
      LinearLayout, id="menu_trans", visibility=View.GONE, orientation="vertical", layout_width="fill", layout_height="fill", gravity="center", backgroundColor="#90000000", clickable=true,
      {
        CardView, layout_width="90%w", layout_height="wrap", CardBackgroundColor="#1E1E1E", radius="15dp",
        {
          LinearLayout, orientation="vertical", layout_width="fill", padding="20dp",
          { RelativeLayout, layout_width="fill", paddingBottom="20dp",
            { TextView, text="⬅️", textSize="22sp", layout_alignParentLeft="true", onClick="closeTrans", paddingRight="20dp" },
            { TextView, id="tv_trans_title", text="Translation", textSize="22sp", textColor="#BB86FC", layout_centerInParent="true" },
          },
          { LinearLayout, orientation="horizontal", layout_width="fill", gravity="center_vertical", layout_marginBottom="15dp",
            { TextView, text="Enable Translation", textColor="#EEE", textSize="16sp", layout_weight=1 }, { Switch, id="sw_trans" }
          },
          { TextView, text="Translate To:", textColor="#B0B0B0", textSize="14sp" },
          { Spinner, id="sp_trans_lang", layout_width="fill", layout_marginBottom="10dp" },
          -- NAYA OPTION: RETAIN ENGLISH WORDS
          { LinearLayout, orientation="horizontal", layout_width="fill", gravity="center_vertical", layout_marginTop="10dp",
            { TextView, text="Retain English Words", textColor="#EEE", textSize="16sp", layout_weight=1 }, { Switch, id="sw_preserve_eng" }
          }
        }
      }
    },

    -- LAYER 5: API KEYS SETTINGS
    {
      LinearLayout, id="menu_api", visibility=View.GONE, orientation="vertical", layout_width="fill", layout_height="fill", gravity="center", backgroundColor="#90000000", clickable=true,
      {
        CardView, layout_width="90%w", layout_height="wrap", CardBackgroundColor="#1E1E1E", radius="15dp",
        {
          LinearLayout, orientation="vertical", layout_width="fill", padding="20dp",
          { RelativeLayout, layout_width="fill", paddingBottom="20dp",
            { TextView, text="⬅️", textSize="22sp", layout_alignParentLeft="true", onClick="closeApi", paddingRight="20dp" },
            { TextView, id="tv_api_title", text="API Keys", textSize="22sp", textColor="#BB86FC", layout_centerInParent="true" },
          },
          { TextView, text="Gemini API Keys:", textColor="#B0B0B0", textSize="14sp" },
          { LinearLayout, layout_width="fill", layout_marginTop="5dp",
            { EditText, id="et_new_key", hint="Paste Key Here", textColor="#EEE", hintTextColor="#666", layout_weight=1, textSize="12sp", background="#2D2D2D", padding="10dp" },
            { Button, text="Add", backgroundColor="#6200EE", textColor="#FFF", onClick="addKeyLogic" }
          },
          { ListView, id="lv_keys", layout_width="fill", layout_height="120dp", backgroundColor="#2D2D2D", dividerHeight=1, layout_marginTop="10dp" },
          { TextView, text="Long press item to delete", textColor="#666", textSize="10sp", gravity="center", padding="5dp" }
        }
      }
    },

    -- LAYER 6: CONFIRMATION DIALOG POP-UP
    {
      LinearLayout, id="dialog_confirm", visibility=View.GONE, orientation="vertical", layout_width="fill", layout_height="fill", gravity="center", backgroundColor="#D0000000", clickable=true, Focusable=true,
      {
        CardView, radius="15dp", CardBackgroundColor="#2D2D2D", layout_width="85%w", elevation="15dp",
        {
          LinearLayout, orientation="vertical", padding="25dp", gravity="center",
          { TextView, id="tv_dialog_title", text="Save Changes?", textSize="22sp", textColor="#BB86FC", paddingBottom="10dp", Focusable=true },
          { TextView, text="You have unsaved changes. What would you like to do before exiting?", textColor="#EEEEEE", textSize="15sp", paddingBottom="25dp", gravity="center" },
          { Button, text="💾 Save Changes", id="btn_dialog_save", backgroundColor="#03DAC6", textColor="#000", layout_width="fill", onClick="saveSettingsLogic", padding="12dp" },
          { Button, text="🗑️ Discard", id="btn_dialog_discard", backgroundColor="#CF6679", textColor="#000", layout_width="fill", layout_marginTop="10dp", onClick="dialogDiscard", padding="12dp" },
          { Button, text="🚫 Cancel", id="btn_dialog_cancel", backgroundColor="#444444", textColor="#FFF", layout_width="fill", layout_marginTop="10dp", onClick="dialogCancel", padding="12dp" }
        }
      }
    }
  }

  local view = loadlayout(layout)

  tv_main_title.setTypeface(Typeface.DEFAULT_BOLD)
  tv_gen_title.setTypeface(Typeface.DEFAULT_BOLD)
  tv_ai_title.setTypeface(Typeface.DEFAULT_BOLD)
  tv_trans_title.setTypeface(Typeface.DEFAULT_BOLD)
  tv_api_title.setTypeface(Typeface.DEFAULT_BOLD)
  btn_save.setTypeface(Typeface.DEFAULT_BOLD)
  tv_dialog_title.setTypeface(Typeface.DEFAULT_BOLD)
  btn_dialog_save.setTypeface(Typeface.DEFAULT_BOLD)
  btn_dialog_discard.setTypeface(Typeface.DEFAULT_BOLD)
  btn_dialog_cancel.setTypeface(Typeface.DEFAULT_BOLD)
  arrow_1.setTypeface(Typeface.DEFAULT_BOLD)
  arrow_2.setTypeface(Typeface.DEFAULT_BOLD)
  arrow_3.setTypeface(Typeface.DEFAULT_BOLD)
  arrow_4.setTypeface(Typeface.DEFAULT_BOLD)

  -- NAVIGATION LOGIC
  _G.openGen = function() menu_main.setVisibility(View.GONE); menu_gen.setVisibility(View.VISIBLE) end
  _G.closeGen = function() menu_gen.setVisibility(View.GONE); menu_main.setVisibility(View.VISIBLE) end
  
  _G.openAI = function() menu_main.setVisibility(View.GONE); menu_ai.setVisibility(View.VISIBLE) end
  _G.closeAI = function() menu_ai.setVisibility(View.GONE); menu_main.setVisibility(View.VISIBLE) end
  
  _G.openTrans = function() menu_main.setVisibility(View.GONE); menu_trans.setVisibility(View.VISIBLE) end
  _G.closeTrans = function() menu_trans.setVisibility(View.GONE); menu_main.setVisibility(View.VISIBLE) end
  
  _G.openApi = function() menu_main.setVisibility(View.GONE); menu_api.setVisibility(View.VISIBLE) end
  _G.closeApi = function() menu_api.setVisibility(View.GONE); menu_main.setVisibility(View.VISIBLE) end
  
  -- DIALOG LOGIC & EXITING
  _G.handleSettingsBack = function() 
    menu_main.setVisibility(View.GONE) 
    dialog_confirm.setVisibility(View.VISIBLE)   
    tv_dialog_title.requestFocus()               
  end
  
  _G.dialogCancel = function() 
    dialog_confirm.setVisibility(View.GONE)      
    menu_main.setVisibility(View.VISIBLE) 
  end
  
  _G.dialogDiscard = function() WindowManagerHelper.close() end
  
  -- SYSTEM HARDWARE BACK BUTTON INTERCEPT
  settings_root.requestFocus()
  settings_root.setOnKeyListener(View.OnKeyListener{
    onKey = function(v, keyCode, event)
      if event.getAction() == KeyEvent.ACTION_UP and keyCode == KeyEvent.KEYCODE_BACK then
        if dialog_confirm.getVisibility() == View.VISIBLE then
          dialogCancel() 
        elseif menu_gen.getVisibility() == View.VISIBLE then
          closeGen()
        elseif menu_ai.getVisibility() == View.VISIBLE then
          closeAI()
        elseif menu_trans.getVisibility() == View.VISIBLE then
          closeTrans()
        elseif menu_api.getVisibility() == View.VISIBLE then
          closeApi()
        else
          handleSettingsBack()
        end
        return true
      end
      return false
    end
  })

  -- ================== POPULATING DATA ==================
  
  -- General: Languages
  local langs = {"English (US)", "Urdu (Pakistan)", "Hindi (India)", "Roman Urdu (English Script)", "Roman Hindi (English Script)"}
  local codes = {"en-US", "ur-PK", "hi-IN", "en-PK", "en-IN"}
  sp_lang.setAdapter(ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, langs))
  local currLang = loadConfig("language", "en-US")
  if currLang == "ur-PK" then sp_lang.setSelection(1) 
  elseif currLang == "hi-IN" then sp_lang.setSelection(2) 
  elseif currLang == "en-PK" then sp_lang.setSelection(3) 
  elseif currLang == "en-IN" then sp_lang.setSelection(4) 
  else sp_lang.setSelection(0) end

  local appendOpts = {"Space", "Dot (.)", "New Line", "None"}
  sp_append.setAdapter(ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, appendOpts))
  local savedAppend = loadConfig("append_ending", "Space")
  for i, s in ipairs(appendOpts) do if s == savedAppend then sp_append.setSelection(i-1); break end end
  
  -- AI: Models (2.5 IS NOW DEFAULT)
  local models = {"Gemini 2.5 Flash", "Gemini 2.0 Flash", "Gemini 1.5 Flash", "Gemini 1.5 Pro"}
  local modelCodes = {"gemini-2.5-flash", "gemini-2.0-flash", "gemini-1.5-flash", "gemini-1.5-pro"}
  sp_model.setAdapter(ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, models))
  local currModel = loadConfig("ai_model", "gemini-2.5-flash")
  
  if currModel == "gemini-2.5-flash" or currModel == "gemini-2.5-flash-preview-09-2025" then sp_model.setSelection(0)
  elseif currModel == "gemini-2.0-flash" then sp_model.setSelection(1) 
  elseif currModel == "gemini-1.5-pro" then sp_model.setSelection(3) 
  else sp_model.setSelection(2) end 

  local styles = { 
    "Automatic (Smart Detect)", "Grammar Fix", "Professional", "Casual", "Academic", "Creative", "Email Format", "Summarize", "Poetic", 
    "Prompt: General", "Prompt: Chain of Thought", "Prompt: Expert Persona", "Prompt: Image Gen", "Prompt: Code Gen", "Prompt: Socratic", "Prompt: Debate",
    "Prompt: Brainstorming", "Prompt: Explain Like I'm 5", "Prompt: Roleplay", "Prompt: SEO Content", "Prompt: Data Extraction", "Prompt: Storytelling", "Prompt: Instructional", "Prompt: Reverse Engineer"
  }
  sp_style.setAdapter(ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, styles))
  local savedStyle = loadConfig("writing_style", "Automatic (Smart Detect)")
  for i, s in ipairs(styles) do if s == savedStyle then sp_style.setSelection(i-1); break end end

  -- Switches Initialization
  sw_ai.setChecked(loadConfig("use_ai", "false") == "true")
  sw_emoji.setChecked(loadConfig("use_emoji", "false") == "true") 
  sw_autocopy.setChecked(loadConfig("use_autocopy", "true") == "true") 
  sw_trans.setChecked(loadConfig("use_trans", "false") == "true")
  sw_preserve_eng.setChecked(loadConfig("preserve_eng", "false") == "true") -- NEW SWITCH
  
  local transLangs = {"English", "Urdu", "Hindi", "Roman Urdu", "Roman Hindi"}
  sp_trans_lang.setAdapter(ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, transLangs))
  local savedTransLang = loadConfig("trans_lang", "English")
  if savedTransLang == "Urdu" then sp_trans_lang.setSelection(1) 
  elseif savedTransLang == "Hindi" then sp_trans_lang.setSelection(2) 
  elseif savedTransLang == "Roman Urdu" then sp_trans_lang.setSelection(3) 
  elseif savedTransLang == "Roman Hindi" then sp_trans_lang.setSelection(4) 
  else sp_trans_lang.setSelection(0) end
  
  local keyList = getApiKeys()
  local listData = ArrayList()
  function refreshList() listData.clear(); for _, k in ipairs(keyList) do listData.add(k) end; lv_keys.setAdapter(ArrayAdapter(ctx, android.R.layout.simple_list_item_1, listData)) end
  refreshList()
  function saveKeysToDisk() local str = table.concat(keyList, "\n"); saveConfig("api_keys", str) end

  _G.addKeyLogic = function() local k = et_new_key.getText().toString():match("^%s*(.-)%s*$"); if #k > 10 then table.insert(keyList, k); et_new_key.setText(""); refreshList(); saveKeysToDisk(); showToast("Key Added") else showToast("Invalid Key") end end
  lv_keys.onItemLongClick = function(p, v, pos, id) local idx = pos + 1; table.remove(keyList, idx); refreshList(); saveKeysToDisk(); showToast("Key Deleted"); return true end
  
  _G.saveSettingsLogic = function()
    saveConfig("language", codes[sp_lang.getSelectedItemPosition() + 1])
    saveConfig("ai_model", modelCodes[sp_model.getSelectedItemPosition() + 1])
    saveConfig("writing_style", styles[sp_style.getSelectedItemPosition() + 1])
    saveConfig("use_ai", tostring(sw_ai.isChecked()))
    saveConfig("use_emoji", tostring(sw_emoji.isChecked())) 
    saveConfig("use_autocopy", tostring(sw_autocopy.isChecked())) 
    saveConfig("append_ending", appendOpts[sp_append.getSelectedItemPosition() + 1]) 
    saveConfig("use_trans", tostring(sw_trans.isChecked()))
    saveConfig("preserve_eng", tostring(sw_preserve_eng.isChecked())) -- SAVE NEW SWITCH
    saveConfig("trans_lang", transLangs[sp_trans_lang.getSelectedItemPosition() + 1])
    showToast("All Settings Saved!")
    WindowManagerHelper.close()
  end
  WindowManagerHelper.show(view, getOverlayParams())
end

-- --- DASHBOARD UI ---
function showDashboard()
  checkFirebaseMessages() 

  local layout = {
    LinearLayout, orientation="vertical", layout_width="fill", layout_height="fill", gravity="center", backgroundColor="#90000000", id="dash_root",
    {
      CardView, layout_width="85%w", layout_height="wrap", CardBackgroundColor="#1E1E1E", radius="20dp", elevation="10dp",
      {
        LinearLayout, orientation="vertical", padding="30dp", gravity="center",
        { TextView, text=getGreeting(), id="tv_greet", textSize="22sp", textColor="#BB86FC", gravity="center" },
        { TextView, text=os.date("%I:%M %p"), id="tv_time", textSize="34sp", textColor="#03DAC6", paddingBottom="15dp", gravity="center" },
        { View, layout_width="60dp", layout_height="2dp", backgroundColor="#333", layout_marginBottom="25dp" },
        { TextView, id="tv_brand", text="V I Information Media", gravity="center", textColor="#EEE", textSize="16sp" },
        { TextView, text="Cloud Connected – v"..APP_VERSION, gravity="center", textColor="#777", textSize="12sp", paddingBottom="30dp" },
        { Button, text="⚙️  Open Settings", layout_width="fill", backgroundColor="#6200EE", textColor="#FFF", onClick="openSettingsFromDash", padding="12dp" },
        { TextView, text="Tap outside or here to Close", padding="15dp", textColor="#B0B0B0", onClick="closeDash", paddingTop="20dp" }
      }
    }
  }
  
  local view = loadlayout(layout)
  tv_greet.setTypeface(Typeface.DEFAULT_BOLD)
  tv_time.setTypeface(Typeface.DEFAULT_BOLD)
  tv_brand.setTypeface(Typeface.DEFAULT_BOLD)
  
  _G.openSettingsFromDash = function() showSettings() end
  _G.closeDash = function() WindowManagerHelper.close() end
  dash_root.onClick = function() WindowManagerHelper.close() end
  WindowManagerHelper.show(view, getOverlayParams())
end

-- =========================================================
--  7. MAIN ENTRY
-- =========================================================
function main()
  if not loadBool("is_logged_in", false) then showLogin(); return end
  if loadBool("is_first_run", true) then showIntro(); return end
  
  local root = service.getRootInActiveWindow()
  if not root then showDashboard(); return end
  local focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
  if focused and focused.isEditable() then startDictation(focused) else showDashboard() end
end

main()