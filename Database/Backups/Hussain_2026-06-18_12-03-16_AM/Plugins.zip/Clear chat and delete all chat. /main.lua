if service.click({
{"More options$800",
"More|Settings$800",
"Clear chat|Chats*$800",
"Clear chat|Chat history$800",
"Delete all chats$800",
"Delete chats>3",
"%Go back<3",
}
})
return true
end