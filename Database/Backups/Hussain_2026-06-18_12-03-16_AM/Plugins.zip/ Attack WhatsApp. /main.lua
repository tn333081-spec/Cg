if click then
  click.cancel()
  service.speak("boomber by Ruben off")
  click=nil
  return true
end

function append(t1,t2)
  for k,v in ipairs(t2) do
    table.insert(t1,v)
  end
end

按钮列表={}
初始化={
{{"%Paste$1","Kirim|Send$1",}}
}
点击列表={
{{"%Paste$1","Kirim|Send$1",}}
}
后续操作={}
循环次数=100
定时间隔=1
定时次数=1
append(按钮列表,初始化)
local c={}

for n=1,循环次数 do
  append(c,点击列表)
end
table.insert(按钮列表,{c})
append(按钮列表,后续操作)

click=service.loopClick(定时间隔*99999999990000000000000,定时次数,{
  {
    "%解锁",
    {按钮列表},
  }
})
service.speak("已boomber by Ruben on开始")
return true