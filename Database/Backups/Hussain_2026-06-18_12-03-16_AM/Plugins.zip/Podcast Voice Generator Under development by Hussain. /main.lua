require "import"
import "android.widget.*"
import "android.view.*"
import "android.content.*"
import "android.net.Uri"
import "android.text.*"
import "cjson"
import "android.media.MediaPlayer"
import "java.util.*"
import "android.os.*"
import "java.io.*"
import "android.media.MediaRecorder"
import "android.util.TypedValue"
import "android.util.Base64"
import "java.lang.Byte"
import "java.lang.Integer"
import "java.lang.System"
import "java.text.SimpleDateFormat"
import "java.text.DateFormat"
import "android.graphics.Typeface"
import "android.graphics.Color"
-- Replace OkHttp with standard Java networking
import "java.net.URL"
import "java.net.HttpURLConnection"
import "java.io.DataOutputStream"

if Build.VERSION.SDK_INT >= 23 then
    import "android.media.PlaybackParams"
end

activity = this
local CURRENT_VERSION = "0.3"

-- ==================== CONSTANTS & GLOBALS ====================
local GEMINI_PREFS = "GEMINI_CONFIG"
local PREFS_NAME = "VOICE_CONFIG"
local GENERATION_STATE_PREFS = "GENERATION_STATE"

local API_PROVIDERS = { "Google Generative Language (Gemini)" }
local API_ENDPOINTS = {
    ["Google Generative Language (Gemini)"] = function(apiKey)
        return string.format("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent?key=%s", apiKey)
    end
}
local DEFAULT_API_KEYS = { "" }
local SELECTED_API_PROVIDER = "Google Generative Language (Gemini)"

local API_KEYS = {}   -- loaded from prefs

-- Voice configuration (same as before)
local configNames = {"Host", "Guest 1", "Guest 2", "Guest 3", "Guest 4", "Guest 5"}
local configVoices = {"Puck", "Kore", "Charon", "Zephyr", "Fenrir", "Leda"}
local configSpeeds = {1.0, 1.0, 1.0, 1.0, 1.0, 1.0}
local configPitches = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0}
local configEmotions = {"Default", "Default", "Default", "Default", "Default", "Default"}

local currentMode = 0
local selectedEmotionSingle = "Default"
local customEmotionPrompt = "Please read this sentence with a deep, warm voice."
local textEmotionMode = "Default (Keep as is)"

local MAX_CHARS = 50000
local MAX_TOKENS = 12500
local CHUNK_SIZE = 4000

-- Audio globals
local audioPlayer = nil
local finalPodcastPath = nil
local testAudioPlayer = nil
local configTestAudioPlayer = nil
local activePlayers = {}
local activeStreams = {}
local activeFiles = {}
local isAudioAutoPlayEnabled = false

local textEmotionModes = { "Default (Keep as is)", "Default Voice Emotion" }
local emotionsFull = { "Default", "Happy", "Energetic", "Sad", "Crying", "Angry",
    "Furious", "Whisper", "Mysterious", "Spooky", "Ghostly", "Flat", "Robot",
    "News", "Radio", "Singing", "Poetic", "Storytelling", "Sarcastic", "Confused",
    "Shocked", "Scared", "Panicked", "Disgusted", "Hopeful", "Nostalgic",
    "Sympathetic", "Firm", "Military", "Fast", "Slow", "Nervous", "Sleepy",
    "Drunk", "Pleading", "Secretive", "Philosophical", "Custom", "Rap", "Pop",
    "Rock", "Jazz", "Blues", "Opera", "Country", "HipHop", "Electronic", "Reggae",
    "Classical", "Lullaby", "Fairy Tale", "Superhero", "Villain", "Alien",
    "Monster", "Cartoon", "Anime", "Gothic", "Romantic", "Comedic", "Horror",
    "SciFi", "Fantasy", "Adventure"
}
local voiceMapGemini = {
    ["Zephyr (Male, Bright)"]="Zephyr", ["Puck (Male, Fresh)"]="Puck",
    ["Charon (Male, Emotional)"]="Charon", ["Kore (Female, Firm)"]="Kore",
    ["Fenrir (Male, Excited)"]="Fenrir", ["Leda (Female, Youthful)"]="Leda",
    ["Orus (Male, Determined)"]="Orus", ["Aoede (Female, Comfortable)"]="Aoede",
    ["Callirrhoe (Female, Easygoing)"]="Callirrhoe", ["Autonoe (Female, Bright)"]="Autonoe",
    ["Enceladus (Male, Slightly Hoarse)"]="Enceladus", ["Iapetus (Male, Clear)"]="Iapetus",
    ["Umbriel (Female, Easygoing)"]="Umbriel", ["Algieba (Male, Smooth)"]="Algieba",
    ["Despina (Female, Smooth)"]="Despina", ["Erinome (Female, Clear)"]="Erinome",
    ["Algenib (Male, Hoarse Voice)"]="Algenib", ["Rasalgethi (Male, Emotional)"]="Rasalgethi",
    ["Laomedeia (Female, Fresh)"]="Laomedeia", ["Achernar (Male, Soft)"]="Achernar",
    ["Alnilam (Male, Firm)"]="Alnilam", ["Schedar (Female, Even)"]="Schedar",
    ["Gacrux (Male, Mature)"]="Gacrux", ["Pulcherrima (Female, Confident)"]="Pulcherrima",
    ["Achird (Male, Friendly)"]="Achird", ["Zubenelgenubi (Male, Simple)"]="Zubenelgenubi",
    ["Vindemiatrix (Female, Gentle)"]="Vindemiatrix", ["Sadachbia (Male, Lively)"]="Sadachbia",
    ["Sadaltager (Male, Knowledgeable)"]="Sadaltager", ["Sulafat (Female, Warm)"]="Sulafat"
}
local emotionMap = {
    ["Default"] = "[READ THIS TEXT EXACTLY AS WRITTEN]",
    ["Happy"] = "[READ WITH A JOYFUL TONE]",
    ["Energetic"] = "[READ WITH HIGH ENERGY]",
    ["Sad"] = "[READ WITH A SAD TONE]",
    ["Crying"] = "[READ WITH CRYING EMOTION]",
    ["Angry"] = "[READ WITH ANGRY TONE]",
    ["Furious"] = "[READ WITH EXTREME ANGER]",
    ["Whisper"] = "[READ IN WHISPER TONE]",
    ["Mysterious"] = "[READ WITH MYSTERIOUS TONE]",
    ["Spooky"] = "[READ WITH SPOOKY TONE]",
    ["Ghostly"] = "[READ WITH GHOSTLY TONE]",
    ["Flat"] = "[READ WITH FLAT MONOTONE]",
    ["Robot"] = "[READ WITH ROBOTIC VOICE]",
    ["News"] = "[READ WITH NEWS ANCHOR TONE]",
    ["Radio"] = "[READ WITH RADIO ANNOUNCER STYLE]",
    ["Singing"] = "[READ AS IF SINGING]",
    ["Poetic"] = "[READ WITH POETIC TONE]",
    ["Storytelling"] = "[READ WITH STORYTELLING TONE]",
    ["Sarcastic"] = "[READ WITH SARCASTIC TONE]",
    ["Confused"] = "[READ WITH CONFUSED TONE]",
    ["Shocked"] = "[READ WITH SHOCKED TONE]",
    ["Scared"] = "[READ WITH SCARED TONE]",
    ["Panicked"] = "[READ WITH PANICKED TONE]",
    ["Disgusted"] = "[READ WITH DISGUSTED TONE]",
    ["Hopeful"] = "[READ WITH HOPEFUL TONE]",
    ["Nostalgic"] = "[READ WITH NOSTALGIC TONE]",
    ["Sympathetic"] = "[READ WITH SYMPATHETIC TONE]",
    ["Firm"] = "[READ WITH FIRM TONE]",
    ["Military"] = "[READ WITH MILITARY TONE]",
    ["Fast"] = "[READ AT FAST PACE]",
    ["Slow"] = "[READ AT SLOW PACE]",
    ["Nervous"] = "[READ WITH NERVOUS TONE]",
    ["Sleepy"] = "[READ WITH SLEEPY TONE]",
    ["Drunk"] = "[READ WITH DRUNK TONE]",
    ["Pleading"] = "[READ WITH PLEADING TONE]",
    ["Secretive"] = "[READ WITH SECRETIVE TONE]",
    ["Philosophical"] = "[READ WITH PHILOSOPHICAL TONE]",
    ["Rap"] = "[READ WITH RAP STYLE]",
    ["Pop"] = "[READ WITH POP MUSIC STYLE]",
    ["Rock"] = "[READ WITH ROCK STYLE]",
    ["Jazz"] = "[READ WITH JAZZ STYLE]",
    ["Blues"] = "[READ WITH BLUES STYLE]",
    ["Opera"] = "[READ WITH OPERA STYLE]",
    ["Country"] = "[READ WITH COUNTRY STYLE]",
    ["HipHop"] = "[READ WITH HIPHOP STYLE]",
    ["Electronic"] = "[READ WITH ELECTRONIC STYLE]",
    ["Reggae"] = "[READ WITH REGGAE STYLE]",
    ["Classical"] = "[READ WITH CLASSICAL STYLE]",
    ["Lullaby"] = "[READ WITH LULLABY STYLE]",
    ["Fairy Tale"] = "[READ WITH FAIRY TALE STYLE]",
    ["Superhero"] = "[READ WITH SUPERHERO STYLE]",
    ["Villain"] = "[READ WITH VILLAIN STYLE]",
    ["Alien"] = "[READ WITH ALIEN STYLE]",
    ["Monster"] = "[READ WITH MONSTER STYLE]",
    ["Cartoon"] = "[READ WITH CARTOON STYLE]",
    ["Anime"] = "[READ WITH ANIME STYLE]",
    ["Gothic"] = "[READ WITH GOTHIC STYLE]",
    ["Romantic"] = "[READ WITH ROMANTIC STYLE]",
    ["Comedic"] = "[READ WITH COMEDIC STYLE]",
    ["Horror"] = "[READ WITH HORROR STYLE]",
    ["SciFi"] = "[READ WITH SCI-FI STYLE]",
    ["Fantasy"] = "[READ WITH FANTASY STYLE]",
    ["Adventure"] = "[READ WITH ADVENTURE STYLE]",
    ["Custom"] = "[CUSTOM EMOTION - USE PROMPT PROVIDED]"
}
local formatOptions = {"wav", "mp3"}
local USER_AUDIO_DIR = "/storage/emulated/0/Audio/Podcast Generator"
local lastGeneratedAudioPath = nil
local lastGeneratedAudioType = nil
local modes = { "Single Voice", "Two Voices (Dialogue)", "Four Voices Podcast", "Six Voices Podcast" }

-- Generation state variables
local isGenerationActive = false
local currentGenerationText = nil
local currentGenerationChunks = {}
local currentGenerationCompleted = {}
local currentGenerationAudioFiles = {}

-- UI references
local chatInput, charCounter, modeSpinner, textEmotionSpinner, formatSpinner
local generateButton, playButton, downloadButton, podcastProgressBar, resultText
local mainHandler = Handler(Looper.getMainLooper())

-- ==================== UTILITY FUNCTIONS ====================
function runOnUi(callback)
    mainHandler.post(Runnable{ run = callback })
end

function estimateTokens(text)
    if not text then return 0 end
    return math.ceil(string.len(text) / 4)
end

function cleanupAllResources()
    for name, player in pairs(activePlayers) do
        if player then
            pcall(function()
                if player.isPlaying() then player.stop() end
                player.release()
                activePlayers[name] = nil
            end)
        end
    end
    for name, stream in pairs(activeStreams) do
        pcall(function() stream.close() end)
        activeStreams[name] = nil
    end
    for name, file in pairs(activeFiles) do
        pcall(function() file.close() end)
        activeFiles[name] = nil
    end
    audioPlayer = nil
    testAudioPlayer = nil
    configTestAudioPlayer = nil
    finalPodcastPath = nil
    lastGeneratedAudioPath = nil
    System.gc()
end

function stopAudio()
    if audioPlayer then
        pcall(function()
            if audioPlayer.isPlaying() then audioPlayer.stop() end
            audioPlayer.release()
        end)
        audioPlayer = nil
        activePlayers["main"] = nil
    end
    if playButton then
        playButton.setText("Listen to Podcast")
        playButton.setEnabled(true)
    end
end

function showErrorDialog(msg)
    runOnUi(function()
        LuaDialog(activity)
            .setTitle("Error")
            .setMessage(tostring(msg))
            .setPositiveButton("OK", nil)
            .show()
        if generateButton then
            generateButton.setText("Generate Audio")
            generateButton.setEnabled(true)
        end
        if podcastProgressBar then podcastProgressBar.setVisibility(View.GONE) end
    end)
end

function showInfoDialog(title, msg)
    runOnUi(function()
        LuaDialog(activity)
            .setTitle(title)
            .setMessage(tostring(msg))
            .setPositiveButton("OK", nil)
            .show()
    end)
end

function updateCharCounter()
    runOnUi(function()
        local text = chatInput.getText() or ""
        local charCount = string.len(text)
        local tokenEstimate = estimateTokens(text)
        local color = 0xFF000000
        if charCount > MAX_CHARS then
            color = 0xFFFF0000
            chatInput.setText(text:sub(1, MAX_CHARS))
            charCount = MAX_CHARS
            tokenEstimate = estimateTokens(chatInput.getText())
        end
        charCounter.setText(string.format("Characters: %d/%d | Tokens: %d/%d",
            charCount, MAX_CHARS, tokenEstimate, MAX_TOKENS))
        charCounter.setTextColor(color)
    end)
end

function getPrefs()
    return activity.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
end

function getGeminiPrefs()
    return activity.getSharedPreferences(GEMINI_PREFS, Context.MODE_PRIVATE)
end

function getGenerationStatePrefs()
    return activity.getSharedPreferences(GENERATION_STATE_PREFS, Context.MODE_PRIVATE)
end

-- ==================== MULTIPLE API KEYS ====================
function saveGeminiConfig(keys, provider)
    local prefs = getGeminiPrefs()
    local editor = prefs.edit()
    editor.putString("API_KEYS", cjson.encode(keys or API_KEYS))
    editor.putString("API_PROVIDER", provider or SELECTED_API_PROVIDER)
    editor.apply()
end

function loadGeminiConfig()
    local prefs = getGeminiPrefs()
    local keysJson = prefs.getString("API_KEYS", cjson.encode(DEFAULT_API_KEYS))
    API_KEYS = cjson.decode(keysJson) or DEFAULT_API_KEYS
    SELECTED_API_PROVIDER = prefs.getString("API_PROVIDER", "Google Generative Language (Gemini)")
end

function showApiKeyDialog()
    local builder = AlertDialog.Builder(activity)
    builder.setTitle("Manage API Keys")
    local layout = LinearLayout(activity)
    layout.setOrientation(LinearLayout.VERTICAL)
    layout.setPadding(40, 20, 40, 20)

    local hint = TextView(activity)
    hint.setText("Enter one key per line")
    hint.setTextSize(14)
    layout.addView(hint)

    local editText = EditText(activity)
    editText.setLayoutParams(LinearLayout.LayoutParams(-1, -2))
    editText.setGravity(Gravity.TOP)
    editText.setLines(5)
    editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE)
    editText.setText(table.concat(API_KEYS, "\n"))
    layout.addView(editText)

    builder.setView(layout)
    builder.setPositiveButton("Save", function()
        local input = editText.getText().toString()
        local lines = {}
        for line in input:gmatch("[^\r\n]+") do
            line = line:match("^%s*(.-)%s*$")
            if line and #line > 0 then
                table.insert(lines, line)
            end
        end
        if #lines == 0 then lines = { "" } end
        API_KEYS = lines
        saveGeminiConfig()
        showInfoDialog("Success", "API keys saved.")
    end)
    builder.setNegativeButton("Cancel", nil)
    builder.show()
end

-- ==================== TEXT SANITIZATION ====================
function sanitizeText(text)
    if not text then return "" end
    -- Remove control characters except newline/tab
    text = text:gsub("[%c\r\n\t]", function(c)
        if c == '\n' or c == '\r' or c == '\t' then return c else return "" end
    end)
    -- Remove emojis (rough)
    text = text:gsub("[\226-\239][\128-\191]+", "")
    -- Collapse multiple spaces
    text = text:gsub("%s+", " ")
    return text
end

-- ==================== GENERATION STATE ====================
function saveGenerationState(text, chunks, completed, audioFiles)
    local prefs = getGenerationStatePrefs()
    local editor = prefs.edit()
    editor.putString("text", text)
    editor.putString("chunks", cjson.encode(chunks))
    editor.putString("completed", cjson.encode(completed))
    editor.putString("audioFiles", cjson.encode(audioFiles))
    editor.putBoolean("hasState", true)
    editor.apply()
end

function loadGenerationState()
    local prefs = getGenerationStatePrefs()
    if not prefs.getBoolean("hasState", false) then return nil end
    return {
        text = prefs.getString("text", ""),
        chunks = cjson.decode(prefs.getString("chunks", "[]")),
        completed = cjson.decode(prefs.getString("completed", "[]")),
        audioFiles = cjson.decode(prefs.getString("audioFiles", "[]"))
    }
end

function clearGenerationState()
    getGenerationStatePrefs().edit().clear().apply()
end

-- ==================== API CALL (using HttpURLConnection) ====================
function callGeminiAPI(prompt, apiKey)
    local urlString = API_ENDPOINTS[SELECTED_API_PROVIDER](apiKey)
    local url = URL(urlString)
    local connection = url.openConnection()
    connection.setRequestMethod("POST")
    connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
    connection.setDoOutput(true)

    local jsonBody = cjson.encode({
        contents = { { parts = { { text = prompt } } } }
    })

    -- Write request body
    local os = DataOutputStream(connection.getOutputStream())
    os.writeBytes(jsonBody)
    os.flush()
    os.close()

    -- Get response
    local responseCode = connection.getResponseCode()
    if responseCode ~= 200 then
        local errorStream = connection.getErrorStream()
        local scanner = Scanner(errorStream).useDelimiter("\\A")
        local errorResponse = scanner.hasNext() and scanner.next() or ""
        scanner.close()
        errorStream.close()
        error("HTTP " .. responseCode .. ": " .. errorResponse)
    end

    local inputStream = connection.getInputStream()
    local scanner = Scanner(inputStream).useDelimiter("\\A")
    local responseBody = scanner.hasNext() and scanner.next() or ""
    scanner.close()
    inputStream.close()
    connection.disconnect()

    local data = cjson.decode(responseBody)
    if data.error then
        error(data.error.message or "Unknown API error")
    end

    -- Extract audio data (assumes base64 in inlineData)
    local audioB64 = data.candidates[1].content.parts[1].inlineData.data
    return Base64.decode(audioB64, Base64.DEFAULT)
end

function tryCallWithAllKeys(prompt)
    local lastError = nil
    for idx, key in ipairs(API_KEYS) do
        local success, result = pcall(callGeminiAPI, prompt, key)
        if success then
            return result
        else
            lastError = result
        end
    end
    error("All API keys failed. Last error: " .. tostring(lastError))
end

-- ==================== PROMPT BUILDING ====================
function getSystemPrompt(emotionName, customPrompt, speed, pitch)
    local emotionText = ""
    if emotionName == "Custom" then
        local p = customPrompt or customEmotionPrompt
        emotionText = (#p > 0) and string.format("[%s]", p) or "[READ THIS TEXT]"
    else
        emotionText = emotionMap[emotionName] or "[READ THIS TEXT]"
    end

    local speedPrompt = ""
    if speed and speed ~= 1.0 then
        if speed < 0.5 then
            speedPrompt = string.format(" [READ AT EXTREMELY SLOW PACE (%.1fx).]", speed)
        elseif speed < 0.8 then
            speedPrompt = string.format(" [READ AT SLOW PACE (%.1fx).]", speed)
        elseif speed < 1.0 then
            speedPrompt = string.format(" [READ AT SLIGHTLY SLOWER PACE (%.1fx).]", speed)
        elseif speed > 2.0 then
            speedPrompt = string.format(" [READ AT EXTREMELY FAST PACE (%.1fx).]", speed)
        elseif speed > 1.5 then
            speedPrompt = string.format(" [READ AT FAST PACE (%.1fx).]", speed)
        elseif speed > 1.0 then
            speedPrompt = string.format(" [READ AT SLIGHTLY FASTER PACE (%.1fx).]", speed)
        end
    end

    local pitchPrompt = ""
    if pitch and pitch ~= 0.0 then
        if pitch < -1.5 then
            pitchPrompt = string.format(" [USE EXTREMELY DEEP VOICE (%.1f).]", pitch)
        elseif pitch < -0.8 then
            pitchPrompt = string.format(" [USE VERY DEEP VOICE (%.1f).]", pitch)
        elseif pitch < 0.0 then
            pitchPrompt = string.format(" [USE DEEPER VOICE (%.1f).]", pitch)
        elseif pitch > 1.5 then
            pitchPrompt = string.format(" [USE EXTREMELY HIGH VOICE (%.1f).]", pitch)
        elseif pitch > 0.8 then
            pitchPrompt = string.format(" [USE VERY HIGH VOICE (%.1f).]", pitch)
        else
            pitchPrompt = string.format(" [USE HIGHER VOICE (%.1f).]", pitch)
        end
    end
    return emotionText .. pitchPrompt .. speedPrompt
end

function buildPromptForChunk(index, chunkText, mode)
    -- Determine which speaker to use based on mode and chunk index
    local speakerIndex = 1  -- default for single voice
    if mode == 1 then -- Two voices: alternate
        speakerIndex = (index % 2 == 1) and 1 or 2
    elseif mode == 2 then -- Four voices: round robin
        speakerIndex = ((index-1) % 4) + 1
    elseif mode == 3 then -- Six voices: round robin
        speakerIndex = ((index-1) % 6) + 1
    end

    local voiceName = configVoices[speakerIndex] or "Puck"
    local speed = configSpeeds[speakerIndex] or 1.0
    local pitch = configPitches[speakerIndex] or 0.0
    local emotion = configEmotions[speakerIndex] or "Default"
    local custom = (emotion == "Custom") and customEmotionPrompt or nil

    local systemPrompt = getSystemPrompt(emotion, custom, speed, pitch)
    -- Combine with the actual text
    return systemPrompt .. " " .. chunkText
end

-- ==================== FILE HANDLING ====================
function saveAudioToFile(audioData, index)
    local cacheDir = activity.getCacheDir()
    local fileName = string.format("temp_tts_%d_%d.wav", os.time(), index)
    local file = File(cacheDir, fileName)
    local fos = FileOutputStream(file)
    fos.write(audioData)
    fos.close()
    return file.getAbsolutePath()
end

function writeWavHeader(outStream, totalAudioLen, sampleRate, channels)
    local bitsPerSample = 16
    local blockAlign = (channels * bitsPerSample) / 8
    local byteRate = sampleRate * channels * (bitsPerSample / 8)
    local totalDataLen = totalAudioLen
    local totalSize = totalDataLen + 36

    local function getBytes(val)
        return {
            val & 0xff,
            (val >> 8) & 0xff,
            (val >> 16) & 0xff,
            (val >> 24) & 0xff
        }
    end
    local totalSizeB = getBytes(totalSize)
    local sampleRateB = getBytes(sampleRate)
    local byteRateB = getBytes(byteRate)
    local dataLenB = getBytes(totalDataLen)

    local header = {
        0x52, 0x49, 0x46, 0x46,                         -- "RIFF"
        totalSizeB[1], totalSizeB[2], totalSizeB[3], totalSizeB[4],
        0x57, 0x41, 0x56, 0x45,                         -- "WAVE"
        0x66, 0x6d, 0x74, 0x20,                         -- "fmt "
        0x10, 0x00, 0x00, 0x00,                         -- chunk size (16 for PCM)
        0x01, 0x00,                                      -- audio format (1 = PCM)
        channels & 0xff, (channels >> 8) & 0xff,
        sampleRateB[1], sampleRateB[2], sampleRateB[3], sampleRateB[4],
        byteRateB[1], byteRateB[2], byteRateB[3], byteRateB[4],
        blockAlign & 0xff, (blockAlign >> 8) & 0xff,
        bitsPerSample & 0xff, (bitsPerSample >> 8) & 0xff,
        0x64, 0x61, 0x74, 0x61,                         -- "data"
        dataLenB[1], dataLenB[2], dataLenB[3], dataLenB[4]
    }
    for i = 1, #header do
        outStream.write(header[i])
    end
end

function mergeAndSavePodcast(audioFilePaths)
    -- Determine output format
    local format = formatSpinner.getSelectedItem() or "wav"
    local finalPath = activity.getCacheDir().toString() .. "/final_podcast." .. format

    -- For simplicity, we assume all temp files are WAV. If format is not WAV,
    -- you'd need conversion. We'll just write WAV.
    local fos = FileOutputStream(finalPath)
    local totalAudioLen = 0

    -- First, read all audio data and compute total length
    local allData = {}
    for _, path in ipairs(audioFilePaths) do
        local fis = FileInputStream(path)
        local data = fis.readAllBytes()
        table.insert(allData, data)
        totalAudioLen = totalAudioLen + #data
        fis.close()
        -- Delete temp file
        File(path).delete()
    end

    -- Write WAV header (assuming 16-bit mono 24kHz)
    writeWavHeader(fos, totalAudioLen, 24000, 1)

    -- Write audio data
    for _, data in ipairs(allData) do
        fos.write(data)
    end
    fos.close()

    return finalPath
end

-- ==================== GENERATION CORE ====================
function processChunks(chunks, startIndex, completed, audioFiles)
    local total = #chunks
    for i = startIndex, total do
        local rawChunk = chunks[i]
        local chunk = sanitizeText(rawChunk)
        local prompt = buildPromptForChunk(i, chunk, currentMode)

        local success, audioData = pcall(tryCallWithAllKeys, prompt)
        if not success then
            -- Save state and show resume dialog
            saveGenerationState(chatInput.getText(), chunks, completed, audioFiles)
            runOnUi(function()
                local errMsg = tostring(audioData):gsub(".*:", "")
                if errMsg:find("junk one") or errMsg:find("junk two") then
                    errMsg = "The API encountered a temporary issue. You can retry and it will resume from where it left off."
                else
                    errMsg = "Error: " .. errMsg
                end
                LuaDialog(activity)
                    .setTitle("Generation Paused")
                    .setMessage(errMsg .. "\n\nDo you want to retry?")
                    .setPositiveButton("Retry", function()
                        resumeGeneration(loadGenerationState())
                    end)
                    .setNegativeButton("Cancel", function()
                        clearGenerationState()
                        runOnUi(function()
                            generateButton.setEnabled(true)
                            podcastProgressBar.setVisibility(View.GONE)
                        end)
                    end)
                    .show()
            end)
            return false
        end

        local filePath = saveAudioToFile(audioData, i)
        table.insert(audioFiles, filePath)
        table.insert(completed, i)
        saveGenerationState(chatInput.getText(), chunks, completed, audioFiles)

        runOnUi(function()
            podcastProgressBar.setProgress(i)
        end)
    end

    -- All done
    local finalPath = mergeAndSavePodcast(audioFiles)
    finalPodcastPath = finalPath
    lastGeneratedAudioPath = finalPath
    lastGeneratedAudioType = "podcast"
    clearGenerationState()
    runOnUi(function()
        resultText.setText("Success! Podcast ready.")
        playButton.setVisibility(View.VISIBLE)
        playButton.setEnabled(true)
        downloadButton.setVisibility(View.VISIBLE)
        generateButton.setEnabled(true)
        generateButton.setText("Generate Audio")
        podcastProgressBar.setVisibility(View.GONE)
    end)
    return true
end

function splitTextIntoChunks(text, chunkSize)
    if not text or #text == 0 then return {} end
    text = text:gsub("\r\n", "\n"):gsub("\r", "\n")
    local chunks = {}
    local pos = 1
    while pos <= #text do
        -- Try to cut at a sentence boundary near chunkSize
        local endPos = pos + chunkSize - 1
        if endPos >= #text then
            chunks[#chunks+1] = text:sub(pos)
            break
        end
        -- Look for newline or period within next few chars
        local lookahead = text:find("[\n.?!]", pos + chunkSize - 20)
        if lookahead and lookahead <= pos + chunkSize + 20 then
            endPos = lookahead
        else
            endPos = pos + chunkSize
        end
        chunks[#chunks+1] = text:sub(pos, endPos)
        pos = endPos + 1
    end
    return chunks
end

function startFreshGeneration(text)
    local chunks = splitTextIntoChunks(text, CHUNK_SIZE)
    currentGenerationChunks = chunks
    currentGenerationCompleted = {}
    currentGenerationAudioFiles = {}

    runOnUi(function()
        podcastProgressBar.setMax(#chunks)
        podcastProgressBar.setProgress(0)
        podcastProgressBar.setVisibility(View.VISIBLE)
        generateButton.setEnabled(false)
        generateButton.setText("Generating...")
    end)

    processChunks(chunks, 1, {}, {})
end

function resumeGeneration(state)
    local chunks = state.chunks
    local completed = state.completed
    local audioFiles = state.audioFiles
    local nextIndex = #completed + 1

    if nextIndex > #chunks then
        -- Already complete? just merge
        local finalPath = mergeAndSavePodcast(audioFiles)
        finalPodcastPath = finalPath
        lastGeneratedAudioPath = finalPath
        lastGeneratedAudioType = "podcast"
        clearGenerationState()
        runOnUi(function()
            resultText.setText("Success! Podcast ready.")
            playButton.setVisibility(View.VISIBLE)
            playButton.setEnabled(true)
            downloadButton.setVisibility(View.VISIBLE)
            generateButton.setEnabled(true)
            generateButton.setText("Generate Audio")
            podcastProgressBar.setVisibility(View.GONE)
        end)
        return
    end

    runOnUi(function()
        podcastProgressBar.setMax(#chunks)
        podcastProgressBar.setProgress(#completed)
        podcastProgressBar.setVisibility(View.VISIBLE)
        generateButton.setEnabled(false)
        generateButton.setText("Resuming...")
    end)

    processChunks(chunks, nextIndex, completed, audioFiles)
end

function generateAudio()
    if isGenerationActive then return end
    local text = chatInput.getText() or ""
    if #text == 0 then
        showInfoDialog("Info", "Please enter some text.")
        return
    end

    local state = loadGenerationState()
    if state then
        LuaDialog(activity)
            .setTitle("Incomplete Generation Found")
            .setMessage("Do you want to resume from where it stopped?")
            .setPositiveButton("Resume", function()
                resumeGeneration(state)
            end)
            .setNegativeButton("Restart", function()
                clearGenerationState()
                startFreshGeneration(text)
            end)
            .show()
    else
        startFreshGeneration(text)
    end
end

-- ==================== UI BUILDING ====================
function updateUIMode(mode)
    -- This function would show/hide configuration panels based on mode.
    -- For simplicity, we'll leave it empty. In a full app, you'd implement.
end

function saveConfig()
    local prefs = getPrefs()
    local editor = prefs.edit()
    editor.putInt("mode", currentMode)
    for i = 1, 6 do
        editor.putString("name" .. i, configNames[i])
        editor.putString("voice" .. i, configVoices[i])
        editor.putFloat("speed" .. i, configSpeeds[i])
        editor.putFloat("pitch" .. i, configPitches[i])
        editor.putString("emotion" .. i, configEmotions[i])
    end
    editor.putString("emotionSingle", selectedEmotionSingle)
    editor.putString("textEmotionMode", textEmotionMode)
    editor.putString("customEmotion", customEmotionPrompt)
    if formatSpinner then
        editor.putString("fileFormat", formatSpinner.getSelectedItem() or "mp3")
    end
    editor.apply()
end

function loadConfig()
    loadGeminiConfig()
    local prefs = getPrefs()
    currentMode = prefs.getInt("mode", 0)
    textEmotionMode = prefs.getString("textEmotionMode", "Default (Keep as is)")
    customEmotionPrompt = prefs.getString("customEmotion", "Please read this sentence with a deep, warm voice.")
    selectedEmotionSingle = prefs.getString("emotionSingle", "Default")
    local fileFormat = prefs.getString("fileFormat", "mp3")

    for i = 1, 6 do
        configNames[i] = prefs.getString("name" .. i, configNames[i])
        configVoices[i] = prefs.getString("voice" .. i, configVoices[i])
        configSpeeds[i] = prefs.getFloat("speed" .. i, 1.0)
        configPitches[i] = prefs.getFloat("pitch" .. i, 0.0)
        configEmotions[i] = prefs.getString("emotion" .. i, "Default")
    end

    runOnUi(function()
        modeSpinner.setSelection(currentMode)

        local function setSpinner(spinner, name, list)
            if not spinner then return end
            for i=1, #list do
                if list[i] == name then
                    spinner.setSelection(i - 1)
                    return
                end
            end
        end
        if formatSpinner then
            setSpinner(formatSpinner, fileFormat, formatOptions)
        end
        if textEmotionSpinner then
            setSpinner(textEmotionSpinner, textEmotionMode, textEmotionModes)
        end
        updateUIMode(currentMode)
        updateCharCounter()
    end)
end

function createUI()
    activity.setTitle("Podcast Generator v" .. CURRENT_VERSION)

    local scroll = ScrollView(activity)
    local ll = LinearLayout(activity)
    ll.setOrientation(LinearLayout.VERTICAL)
    ll.setPadding(20, 20, 20, 20)

    -- Input area
    local inputLabel = TextView(activity)
    inputLabel.setText("Enter your script:")
    inputLabel.setTextSize(16)
    inputLabel.setTypeface(Typeface.DEFAULT_BOLD)
    ll.addView(inputLabel)

    chatInput = EditText(activity)
    chatInput.setLayoutParams(LinearLayout.LayoutParams(-1, 300))
    chatInput.setGravity(Gravity.TOP)
    chatInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE)
    chatInput.setHint("Type or paste your text here...")
    chatInput.addTextChangedListener(TextWatcher{
        afterTextChanged = function() updateCharCounter() end
    })
    ll.addView(chatInput)

    charCounter = TextView(activity)
    charCounter.setText("Characters: 0/50000 | Tokens: 0/12500")
    charCounter.setTextSize(12)
    charCounter.setPadding(0, 5, 0, 10)
    ll.addView(charCounter)

    -- Mode spinner
    local modeLayout = LinearLayout(activity)
    modeLayout.setOrientation(LinearLayout.HORIZONTAL)
    modeLayout.setGravity(Gravity.CENTER_VERTICAL)
    local modeLabel = TextView(activity)
    modeLabel.setText("Mode: ")
    modeLabel.setTextSize(16)
    modeLayout.addView(modeLabel)
    modeSpinner = Spinner(activity)
    modeSpinner.setAdapter(ArrayAdapter(activity, android.R.layout.simple_spinner_item, modes))
    modeSpinner.setLayoutParams(LinearLayout.LayoutParams(-1, -2))
    modeSpinner.onItemSelectedListener = {
        onItemSelected = function(parent, view, position, id)
            currentMode = position
            saveConfig()
            updateUIMode(position)
        end
    }
    modeLayout.addView(modeSpinner)
    ll.addView(modeLayout)

    -- Text emotion spinner
    local textEmotionLayout = LinearLayout(activity)
    textEmotionLayout.setOrientation(LinearLayout.HORIZONTAL)
    textEmotionLayout.setGravity(Gravity.CENTER_VERTICAL)
    local textEmotionLabel = TextView(activity)
    textEmotionLabel.setText("Text Emotion: ")
    textEmotionLabel.setTextSize(16)
    textEmotionLayout.addView(textEmotionLabel)
    textEmotionSpinner = Spinner(activity)
    textEmotionSpinner.setAdapter(ArrayAdapter(activity, android.R.layout.simple_spinner_item, textEmotionModes))
    textEmotionSpinner.onItemSelectedListener = {
        onItemSelected = function(parent, view, position, id)
            textEmotionMode = textEmotionModes[position+1]
            saveConfig()
        end
    }
    textEmotionLayout.addView(textEmotionSpinner)
    ll.addView(textEmotionLayout)

    -- Format spinner
    local formatLayout = LinearLayout(activity)
    formatLayout.setOrientation(LinearLayout.HORIZONTAL)
    formatLayout.setGravity(Gravity.CENTER_VERTICAL)
    local formatLabel = TextView(activity)
    formatLabel.setText("Output Format: ")
    formatLabel.setTextSize(16)
    formatLayout.addView(formatLabel)
    formatSpinner = Spinner(activity)
    formatSpinner.setAdapter(ArrayAdapter(activity, android.R.layout.simple_spinner_item, formatOptions))
    formatSpinner.onItemSelectedListener = {
        onItemSelected = function() saveConfig() end
    }
    formatLayout.addView(formatSpinner)
    ll.addView(formatLayout)

    -- Generate button
    generateButton = Button(activity)
    generateButton.setText("Generate Audio")
    generateButton.setLayoutParams(LinearLayout.LayoutParams(-1, -2))
    generateButton.onClick = function()
        generateAudio()
    end
    ll.addView(generateButton)

    -- Progress bar
    podcastProgressBar = ProgressBar(activity, nil, android.R.attr.progressBarStyleHorizontal)
    podcastProgressBar.setLayoutParams(LinearLayout.LayoutParams(-1, 30))
    podcastProgressBar.setVisibility(View.GONE)
    ll.addView(podcastProgressBar)

    -- Result text
    resultText = TextView(activity)
    resultText.setText("")
    resultText.setTextSize(14)
    resultText.setPadding(0, 10, 0, 10)
    ll.addView(resultText)

    -- Play button
    playButton = Button(activity)
    playButton.setText("Listen to Podcast")
    playButton.setVisibility(View.GONE)
    playButton.onClick = function()
        if finalPodcastPath and File(finalPodcastPath).exists() then
            stopAudio()
            audioPlayer = MediaPlayer()
            activePlayers["main"] = audioPlayer
            audioPlayer.setDataSource(finalPodcastPath)
            audioPlayer.prepare()
            audioPlayer.start()
            playButton.setText("Playing...")
            audioPlayer.setOnCompletionListener(MediaPlayer.OnCompletionListener{
                onCompletion = function()
                    playButton.setText("Listen to Podcast")
                end
            })
        else
            showInfoDialog("Info", "No podcast to play.")
        end
    end
    ll.addView(playButton)

    -- Download button (placeholder)
    downloadButton = Button(activity)
    downloadButton.setText("Download")
    downloadButton.setVisibility(View.GONE)
    downloadButton.onClick = function()
        -- Implement actual download logic if needed
        showInfoDialog("Info", "Download not implemented.")
    end
    ll.addView(downloadButton)

    -- Settings button
    local settingsButton = Button(activity)
    settingsButton.setText("API Settings")
    settingsButton.onClick = function()
        showApiKeyDialog()
    end
    ll.addView(settingsButton)

    scroll.addView(ll)
    activity.setContentView(scroll)

    loadConfig()
    updateUIMode(currentMode)
end

-- ==================== MAIN ====================
function onCreate()
    createUI()
end

onCreate()