
if service.click({
{"%Functions menu$10",
"%Clipboard history$10",
"MANAGE$10",
"SELECT ALL$10",
"DELETE",
}
})
return true
end
