require "import"

local clickFor = 50
local coolTime = 200
local count = 0

function execute()
if count == 1 then service.speak("Clicking started.") end
task(coolTime, function()
if not service.execute("Click") then service.speak("Button not found."); return end
if count >= clickFor then service.speak("Clicking finished "); return end
count = count + 1
execute()
end)
end

execute()