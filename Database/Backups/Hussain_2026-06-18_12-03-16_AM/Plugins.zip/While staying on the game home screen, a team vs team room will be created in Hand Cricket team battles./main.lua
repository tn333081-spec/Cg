
if service.click({
{">hand cricket",
"PLAY TEAM VERSUS TEAM*>4",
"create new room>2",
"play",
}
})
return true
end
