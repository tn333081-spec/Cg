service.playSoundTick()
service.postSpeak(4000,"Task Completed!")
if service.click({
{"More options$250",
"Group info$220",
"More options$200",
"Group permissions$220",
"Send new messages*$20",
"%Go back<2",
}
})
service.rawSpeak("Clicking...")
return true
end
service.rawSpeak("Whats App group not found!")
