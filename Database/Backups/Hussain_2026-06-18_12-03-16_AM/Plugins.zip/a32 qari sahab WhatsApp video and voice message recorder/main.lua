if service.click({
{"video message*|Voice message, Button. Double tap and hold to record, slide left to cancel recording, slide up to lock recording on. Release to send.$10",
"%Direct swipe up",
}
})
return true
end

if service.click({
{"send",
}
})
return true
end