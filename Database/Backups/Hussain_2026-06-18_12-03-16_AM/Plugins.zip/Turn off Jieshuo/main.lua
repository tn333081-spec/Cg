 service.speak("Jieshuo off")
while service.isSpeaking() do
end
this.disableSelf()