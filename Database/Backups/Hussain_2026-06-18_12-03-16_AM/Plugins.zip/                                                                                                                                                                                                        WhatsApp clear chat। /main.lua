
if service.click({
{"More options$01",
"More$01",
"Clear chat$01",
"Clear chat$01",
}
})
return true
end
