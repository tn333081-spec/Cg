require "import"
import "android.widget.*"
import "android.view.*"

layout = {
  LinearLayout,
  orientation = "vertical",
  padding = "16dp",
  {
    EditText,
    id = "inputCount",
    hint = "Number of times",
    inputType = "number"
  },
  {
    Button,
    text = "Start",
    onClick = function()
      
      dialog.dismiss()

      local count = tonumber(tostring(inputCount.getText())) or 1

      service.speak("Started")

      for i = 1, count do
        service.loopClick(1, 1, {  -- repeat 1 time, 1ms interval
          { "%Paste$1" }          -- paste button
        })

        service.loopClick(1, 1, {
          { "LAUNCH INSTANCE","Launch Instance" } -- click button
        })
      end

      service.speak("Completed")

    end
  }
}

dialog = LuaDialog(service)
dialog.setTitle("Auto Paste & Launch")
dialog.setView(loadlayout(layout))
dialog.show()