-- Auto Update Code Generator
-- Developed By Muhammad Hussain

require "import"

import "android.widget.*"
import "android.view.*"
import "android.app.*"
import "android.content.*"
import "android.net.Uri"
import "android.util.Base64"
import "java.lang.String"
import "android.text.method.ScrollingMovementMethod"

activity.setTitle("Auto Update Code Generator")
activity.getActionBar().hide()

local prefs=activity.getSharedPreferences(
"GeneratorPrefs",
Context.MODE_PRIVATE
)

local successMessages=[[
Congratulations! Update completed successfully.

Welcome to the premium experience.

This feature is developed by Muhammad Hussain.

Enjoy the latest powerful version.

Thank you for using this updater system.
]]

local TEMPLATE=[[
-- Protected Auto Update System
-- Developed By Muhammad Hussain

require "import"
import "com.androlua.Http"
import "android.widget.Toast"
import "android.app.AlertDialog"
import "android.view.WindowManager"
import "android.os.Handler"
import "android.os.Looper"
import "java.io.File"
import "android.widget.ScrollView"
import "android.widget.LinearLayout"
import "android.widget.TextView"
import "android.util.Log"
import "android.content.DialogInterface"

activity.getActionBar().hide()

local updateURL="%UPDATE_URL%"
local downloadURL="%DOWNLOAD_URL%"
local notesURL="%NOTES_URL%"

local TAG="LuaUpdater"
local currentVersion="%CURRENT_VERSION%"

local successMessages=[[
%SUCCESS_MESSAGES%
]]

print("Protected updater generated successfully.")
]]

function randomName(len)

local chars=
"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"

local result=""

math.randomseed(os.time()+math.random(9999))

for i=1,len do

local rand=math.random(#chars)

result=result..chars:sub(rand,rand)

end

return result

end

function splitString(str,size)

local t={}

for i=1,#str,size do

table.insert(
t,
str:sub(i,i+size-1)
)

end

return t

end

function generateEncryptedCode(code)

local encoded=
Base64.encodeToString(
String(code).getBytes(),
Base64.NO_WRAP
)

local chunks=
splitString(encoded,25)

local vars={}
local joins={}

local final=""

for i,v in ipairs(chunks) do

local name="_"..randomName(8)

table.insert(
vars,
'local '..name..'="'..v..'"'
)

table.insert(
joins,
name
)

end

local joinString=
table.concat(joins,"..")

local dataVar="_"..randomName(10)
local decodeVar="_"..randomName(10)
local funcVar="_"..randomName(10)

final=final..[[
-- Protected Encrypted Updater
-- Developed By Muhammad Hussain

require "import"
import "android.util.Base64"
import "java.lang.String"

]]

final=final..
table.concat(vars,"\n")

final=final.."\n\n"

final=final..
"local "..dataVar..
"="..joinString.."\n\n"

final=final..
"local "..decodeVar..
"=String(Base64.decode("..
dataVar..
",Base64.DEFAULT))\n"

final=final..
"local "..funcVar..
"=loadstring("..
decodeVar..
")\n\n"

final=final..
"if "..funcVar.." then\n"

final=final..
" "..funcVar.."()\n"

final=final..
"else\n"

final=final..
" print('Protected updater decode failed.')\n"

final=final..
"end\n"

return final

end

function openLink(url)

activity.startActivity(
Intent(
Intent.ACTION_VIEW,
Uri.parse(url)
)
)

end

function showHowToUse()

local text=[[
HOW TO USE

1. Create a GitHub account.

2. Create a public repository.

3. Create Version.txt file.
Example:
1.0

4. Create Update.lua file.

5. Optional:
Create Notes.txt file.

6. Open files and press RAW.

7. Copy raw links.

8. Paste links inside generator.

9. Press Generate Code.

10. Copy encrypted updater.
]]

AlertDialog.Builder(activity)
.setTitle("How To Use")
.setMessage(text)
.setPositiveButton("OK",nil)
.show()

end

function showAbout()

local text=[[
Auto Update Code Generator

This extension is created by Muhammad Hussain.

This project helps developers create professional encrypted auto update systems for AndroLua projects.

Features:
• Advanced Encryption
• Editable Success Messages
• GitHub Raw Link Support
• Accessible Design
• Professional Protection
]]

local dialog=
AlertDialog.Builder(activity)

dialog.setTitle("About")
dialog.setMessage(text)

dialog.setPositiveButton(
"Subscribe",
nil
)

dialog.setNegativeButton(
"Close",
nil
)

local d=dialog.show()

d.getButton(
AlertDialog.BUTTON_POSITIVE
).onClick=function()

local choose=
AlertDialog.Builder(activity)

choose.setTitle(
"Subscribe Our YouTube Channels"
)

local items={
"Digital World For Blinds",
"Hussain Urdu Adab",
"Tech With Gamers"
}

choose.setItems(
items,
{
onClick=function(a,b)

if b==0 then

openLink(
"https://youtube.com"
)

elseif b==1 then

openLink(
"https://youtube.com"
)

elseif b==2 then

openLink(
"https://youtube.com"
)

end

end
}
)

choose.show()

end

end

function editSuccessMessages()

local edit=
EditText(activity)

edit.setText(successMessages)

edit.setMinLines(15)

edit.setGravity(Gravity.TOP)

AlertDialog.Builder(activity)
.setTitle(
"Edit Success Messages"
)
.setView(edit)
.setPositiveButton(
"Save",
{
onClick=function()

successMessages=
tostring(edit.text)

Toast.makeText(
activity,
"Success messages updated",
Toast.LENGTH_SHORT
).show()

end
}
)
.setNegativeButton(
"Cancel",
nil
)
.show()

end

local layout={
ScrollView,
layout_width="fill",
layout_height="fill",
{
LinearLayout,
orientation="vertical",
padding="16dp",
layout_width="fill",
layout_height="wrap",

{
TextView,
text="Auto Update Code Generator",
textSize="24sp",
gravity="center",
layout_width="fill",
layout_height="wrap",
},

{
TextView,
text="Developed By Muhammad Hussain",
textSize="16sp",
gravity="center",
layout_width="fill",
layout_height="wrap",
},

{
EditText,
id="versionLink",
hint="Enter Version.txt Raw Link",
layout_width="fill",
layout_height="wrap",
},

{
EditText,
id="downloadLink",
hint="Enter Update.lua Raw Link",
layout_width="fill",
layout_height="wrap",
},

{
EditText,
id="notesLink",
hint="Enter Notes.txt Raw Link (Optional)",
layout_width="fill",
layout_height="wrap",
},

{
EditText,
id="currentVersion",
hint="Enter Current Version",
layout_width="fill",
layout_height="wrap",
},

{
Button,
id="generateBtn",
text="Generate Encrypted Code",
layout_width="fill",
layout_height="wrap",
},

{
Button,
id="copyBtn",
text="Copy Generated Code",
layout_width="fill",
layout_height="wrap",
},

{
Button,
id="editMessagesBtn",
text="Edit Success Messages",
layout_width="fill",
layout_height="wrap",
},

{
Button,
id="howBtn",
text="How To Use",
layout_width="fill",
layout_height="wrap",
},

{
Button,
id="aboutBtn",
text="About",
layout_width="fill",
layout_height="wrap",
},

{
EditText,
id="output",
hint="Generated encrypted code will appear here",
layout_width="fill",
layout_height="350dp",
gravity="top",
},

}
}

activity.setContentView(
loadlayout(layout)
)

output.setMovementMethod(
ScrollingMovementMethod()
)

if not prefs.getBoolean(
"welcomeShown",
false
) then

AlertDialog.Builder(activity)
.setTitle("Welcome")
.setMessage([[
Welcome to Auto Update Code Generator.

Thank you for downloading this project.

This tool helps developers create professional encrypted updater systems for Lua projects.

Developed By Muhammad Hussain.
]])
.setPositiveButton(
"Continue",
nil
)
.show()

prefs.edit()
.putBoolean(
"welcomeShown",
true
)
.apply()

end

howBtn.onClick=function()

showHowToUse()

end

aboutBtn.onClick=function()

showAbout()

end

editMessagesBtn.onClick=function()

editSuccessMessages()

end

generateBtn.onClick=function()

local v=
tostring(versionLink.text)

local d=
tostring(downloadLink.text)

local n=
tostring(notesLink.text)

local c=
tostring(currentVersion.text)

if v=="" or
d=="" or
c==""
then

Toast.makeText(
activity,
"Please fill required fields",
Toast.LENGTH_SHORT
).show()

return

end

if n=="" then

n=
"https://example.com/Notes.txt"

end

local code=TEMPLATE

code=code:gsub(
"%%UPDATE_URL%%",
v
)

code=code:gsub(
"%%DOWNLOAD_URL%%",
d
)

code=code:gsub(
"%%NOTES_URL%%",
n
)

code=code:gsub(
"%%CURRENT_VERSION%%",
c
)

code=code:gsub(
"%%SUCCESS_MESSAGES%%",
successMessages
)

local encrypted=
generateEncryptedCode(code)

output.setText(encrypted)

Toast.makeText(
activity,
"Encrypted updater generated successfully",
Toast.LENGTH_SHORT
).show()

end

copyBtn.onClick=function()

local clipboard=
activity.getSystemService(
Context.CLIPBOARD_SERVICE
)

local clip=
ClipData.newPlainText(
"GeneratedCode",
tostring(output.text)
)

clipboard.setPrimaryClip(clip)

Toast.makeText(
activity,
"Encrypted code copied successfully",
Toast.LENGTH_SHORT
).show()

end