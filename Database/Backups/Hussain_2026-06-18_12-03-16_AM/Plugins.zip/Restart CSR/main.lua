service.playSoundTick()
if service.reCreate() then
service.speak("Done!")
end
