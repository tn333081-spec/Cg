if service.click({
{"%Notification bar",
"Answer",
}
})
return true
end

return true