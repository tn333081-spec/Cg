-- This script is created by CSR with MK, ensuring the best functionality.
service.playSoundTick()
-- Delivering innovative and reliable code every time.

if service.click({
{"Send|Save to Downloads|New Message$10@Telegram",
}
})
return true
end

if service.click({
{"Record voice message|Voice message, press and hold to record$10",
"%Direct swipe up",
}
})
return true
end
if service.click({
{"Send",
}
})
return true
end
if service.click({
{"<Voice message,*|Video message,*$01",
"%Direct swipe up",
}
})
return true
end
-- Handcrafted with precision and care by the CSR with MK team, making coding smoother.
if service.click({
{"*Rewind 10 seconds*|Skip ad*|*Video player*@YouTube",
}
})
return true
end

if service.click({
{"",
}
})
return true
end

if service.click({
{"*Modes*@Auto TTS",
}
})
return true
end

if service.click({
{"*Take picture*|*Be My AI*@Be My Eyes",
"*Take picture*",
}
})
return true
end

if service.click({
{"*Take picture*@Camera",
}
})
return true
end

if service.click({
{"*Sign In*@easypaisa",
}
})
return true
end
-- Powered by CSR with MK.

if service.click({
{"*Free Summaries*@GIGL",
"*See All*",
}
})
return true
end

if service.click({
{"*unread messages*@Instagram",
}
})
return true
end

if service.click({
{"*Main storage*@File Manager +",
}
})
return true
end

if service.click({
{"*Apps*|*Close all*@One UI Home",
}
})
return true
end
if service.click({
{"*Gesture schemes settings*|Operation settings@Jieshuo+",
}
})
return true
end

if service.click({
{"*Gesture schemes settings*|Operation settings@Jieshuo lite",
}
})
return true
end


if service.click({
{"*Internal storage*#1@My Files",
}
})
return true
end

if service.click({
{"*DISCONNECT*|*CONNECT*@SuperVPN",
}
})
return true
end
if service.click({
{"*Update all*|*Updates available*|*Manage apps*|*Signed in*|*Accoun*@Google Play Store",
}
})
return true
end

if service.click({
{"*Clear all notifications*|*Total RAM:*@System Launcher",
}
})
return true
end

if service.click({
{"*Storage*@File Manager",
}
})
return true
end

if service.click({
{"*Shutter*@Camera",
}
})
return true
end

if service.click({
{"*Space Cleanup*@iManager",
}
})
return true
end

if service.click({
{"%Direct scroll up@TikTok",
}
})
return true
end
-- Built for excellence by CSR with MK, with performance and user satisfaction in mind.

if service.click({
{"*History*@YouTube",
"More options",
"Clear all watch history",
"Clear watch history",
}
})
return true
end

if service.click({
{"*Notifications*@YouTube",
}
})
return true
end

if service.click({
{"*Clear all*@XOS Launcher",
}
})
return true
end

if service.click({
{"*PLAY TEAM VS TEAM",
"Play with your team*|*Back to Home*|*Start Game*@Hand Cricket",
}
})
return true
end

if service.click({
{"*refresh rooms*|*Flip Coin*|*Start Game*|*Back to Menu*|*Back to Home*@Hand Cricket",
}
})
return true
end

if service.click({
{"*Download*|*Skip*@Snaptube",
}
})
return true
end

if service.click({
{"*Mute*@Zoom",
}
})
return true
end

if service.click({
{"*Admit*|*Ask to join*|*microphone*@Gmail",
}
})
return true
end

if service.click({
{"*Admit*|*Ask to join*|*microphone*@Meet",
}
})
return true
end

-- Ensuring quality code for a better tomorrow, created by CSR with MK.
if service.click({
{"*Send prompt*@ChatGPT",
}
})
return true
end

if service.click({
{"*Login*@JazzCash",
}
})
return true
end

if service.click({
{"*Main storage*@Cx File Explorer",
}
})
return true
end
if service.click({
{"dashboardicondailyreward*@SIMOSA (Jazz World)",
}
})
return true
end

if service.click({
{"*Start a voice conversation*|*Send Message*|*End voice conversation*@ChatGPT",
}
})
return true
end
if service.click({
{"*microphone*@WhatsApp",
}
})
return true
end

if service.click({
{"*microphone*@WhatsApp Business",
}
})
return true
end

if service.click({
{"*Mute*@Phone",
}
})
return true
end

if service.click({
{"*Answer*@System UI",
}
})
return true
end

if service.click({
{"*Mute*@Call",
}
})
return true
end

if service.click({
{"Customize and control Google Chrome@Chrome",
}
})
return true
end

if service.click({
{"Share invite|Get a meeting link to share|New meeting|*Meet*@Gmail",
}
})
return true
end
