if service.click({
{"%Function menu$10",
"[540,620]$10",
}
})
return true
end

return true