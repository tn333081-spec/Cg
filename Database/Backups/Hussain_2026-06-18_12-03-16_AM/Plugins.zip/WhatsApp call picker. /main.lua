local answer = false
local join = false

service.click({"%direct swipe up"})

if service.click({"Answer"}) then
    answer = true
    if service.click({"Join Call","Join call","JOIN CALL"}) then
        join = true
    end
end

if answer and join then
    service.speak("WhatsApp group Call joined successfully!")
elseif answer then
    service.speak("Call picked successfully!")
else
    service.speak("No WhatsApp call detected.")
end