require "import"
import "com.androlua.Http"
import "android.widget.Toast"
import "android.app.AlertDialog"
import "android.view.WindowManager"
import "android.os.Handler"
import "android.os.Looper"
import "java.io.File"

local updateURL = "https://raw.githubusercontent.com/muzammilmuneer515-lgtm/Vvh/refs/heads/main/Version.txt"
local downloadURL = "https://raw.githubusercontent.com/muzammilmuneer515-lgtm/Vvh/refs/heads/main/Update.lua"
local currentVersion = "1.2"
local currentDir = "/storage/emulated/0/解说/Plugins/                                                                                                                                                                                                            ChatGPT+"
local oldPath = currentDir .. "/old_main.lua"
local mainPath = currentDir .. "/main.lua"

local oldMainDialog = nil

local function runOriginalCode()
    if File(oldPath).exists() then
        local func, err = loadfile(oldPath)
        if func then 
          local status, result = pcall(func)
          if status and type(result) == "userdata" then
             oldMainDialog = result
          end
        end
    end
end

local function checkUpdate()
    Http.get(updateURL, function(code, response)
        if code == 200 and response then
            local onlineVersion = tostring(response):gsub("^%s*(.-)%s*$", "%1")
            if onlineVersion ~= currentVersion then
                Handler(Looper.getMainLooper()).post(Runnable{run=function()
                    local updateAlertDlg = AlertDialog.Builder(service or activity)
                    updateAlertDlg.setTitle("Update Available!")
                    updateAlertDlg.setMessage("Server Version: " .. onlineVersion .. "\nYour Version: " .. currentVersion)
                    updateAlertDlg.setPositiveButton("Update", {onClick=function(v)
                        v.dismiss()
                        Toast.makeText(service, "Downloading...", 0).show()
                        Http.get(downloadURL, function(c, content)
                            if c == 200 and content then
                                local f = io.open(oldPath, "w")
                                if f then f:write(content) f:close() end
                                
                                local mf = io.open(mainPath, "r")
                                if mf then
                                    local mainContent = mf:read("*a")
                                    mf:close()
                                    local newMainContent = mainContent:gsub('local currentVersion = ".-"', 'local currentVersion = "'..onlineVersion..'"')
                                    local mf2 = io.open(mainPath, "w")
                                    if mf2 then mf2:write(newMainContent):close() end
                                end
                                
                                -- FIRST: CLOSE THE OLD DIALOG BOX
                                if oldMainDialog then
                                    pcall(function() oldMainDialog.dismiss() end)
                                    oldMainDialog = nil
                                end
                                
                                -- THEN: SHOW SUCCESS DIALOG AFTER A SMALL DELAY
                                Handler(Looper.getMainLooper()).postDelayed(Runnable{run=function()
                                    local successDialog = AlertDialog.Builder(service or activity)
                                    successDialog.setTitle("Update Successful")
                                    successDialog.setMessage("Plugin updated to "..onlineVersion.."\nRestarting in 2 seconds...")
                                    successDialog.setPositiveButton("OK", {onClick=function(v2)
                                        v2.dismiss()
                                        
                                        -- WAIT 2 SECONDS THEN CALL MAIN.LUA AGAIN
                                        Handler(Looper.getMainLooper()).postDelayed(Runnable{run=function()
                                            -- CALL MAIN.LUA AGAIN TO RESTART EXTENSION
                                            local func, err = loadfile(mainPath)
                                            if func then
                                                pcall(func)
                                            else
                                                Toast.makeText(service, "Error: " .. tostring(err), 1).show()
                                            end
                                        end}, 2000)
                                    end})
                                    local d2 = successDialog.create()
                                    d2.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
                                    d2.setCancelable(false)
                                    d2.show()
                                end}, 500)
                            end
                        end)
                    end})
                    updateAlertDlg.setNegativeButton("Later", nil)
                    local d1 = updateAlertDlg.create()
                    d1.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
                    d1.show()
                end})
            end
        end
    end)
end

runOriginalCode()

Handler(Looper.getMainLooper()).postDelayed(Runnable{run=function()
    checkUpdate()
end}, 3000)
