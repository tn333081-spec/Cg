local fz=service.getLastSpeakText()
service.copy(fz)
service.speak(" copied,,"..fz)
return true