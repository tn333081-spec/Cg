local days = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"}
local months = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}

local today = os.date("*t")
local dayOfWeek = days[today.wday]
local dayOfMonth = today.day
local month = months[today.month]
local year = today.year

local current_date = dayOfWeek .. ", " .. month .. " " .. dayOfMonth .. ", " .. year
service.speak(current_date)
service.playSoundTick()
