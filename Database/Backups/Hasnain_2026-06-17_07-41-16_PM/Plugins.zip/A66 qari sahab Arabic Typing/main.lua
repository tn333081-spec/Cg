require "import"
import "android.content.Context"
import "android.content.Intent"
import "java.util.Locale"

import "android.speech.SpeechRecognizer"
import "android.speech.RecognitionListener"
import "android.speech.RecognizerIntent"
import "java.util.Locale"
import "android.content.Intent"

-- Substitution table for Arabic keywords
local substitutionTable = {
    ["نعم"] = "Yes",
    ["لا"] = "No",
    ["شكرا"] = "Thank you"
}

function capitalizeFirstWord(text)
    local firstChar = text:sub(1, 1)
    local restOfString = text:sub(2)
    return firstChar:upper() .. restOfString
end

function substituteWords(text)
    for word, substitution in pairs(substitutionTable) do
        text = text:gsub("%f[%a]" .. word .. "%f[%A]", substitution)
    end
    return text
end

function capitalizeAfterPeriod(text)
    return text:gsub("(%.[%s]*%a)", function(match)
        local char = match:sub(-1)
        local capitalizedChar = char:upper()
        return match:sub(1, -2) .. capitalizedChar
    end)
end

function lowercaseAfterComma(text)
    return text:gsub("(%,[%s]*%a)", function(match)
        local char = match:sub(-1)
        local lowercaseChar = char:lower()
        return match:sub(1, -2) .. lowercaseChar
    end)
end

function addPunctuation(text)
    local lastChar = text:sub(-1)
    local punctuation = { ".", "!", "?" }
    local hasPunctuation = false

    for _, p in ipairs(punctuation) do
        if lastChar == p then
            hasPunctuation = true
            break
        end
    end

    if not hasPunctuation then
        text = text .. "."
    end

    return text
end

function hasInternetConnection()
    local connectivityManager = this.getSystemService(Context.CONNECTIVITY_SERVICE)
    local networkInfo = connectivityManager.getActiveNetworkInfo()
    return networkInfo ~= nil and networkInfo.isConnected()
end

function kill()
    speechRecognizer.destroy()
    speechRecognizer = nil
    return true
end

function startListening()
    if not hasInternetConnection() then
        service.asyncSpeak("لا يوجد اتصال بالإنترنت. خدمة التعرف على الصوت غير متاحة.")
        return false
    end
    
    local verbalizationDetected = false
    
    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
    speechListener = RecognitionListener{
        onResults = function(results)
            data = results.getParcelableArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if data ~= nil and data.size() > 0 then
                verbalizationDetected = true
                local recognizedText = data.get(0)
                recognizedText = capitalizeFirstWord(recognizedText)
                recognizedText = substituteWords(recognizedText)
                recognizedText = capitalizeAfterPeriod(recognizedText)
                recognizedText = lowercaseAfterComma(recognizedText)
                recognizedText = addPunctuation(recognizedText)
                
                -- Example Arabic punctuation handling
                recognizedText = string.gsub(recognizedText, "(%s?)فاصل(%s?)([%p]*)$", "%2,%3")
                recognizedText = string.gsub(recognizedText, "(%s?)نقطة كاملة(%s?)([%p]*)$", "%2.%3")
                recognizedText = string.gsub(recognizedText, "(%s?)علامة استفهام(%s?)([%p]*)$", "%2?")
                
                -- Handle Arabic emoji mappings
                recognizedText = string.gsub(recognizedText, "(%s?)وجه مبتسم(%s?)", "%1\u{1F600}%2")
                recognizedText = string.gsub(recognizedText, "(%s?)قلب(%s?)", "%1\u{2764}%2")

                service.getEditText()
                local node = service.getEditText()
                service.insertText(node, recognizedText .. "\n")
                service.speak(recognizedText)
            end
            
            if not verbalizationDetected then
                kill()
                return false
            end
        end,
        onError = function()
            kill()
            return false
        end
    }

    recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
    recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
    recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")  -- Set to Arabic
    recognizerIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, this.getPackageName())
    speechRecognizer.startListening(recognizerIntent)
    speechRecognizer.setRecognitionListener(speechListener)
    
    return true
end

startListening()
return true
