local ld = math.random( 1,10)
print( "congratulations! the winner of this round is number " .. ld)