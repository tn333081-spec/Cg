require "import"
import "android.speech.RecognizerIntent"
import "android.speech.SpeechRecognizer"
import "android.speech.RecognitionListener"
import "android.content.Intent"

if not service.getEditText() then
service.asyncSpeak("Sorry! Text Box Not Found!")
return false
end

local autoPunctuationByHemantSingal = ". "

local recordIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
recordIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
recordIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")

local wordChangeTable = {

[""] = "",
[""] = "", 
[""] = ""


}

local speechRecord = SpeechRecognizer.createSpeechRecognizer(service)
speechRecord.setRecognitionListener{
onResults = function(results)
local spokenText = results.getParcelableArrayList(SpeechRecognizer.RESULTS_RECOGNITION).get(0)
for k, v in pairs(wordChangeTable) do spokenText = spokenText:gsub(k, v) end
service.insertText(service.getEditText(), spokenText .. autoPunctuationByHemantSingal)
service.speak(spokenText)
speechRecord.destroy()
end,
onError = function()
speechRecord.destroy()
service.asyncSpeak("Sorry! I Did Not Understand Your Message!")
end
}
speechRecord.startListening(recordIntent)