require "import"
import "android.speech.RecognizerIntent"
import "android.speech.SpeechRecognizer"
import "android.speech.RecognitionListener"
import "com.androlua.*"
import "android.net.Uri"
import "android.content.Intent"

local boobalan = "" -- variable to store the spoken words

function saveWords(words)
    boobalan = words
end

function startListening()
    local verbalizationDetected = false

    local recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
    recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
    recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur_ar")
    recognizerIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, this.getPackageName())

    local speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)

    local speechListener = RecognitionListener{
        onResults = function(results)
            local data = results.getParcelableArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if data ~= nil and data.size() > 0 then
                verbalizationDetected = true
                local recognizedText = data.get(0)

                -- Save the spoken words
                saveWords(recognizedText)

                local node = service.getEditText()
                local editText = service.getText(node)

                local language = "arabic"
                local defaultLanguage = Locale.getDefault().getLanguage()
                local languageCodes = { ["arabic"] = "ar" }  
                
                local languageCode = languageCodes[language]
                if languageCode then
                    local wordsToTranslate = recognizedText
                    local translatedWords = ""
                    
                    local url = "https://translate.google.com/m?sl=auto&hl=" .. defaultLanguage .. "&q=" .. Uri.encode(wordsToTranslate)
                    url = url .. "&tl=" .. languageCode
                    
                    Http.get(url, function(status, result)
                        if status == 200 then
                            translatedWords = result:match('<div class="result%-container">([^<]+)</div>')
service.insertText(node, translatedWords .. " ")
                            
                            this.speak(translatedWords)
                        end
                    end)
                end
            end

            if not verbalizationDetected then
                kill()
                return false
            end
        end,
        onError = function()
            kill()
            return false
        end
    }

    speechRecognizer.setRecognitionListener(speechListener)
    speechRecognizer.startListening(recognizerIntent)
end

startListening()
return true