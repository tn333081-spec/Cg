require "import"
import "android.preference.PreferenceManager"

-- Obtener las preferencias compartidas
prefs = PreferenceManager.getDefaultSharedPreferences(service)
allPreferences = prefs.getAll()

-- Convertir el objeto Java a una tabla
preferencesTable = {}
keys = allPreferences.keySet().toArray()
for i = 0, #keys - 1 do
    key = keys[i]
    value = allPreferences.get(key)
    preferencesTable[tostring(key)] = tostring(value)
end

-- Claves que deseas imprimir
keysToPrint = {"user_name", "user_password", "user_validity", "versionName"}

-- Imprimir la información correspondiente a las claves especificadas
for _, key in ipairs(keysToPrint) do
    if preferencesTable[key] then
        print("" .. key .. ",  " .. preferencesTable[key])
    end
end