local days = {"اتوار", "سوموار", "منگل", "بدھ", "جمعرات", "جمعہ", "ہفتہ"}
local months = {"جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون", "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر"}

local today = os.date("*t")
local dayOfWeek = days[today.wday]
local dayOfMonth = today.day
local month = months[today.month]
local year = today.year

time = dayOfWeek .. "، " .. dayOfMonth .. " " .. month .. "، " .. year
service.speak(time)
service.playSoundTick()

return true
