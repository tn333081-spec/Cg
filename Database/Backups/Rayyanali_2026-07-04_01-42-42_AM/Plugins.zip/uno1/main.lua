if service.click({
{"Wild*<64$01",
}
})
return true
end