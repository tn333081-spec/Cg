require "import"
import "android.widget.*"
import "android.view.*"
import "android.content.*"
import "android.speech.tts.TextToSpeech"
import "java.util.Locale"

activity.setTitle("Text Reverser")

-- Initialize Text-to-Speech
tts = TextToSpeech(activity, TextToSpeech.OnInitListener {
  onInit = function(status)
    if status == TextToSpeech.SUCCESS then
      tts.setLanguage(Locale.US)
    end
  end
})

-- Layout
scrollView = ScrollView(activity)
layout = LinearLayout(activity)
layout.setOrientation(LinearLayout.VERTICAL)

editText = EditText(activity)
editText.setHint("Enter text to reverse")

reversedTextView = TextView(activity)
reversedTextView.setText("Reversed text will appear here")

reverseButton = Button(activity)
reverseButton.setText("Reverse Text")

copyButton = Button(activity)
copyButton.setText("Copy Reversed Text")

shareButton = Button(activity)
shareButton.setText("Share Reversed Text")

clearButton = Button(activity)
clearButton.setText("Clear Text")

-- Paste button
local pasteButton = Button(activity)
pasteButton.setText("Paste")
pasteButton.setOnClickListener(View.OnClickListener {
  onClick = function(v)
    local clipboard = activity.getSystemService(Context.CLIPBOARD_SERVICE)
    local clip = clipboard.getPrimaryClip()
    if clip and clip.getItemCount() > 0 then
      local pasteData = clip.getItemAt(0).getText()
      if pasteData then
        editText.setText(pasteData)
speak("pasted")
      end
    end
  end
})

-- Add Views to Layout
layout.addView(editText)
layout.addView(pasteButton)  -- Add Paste button here
layout.addView(reverseButton)
layout.addView(reversedTextView)
layout.addView(copyButton)
layout.addView(shareButton)
layout.addView(clearButton)

scrollView.addView(layout)
activity.setContentView(scrollView)

-- Function to reverse the text
function reverseText(text)
  return string.reverse(text)
end

-- Text to speech function
function speak(text)
  tts.speak(text, TextToSpeech.QUEUE_FLUSH, nil, nil)
end

-- Save the original text
originalText = ""

-- Button click listener to reverse text and update reversed text view
reverseButton.setOnClickListener(View.OnClickListener {
  onClick = function(v)
    local inputText = editText.getText().toString()
    
    if inputText == "" then
      speak("Keyboard is empty, please enter some text")
      return
    end
    
    if reverseButton.getText() == "Reverse Text" then
      originalText = inputText  -- Save the original text
      local reversedText = reverseText(inputText)
      editText.setText(reversedText)
      reversedTextView.setText(reversedText)
      reverseButton.setText("Original Text")
      speak("Text reversed")
    else
      editText.setText(originalText)  -- Restore the original text
      reversedTextView.setText("Reversed text will appear here")
      reverseButton.setText("Reverse Text")
      speak("original Text restored")
    end
  end
})

-- Button click listener to copy reversed text
copyButton.setOnClickListener(View.OnClickListener {
  onClick = function(v)
    local inputText = editText.getText().toString()
    if inputText == "" then
      speak("REVERSE TEXT is not available")
      return
    end
local clipboard = activity.getSystemService(Context.CLIPBOARD_SERVICE)
local clip = ClipData.newPlainText("Reversed Text", editText.getText().toString())
clipboard.setPrimaryClip(clip)
speak("Text copied to clipboard")
end
})

-- Button click listener to share reversed text
shareButton.setOnClickListener(View.OnClickListener {
onClick = function(v)
local inputText = editText.getText().toString()
if inputText == "" then
speak("REVERSE TEXT is not available")
return
end
local shareIntent = Intent(Intent.ACTION_SEND)
shareIntent.setType("text/plain")
shareIntent.putExtra(Intent.EXTRA_TEXT, editText.getText().toString())
activity.startActivity(Intent.createChooser(shareIntent, "Share Reversed Text"))
speak("Sharing text")
end
})

-- Button click listener to clear text
clearButton.setOnClickListener(View.OnClickListener {
onClick = function(v)
local inputText = editText.getText().toString()
if inputText == "" then
speak("no need, Keyboard is already empty")
return
end
editText.setText("")
reversedTextView.setText("Reversed text will appear here")
reverseButton.setText("Reverse Text")
originalText = ""
speak("Text cleared")
end
})